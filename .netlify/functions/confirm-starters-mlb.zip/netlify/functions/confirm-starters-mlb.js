// confirm-starters-mlb.js
const { samePlayerName } = require('./lib/player-name');
const { writeSummaryStakeDisplay } = require('./lib/omega-vnext/odds_math');
const { resolveTeamId } = require('./lib/omega-vnext/sports/team_identity');
// 1:30pm ET re-check of ESPN probable starters against today's Alpha + Omega cards.
// Flags SP changes; KILLS SP-dependent picks (MLB Total / Moneyline / F5 / Run Line)
// when the starter used at generation time no longer matches ESPN.
// Does not recompute edges. Writes the updated blob back to the same store.

const SITE_ID = process.env.SITE_ID || "87d7bcd9-e95a-479c-bc44-6432a2ffc606";
const STORES = ["edge-picks-alpha", "edge-picks-omega"];

function todayET() {
  return new Date().toLocaleDateString("en-CA", { timeZone: "America/New_York" });
}

function normalizeTeam(name) {
  return (name || "").toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
}

function matchupParts(matchup) {
  return String(matchup || "").split(/\s+(?:@|vs\.?|at)\s+/i).map(s => s.trim()).filter(Boolean);
}

function isSpDependent(pick) {
  const bt = String(pick.betType || pick.market || "").toLowerCase();
  const side = String(pick.pick || pick.side || "");
  if (/\bf5\b/i.test(bt) || /\bf5\b/i.test(side)) return true;
  if (bt.includes("total")) return true;
  if (bt.includes("moneyline")) return true;
  if (bt.includes("run line") || bt.includes("spread")) return true;
  return false;
}

async function fetchCurrentStarters(dateISO) {
  try {
    const dateParam = dateISO.replace(/-/g, "");
    const url = `https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard?dates=${dateParam}`;
    const resp = await fetch(url);
    if (!resp.ok) return {};
    const data = await resp.json();
    const map = {};
    for (const ev of (data.events || [])) {
      const comp = ev.competitions?.[0];
      if (!comp) continue;
      const away = comp.competitors?.find(c => c.homeAway === "away");
      const home = comp.competitors?.find(c => c.homeAway === "home");
      if (!away || !home) continue;
      const awayProb = away.probables?.[0] || {};
      const homeProb = home.probables?.[0] || {};
      const awayName = away.team?.displayName || "";
      const homeName = home.team?.displayName || "";
      const awayEspn = resolveTeamId("MLB", awayName);
      const homeEspn = resolveTeamId("MLB", homeName);
      const row = {
        awayTeam: away.team?.displayName || "",
        homeTeam: home.team?.displayName || "",
        awaySP: awayProb.athlete?.displayName || awayProb.displayName || "TBD",
        homeSP: homeProb.athlete?.displayName || homeProb.displayName || "TBD",
        status: ev.status?.type?.state || "pre",
      };
      if (awayEspn && homeEspn) map[awayEspn + "_" + homeEspn] = row;
      const key = [awayName, homeName].map(t => normalizeTeam(t).split(" ").pop()).join("_");
      map[key] = row;
    }
    return map;
  } catch (e) {
    console.log(`[confirm-starters] ESPN error: ${e.message}`);
    return {};
  }
}

async function blobGet(store, key, token) {
  try {
    const { getStore } = await import("@netlify/blobs");
    const s = getStore(store);
    const v = await s.get(key, { type: "json" });
    if (v) return v;
  } catch (e) { /* fall through */ }
  try {
    const r = await fetch(`https://api.netlify.com/api/v1/blobs/${SITE_ID}/${store}/${key}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (r.ok) return await r.json();
  } catch (e) { /* fall through */ }
  return null;
}

async function blobPut(store, key, value, token) {
  const body = JSON.stringify(value);
  try {
    const { getStore } = await import("@netlify/blobs");
    const s = getStore(store);
    await s.set(key, body);
  } catch (e) { /* fall through */ }
  try {
    await fetch(`https://api.netlify.com/api/v1/blobs/${SITE_ID}/${store}/${key}`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body,
    });
  } catch (e) { /* fall through */ }
}

function noteIdentityFallback(seen, name) {
  const token = String(name || "");
  if (seen && seen.has(token)) return;
  if (seen) seen.add(token);
  console.warn(`[omega-team-identity] fallback sport=MLB name=${token}`);
}

function lookupEspn(currentStarters, pick, fallbackSeen) {
  const parts = matchupParts(pick.matchup);
  if (parts.length < 2) return null;
  const awayId = resolveTeamId("MLB", parts[0]);
  const homeId = resolveTeamId("MLB", parts[1]);
  if (awayId && homeId) {
    return currentStarters[awayId + "_" + homeId] || currentStarters[homeId + "_" + awayId] || null;
  }
  const awayKey = normalizeTeam(parts[0]).split(" ").pop();
  const homeKey = normalizeTeam(parts[1]).split(" ").pop();
  const legacy = currentStarters[awayKey + "_" + homeKey] || currentStarters[homeKey + "_" + awayKey] || null;
  if (!legacy) return null;
  const rowAway = resolveTeamId("MLB", legacy.awayTeam);
  const rowHome = resolveTeamId("MLB", legacy.homeTeam);
  if (awayId && rowAway && rowHome && awayId !== rowAway && awayId !== rowHome) return null;
  if (homeId && rowAway && rowHome && homeId !== rowAway && homeId !== rowHome) return null;
  for (const name of parts) {
    if (!resolveTeamId("MLB", name)) noteIdentityFallback(fallbackSeen, name);
  }
  return legacy;
}

function omegaCardIsLogOnly(store) {
  return store === "edge-picks-omega";
}

function processPicks(picksData, currentStarters, opts = {}) {
  if (opts && opts.logOnly) {
    const copy = JSON.parse(JSON.stringify(picksData));
    const stats = processPicks(copy, currentStarters);
    return {
      ...stats,
      logOnly: true,
      wrote: false,
      wouldScratch: stats.scratches,
      wouldKill: stats.killed,
    };
  }
  const picks = picksData.picks || [];
  let scratches = 0;
  let killed = 0;
  const kept = [];
  const killedPicks = picksData.killedPicks || [];
  const fallbackSeen = new Set();

  for (const pick of picks) {
    if (String(pick.sport || "") !== "MLB") {
      kept.push(pick);
      continue;
    }
    const current = lookupEspn(currentStarters, pick, fallbackSeen);
    if (!current) {
      kept.push(pick);
      continue;
    }
    if (current.status === "in" || current.status === "post") {
      pick.gameStarted = true;
      kept.push(pick);
      continue;
    }

    const origAway = normalizeTeam(pick.awaySP || "");
    const origHome = normalizeTeam(pick.homeSP || "");
    const curAway = normalizeTeam(current.awaySP);
    const curHome = normalizeTeam(current.homeSP);

    // Tolerant name match: accent/suffix/middle-initial differences are not a scratch.
    const awayScratch = origAway && curAway && curAway !== "tbd" && !samePlayerName(pick.awaySP, current.awaySP);
    const homeScratch = origHome && curHome && curHome !== "tbd" && !samePlayerName(pick.homeSP, current.homeSP);

    if (awayScratch || homeScratch) {
      scratches++;
      pick.starterScratch = true;
      pick.scratchDetails = [];
      if (awayScratch) {
        pick.scratchDetails.push(`${current.awayTeam} SP changed: ${pick.awaySP} → ${current.awaySP}`);
        pick.awaySP = current.awaySP;
      }
      if (homeScratch) {
        pick.scratchDetails.push(`${current.homeTeam} SP changed: ${pick.homeSP} → ${current.homeSP}`);
        pick.homeSP = current.homeSP;
      }
      pick.scratchWarning = `Starter change detected: ${pick.scratchDetails.join("; ")}.`;
      console.log(`[confirm-starters] SCRATCH: ${pick.matchup} — ${pick.scratchDetails.join(", ")}`);

      if (isSpDependent(pick)) {
        killed++;
        pick.killed = true;
        pick.killReason = `SP-dependent ${pick.betType || pick.market || "pick"} voided after starter change`;
        killedPicks.push(pick);
        continue;
      }
    } else if (origAway || origHome) {
      pick.starterConfirmed = true;
    } else {
      // No original SP stored (pre-v10.6 cards). Snapshot current names; do not kill.
      pick.awaySP = pick.awaySP || current.awaySP;
      pick.homeSP = pick.homeSP || current.homeSP;
      pick.starterSnapshotOnly = true;
    }
    kept.push(pick);
  }

  picksData.picks = kept;
  picksData.killedPicks = killedPicks;
  if (kept.length < 2 && Array.isArray(picksData.parlayLegs)) {
    picksData.parlayLegs = [];
    picksData.parlayKilledReason = "Parlay dropped — fewer than 2 live legs after SP kill";
  }
  if (picksData.summary) {
    picksData.summary.totalPicks = kept.length;
    picksData.summary.totalStraightBets = kept.length;
    writeSummaryStakeDisplay(picksData.summary, kept, picksData.parlayLegs);
    picksData.summary.sportsCovered = [...new Set(kept.map(p => p.sport))];
  }
  return { scratches, killed, remaining: kept.length };
}

const { rejectUnlessEtSlot } = require('./lib/et-schedule');

exports.processPicks = processPicks;
exports.omegaCardIsLogOnly = omegaCardIsLogOnly;

exports.handler = async (event) => {
  const etSkip = rejectUnlessEtSlot('confirm-starters-mlb', event);
  if (etSkip) return etSkip;
  try {
    const todayISO = todayET();
    console.log(`[confirm-starters] Running starter check for ${todayISO} (ET) on Alpha+Omega`);

    const token = process.env.NETLIFY_AUTH_TOKEN;
    if (!token) {
      console.log("[confirm-starters] No NETLIFY_AUTH_TOKEN — skipping");
      return { statusCode: 200, body: JSON.stringify({ skipped: true, reason: "no token" }) };
    }

    const currentStarters = await fetchCurrentStarters(todayISO);
    const perStore = [];

    for (const store of STORES) {
      const picksData = await blobGet(store, `picks-${todayISO}`, token);
      if (!picksData || !Array.isArray(picksData.picks) || picksData.picks.length === 0) {
        perStore.push({ store, skipped: true, reason: "no picks today" });
        continue;
      }
      if (omegaCardIsLogOnly(store)) {
        const stats = processPicks(picksData, currentStarters, { logOnly: true });
        const detail = (stats && stats.wouldKill) || 0;
        console.log(`[confirm-starters] ${store} log-only wouldScratch=${stats.scratches} wouldKill=${detail} wrote=false`);
        perStore.push({ store, date: todayISO, ...stats, wrote: false });
        continue;
      }
      const stats = processPicks(picksData, currentStarters);
      picksData.starterCheckAt = new Date().toISOString();
      picksData.starterScratchCount = stats.scratches;
      picksData.starterKilledCount = stats.killed;
      await blobPut(store, `picks-${todayISO}`, picksData, token);
      perStore.push({ store, date: todayISO, ...stats, wrote: true });
      console.log(`[confirm-starters] ${store}: remaining=${stats.remaining} scratches=${stats.scratches} killed=${stats.killed}`);
    }

    return { statusCode: 200, body: JSON.stringify({ success: true, date: todayISO, stores: perStore }) };
  } catch (e) {
    console.error(`[confirm-starters] Error: ${e.message}`);
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
