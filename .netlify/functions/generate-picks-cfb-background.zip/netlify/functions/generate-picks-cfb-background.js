// generate-picks-cfb-background.js
// ── WeBetAI College Football Model v1.1.2-cfb-prob-edge ──
// v1.1.1: skip already-started games (Odds commence_time + ESPN state!==pre).
// v1.1.2: REQUIRE ESPN pre match (Odds commence can lag delayed games); harden team matching.
// SEPARATE ENVIRONMENT from alpha and NFL (edge-picks-cfb / /cfb), cloned from the NFL
// pipeline (generate-picks-nfl-background v1.1-nfl) and adapted for the FBS slate:
//   sharp-book consensus + two-sided de-vig, key-number cover (3/7), Pinnacle predCLV
//   floor -2c, 2+ major US books (Hard Rock preferred), quarter-Kelly, caps 2.5u / 0.5u ML.
// v1.1 ranking/selection (approved CFB-only strategic fix):
//   Rank by probability edge probEdge = coverProb − impliedProb (no-vig prior when available),
//   NOT raw EV%. Conviction YES dual floor: EV >= 3% AND probEdge >= 4pp.
//   Dog-ML gate (underdog Moneyline only if ALL of): consensus |spread| <= 10 (unknown → skip),
//   coverProb >= 0.35, American price <= +200; hard NEVER |spread| >= 14 OR price > +425;
//   soft-penalize home dog ML ~0.8pp in ranking; ML unit cap 0.5u; predCLV >= -0.02.
//   Max 1 Moneyline on the published 3-pick straight card; prefer Spread/Total over ML same game.
//   Lean fill-to-3 (Omega-style): if <3 YES, fill with leans (EV ~1.5%, probEdge >= ~2pp,
//   0.25u, rating Lean, thinSlate true). Do not force failing dog MLs as leans. Empty card
//   if nothing qualifies.
//   Parlay: Omega v11.7-style 2-vs-3 optimizer (true parlay EV, one leg per game). CFB
//   constraints: no leg odds >= +200; no leg coverProb < 40%; max 1 dog ML leg; stake 0.5u
//   (0.25u if any lean on the card).
// Claude is narrator-only — JS already selected and sized.
// CFB-specific discipline: there is NO static power-rating seed for 130+ FBS teams, so
// the projection is market-anchored by design — live ESPN standings (point diff + scoring
// rate) overlay when available, otherwise the market number IS the prior and the honest
// edge comes from line shopping + the shopped-point key-number math. Model drift from the
// consensus number is hard-clamped (±4 pts spread / ±5 pts total) so an empty early-season
// overlay can never manufacture phantom edges on big spreads.
// Off days write "No College Football Games Scheduled For Today".
// Game days with a slate but no qualifying picks write the no-plays card
// ("No qualifying college football plays today — WeBetAI passed.", noGames: false).
//
// Cron always fires (9:10am ET). Off days write the no-games blob so /cfb never shows a
// stale card.
//
// POST body: { scheduled?: bool, force?: bool, dryRun?: bool, date?: "YYYY-MM-DD" }
//   force  — override the existing-picks overwrite guard (scheduled cards are protected)
//   dryRun — compute + log everything, write nothing

const { noPlaysFields, sportReason } = require('./lib/no-plays');
const SITE_ID = process.env.SITE_ID || "87d7bcd9-e95a-479c-bc44-6432a2ffc606";
const STORE_NAME = "edge-picks-cfb";
const MODEL_VERSION = "v1.1.2-cfb-prob-edge";
const NO_GAMES_MSG = "No College Football Games Scheduled For Today";
const NO_EDGE_MSG = "No qualifying college football plays today — WeBetAI passed.";

// ── The Odds API sport key — one key covers the FBS regular season + bowls.
const CFB_ODDS_SPORTS = ["americanfootball_ncaaf"];

// ── Season constants ──
// Margin σ 16.0: academic fit vs the closing line is ~14.1 (arXiv 2212.08116, long sample)
// and practitioner consensus 15.5-16; spreads have been shrinking (2024 avg 10.44, lowest
// in 40 yrs), and variance grows with spread size, so 16.0 is the conservative middle for
// the near-market games this model actually bets. Total σ 12.5. HFA 2.5 (VSiN true-HFA
// ≈ 2.6 over the last 3.5 seasons; books hang ~3.0). Market weight 0.70 (market-heavier
// than NFL's 0.50 because there is no rating seed); drift clamps below are the real
// guardrail.
// sigmaML 14.0 is deliberately LOWER than sigmaMargin: the empirical CFB margin curve has a
// fatter middle and the academic spread→win-probability fit is σ≈14.1 (arXiv 2212.08116).
// Converting spreads to ML win probs with the wider ATS σ systematically overrates underdogs
// (Φ(9/16)=71% for a −9 favorite vs ~74-76% empirical) and fills the card with +250 dog
// MLs — the exact MLB-F5 bleed pattern. With σ 14 the only dog MLs that survive the 3% EV
// floor are genuine price outliers the sharp predCLV anchor also likes.
const PHASE_CONFIG = {
  regular: {
    sigmaMargin: 16.0, sigmaML: 14.0, sigmaTotal: 12.5, hfa: 2.5,
    marketWeight: 0.70, shrinkMult: 1.0,
    maxUnits: 2.5, mlMaxUnits: 0.5, evFloor: 0.03, leanEvFloor: 0.015,
    probEdgeFloor: 0.04, leanProbEdgeFloor: 0.02,
    leagueTotal: 55.5,
    marginClamp: 4.0,   // |modelMargin − marketMargin| ≤ 4 pts
    totalClamp: 5.0,    // |modelTotal − consensusTotal| ≤ 5 pts
  },
};

// Shrinkage priors inherited from alpha's fitted constants (428 graded picks, Mar–Jun 2026),
// same as the NFL pipeline. No CFB-specific fit exists yet — that is what this store
// accumulates. Refit against graded edge-picks-cfb results once the sample is real.
const SHRINK_K = { Spread: 0.35, Total: 0.30, Moneyline: 0.50 };
const COVER_PROB_CAPS = { CFB_Spread: 0.57, CFB_Total: 0.60, CFB_Moneyline: 0.72 };
const LEAN_UNITS = 0.25;
const CONV_PROB_EDGE_FLOOR = 0.04;       // 4pp dual floor with EV >= 3%
const LEAN_PROB_EDGE_FLOOR = 0.02;       // ~2pp lean fill
const LEAN_EV_FLOOR = 0.015;             // ~1.5% lean EV
const HOME_DOG_ML_RANK_PENALTY = 0.008;  // 0.8pp soft penalty on home dog ML rank score
const MAX_ML_ON_CARD = 1;
const DOG_ML_MAX_SPREAD = 10;            // consensus |spread| must be <= 10
const DOG_ML_MIN_COVER = 0.35;
const DOG_ML_MAX_PRICE = 200;            // American price <= +200
const DOG_ML_HARD_SPREAD = 14;           // hard never |spread| >= 14
const DOG_ML_HARD_PRICE = 425;           // hard never price > +425
const PARLAY_MIN_COVER = 0.40;           // no parlay leg coverProb < 40%
const PARLAY_MAX_PLUS_ODDS = 200;        // no parlay leg odds >= +200
const PARLAY_EV_TIE_BAND = 0.02;
const PARLAY_HIT_RATE_EDGE = 0.08;

// ── Book weighting (sharpness) + bettable retail set — identical to NFL ──
const BOOK_SHARPNESS = {
  pinnacle: 3.0,
  betonlineag: 1.5, lowvig: 1.5, bookmaker: 1.5,
  draftkings: 1.2, fanduel: 1.2, betmgm: 1.2, caesars: 1.2, espnbet: 1.2,
};
const RETAIL_US_BOOKS = new Set([
  "draftkings", "fanduel", "betmgm", "caesars", "espnbet",
  "hardrockbet", "hardrockbet_oh", "betrivers", "fanatics", "ballybet", "betparx",
]);
const MAJOR_US_BOOKS = new Set([
  "draftkings", "fanduel", "betmgm", "caesars", "espnbet",
  "hardrockbet", "hardrockbet_oh", "betrivers", "fanatics",
]);
const HARD_ROCK = new Set(["hardrockbet", "hardrockbet_oh"]);
const SHARP_BOOK_KEYS = ["pinnacle", "betfair_ex_eu", "betfair_ex_uk", "betfair", "matchbook", "circasports"];
function bookWeight(key) { return BOOK_SHARPNESS[(key || "").toLowerCase()] || 1.0; }
function isMajor(key) { return MAJOR_US_BOOKS.has((key || "").toLowerCase()); }
function isHardRock(key) { return HARD_ROCK.has((key || "").toLowerCase()); }
function sharpPri(key) {
  const i = SHARP_BOOK_KEYS.indexOf((key || "").toLowerCase());
  return i < 0 ? 99 : i;
}

const INDOOR_VENUES = /alamodome|carrier dome|jma wireless|ford field|lucas oil|mercedes-benz|caesars superdome|nrg stadium|state farm stadium|allegiant|at&t stadium|u\.?s\.? bank|roof|dome/i;

// ── Team matching helpers ──
// CFB nicknames collide (Tigers/Bulldogs/…). Key on SCHOOL, never nickname alone.
// NEVER use naive substring includes — "Georgia" must not match "Georgia Tech",
// "Oregon" must not match "Oregon State", "Oklahoma" must not match "Oklahoma State".
// Compound school tokens (State/Tech/A&M/…) are part of the school, not a mascot.
function normTeam(s) { return (s || "").toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim(); }
const CFB_COMPOUND_SCHOOL = new Set([
  "state", "tech", "am", "a&m", "st", "international", "atlantic", "southern",
  "northern", "eastern", "western", "central", "college", "university",
  "oh", "ohio", // Miami OH / Miami (OH) — OH is school, not mascot
]);
const CFB_TEAM_ALIASES = {
  "ucf": "central florida",
  "central florida": "central florida",
  "pitt": "pittsburgh",
  "pittsburgh": "pittsburgh",
  "ole miss": "ole miss",
  "mississippi": "ole miss", // Odds/ESPN sometimes shorten Ole Miss this way; Mississippi State stays "mississippi state"
  "miami oh": "miami ohio",
  "miami ohio": "miami ohio",
  "miami oh redhawks": "miami ohio",
  "miami florida": "miami",
  "miami hurricanes": "miami",
  "lsu": "louisiana state",
  "louisiana state": "louisiana state",
  "ul monroe": "louisiana monroe",
  "louisiana monroe": "louisiana monroe",
  "ull": "louisiana",
  "louisiana ragin cajuns": "louisiana",
  "usc": "southern california",
  "southern california": "southern california",
  "southern cal": "southern california",
  "nc state": "north carolina state",
  "north carolina state": "north carolina state",
  "boston college": "boston college",
  "utsa": "texas san antonio",
  "utep": "texas el paso",
  "fiu": "florida international",
  "fau": "florida atlantic",
  "app state": "appalachian state",
  "appalachian state": "appalachian state",
  "jmu": "james madison",
  "james madison": "james madison",
  "unlv": "unlv",
  "nevada las vegas": "unlv",
};
function schoolKey(name) {
  const parts = normTeam(name).split(" ").filter(Boolean);
  if (!parts.length) return "";
  // If last token is a compound school word, keep it (State/Tech/…).
  // Only strip a trailing nickname when the token before it completes a school.
  if (parts.length === 1) return parts[0];
  const last = parts[parts.length - 1];
  const prev = parts[parts.length - 2];
  // Keep full string when last is compound OR prev is compound (e.g. "florida atlantic owls")
  if (CFB_COMPOUND_SCHOOL.has(last) || CFB_COMPOUND_SCHOOL.has(prev)) {
    // still drop a pure mascot after a completed compound school: "florida state seminoles"
    if (!CFB_COMPOUND_SCHOOL.has(last) && CFB_COMPOUND_SCHOOL.has(prev)) {
      return parts.slice(0, -1).join(" ");
    }
    return parts.join(" ");
  }
  // Default: drop trailing nickname word ("oregon ducks" → "oregon")
  return parts.slice(0, -1).join(" ");
}
function aliasSchool(name) {
  const n = normTeam(name);
  if (!n) return "";
  if (CFB_TEAM_ALIASES[n]) return CFB_TEAM_ALIASES[n];
  const sk = schoolKey(name);
  if (CFB_TEAM_ALIASES[sk]) return CFB_TEAM_ALIASES[sk];
  // Special: bare "mississippi" → ole miss, but "mississippi state" stays
  if (sk === "mississippi" || n === "mississippi") return "ole miss";
  return sk;
}
function cfbTeamsMatch(a, b) {
  const na = normTeam(a), nb = normTeam(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  const sa = aliasSchool(a), sb = aliasSchool(b);
  if (sa && sb && sa === sb) return true;
  // Exact schoolKey equality without aliases (full mascot names)
  const ka = schoolKey(a), kb = schoolKey(b);
  return ka.length > 2 && ka === kb;
}

// ── Math helpers (identical formulas to alpha/NFL) ──
function erf(x) {
  const s = x >= 0 ? 1 : -1; x = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * x);
  const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
  return s * y;
}
function normalCDF(z) { return 0.5 * (1 + erf(z / Math.SQRT2)); }
function americanToDecimal(odds) { return odds > 0 ? 1 + odds / 100 : 1 + 100 / Math.abs(odds); }
function impliedProb(odds) { return odds < 0 ? Math.abs(odds) / (Math.abs(odds) + 100) : 100 / (odds + 100); }
function parseAmericanOdds(odds) {
  if (typeof odds === "number" && Number.isFinite(odds)) return odds;
  const n = parseInt(String(odds || "").replace(/[^0-9+-]/g, ""), 10);
  return Number.isFinite(n) ? n : NaN;
}
function parseCoverProb(cp) {
  if (typeof cp === "number" && Number.isFinite(cp)) return cp > 1 ? cp / 100 : cp;
  if (typeof cp === "string") {
    const n = parseFloat(cp);
    if (!Number.isFinite(n)) return NaN;
    return /%/.test(cp) || n > 1 ? n / 100 : n;
  }
  return NaN;
}
function noVigProb(myOdds, oppOdds) {
  if (myOdds == null || oppOdds == null) return null;
  const a = impliedProb(myOdds), b = impliedProb(oppOdds);
  const s = a + b;
  return s > 0 ? a / s : null;
}
function weightedMedian(pairs) { // pairs: [{v, w}]
  if (!pairs.length) return null;
  const sorted = [...pairs].sort((a, b) => a.v - b.v);
  const total = sorted.reduce((s, p) => s + p.w, 0);
  let acc = 0;
  for (const p of sorted) { acc += p.w; if (acc >= total / 2) return p.v; }
  return sorted[sorted.length - 1].v;
}
function fmtOdds(o) { return `${o > 0 ? "+" : ""}${o}`; }
function fmtSigned(n, dp = 1) { const v = Number(n).toFixed(dp); return n >= 0 ? `+${v}` : v; }

// CFB key-number cover, weighted to the EMPIRICAL college margin distribution (23,768 FBS
// games since 1980, boydsbets: 3=8.3%, 7=6.7%, 10=4.2%, 14=4.1%, 4=4.1%, 17=3.8%, 21=3.7%).
// College is far less key-number concentrated than the NFL (3+7 decide 16% of CFB games vs
// 24.3% of NFL games), so 3/7 get smaller bumps than the NFL model, 6 is NOT a college key
// number (dropped), and the touchdown multiples 10/14/17/21 stay live because empirical
// mass holds up there while the normal tail decays.
function cfbSpreadCoverProb(modelMargin, pointsReceived, sigma) {
  const need = -pointsReceived;
  const integer = Math.abs(pointsReceived % 1) < 1e-9;
  let pWin, pPush = 0;
  if (integer) {
    pPush = Math.max(0, normalCDF((need + 0.5 - modelMargin) / sigma) - normalCDF((need - 0.5 - modelMargin) / sigma));
    pWin = 1 - normalCDF((need + 0.5 - modelMargin) / sigma);
  } else {
    pWin = 1 - normalCDF((need - modelMargin) / sigma);
  }
  const bump = (kn, w) => {
    const L = Math.abs(pointsReceived);
    if (pointsReceived > 0 && L >= kn - 0.5 && L < kn) pWin -= w;      // +2.5: don't get the 3
    if (pointsReceived > 0 && L > kn && L <= kn + 0.5) pWin += w;      // +3.5: get the 3
    if (pointsReceived < 0 && L >= kn - 0.5 && L < kn) pWin += w;      // -2.5: don't need the 3
    if (pointsReceived < 0 && L > kn && L <= kn + 0.5) pWin -= w;      // -3.5: must clear 3
  };
  bump(3, 0.011); bump(7, 0.008); bump(10, 0.005); bump(14, 0.004); bump(4, 0.003); bump(17, 0.004); bump(21, 0.004);
  pWin = Math.min(0.72, Math.max(0.28, pWin));
  return pPush > 0.002 ? pWin / (1 - pPush) : pWin;
}

function cfbTotalCoverProb(modelTotal, line, isOver, sigma) {
  const integer = Math.abs(line % 1) < 1e-9;
  let pOver, pPush = 0;
  if (integer) {
    pPush = Math.max(0, normalCDF((line + 0.5 - modelTotal) / sigma) - normalCDF((line - 0.5 - modelTotal) / sigma));
    pOver = 1 - normalCDF((line + 0.5 - modelTotal) / sigma);
  } else {
    pOver = 1 - normalCDF((line - modelTotal) / sigma);
  }
  const pWin = isOver ? pOver : Math.max(0, 1 - pOver - pPush);
  const denom = 1 - pPush;
  return denom > 0 ? Math.min(0.70, Math.max(0.30, pWin / denom)) : 0.5;
}

function getEasternDateToday() {
  const et = new Date(new Date().toLocaleString("en-US", { timeZone: "America/New_York" }));
  return `${et.getFullYear()}-${String(et.getMonth() + 1).padStart(2, "0")}-${String(et.getDate()).padStart(2, "0")}`;
}
function easternDateOf(iso) {
  const d = new Date(iso);
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
  const [m, dd, y] = parts.split("/");
  return `${y}-${m}-${dd}`;
}
function formatDateLong(dateISO) {
  return new Date(dateISO + "T12:00:00Z").toLocaleDateString("en-US", {
    timeZone: "America/New_York", weekday: "long", month: "long", day: "numeric", year: "numeric",
  });
}

// ── Anthropic call with timeout + backoff (port of alpha's anthropicFetch — null = LLM
// unavailable; callers MUST fall back to deterministic output, never block the run) ──
async function anthropicFetch(body, { timeoutMs = 45000, retries = 3 } = {}) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal: ctrl.signal,
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify(body),
      });
      clearTimeout(timer);
      if ((resp.status === 429 || resp.status === 529 || resp.status >= 500) && attempt < retries) {
        await new Promise(r => setTimeout(r, Math.min(8000, 800 * Math.pow(2, attempt))));
        continue;
      }
      return resp;
    } catch (e) {
      clearTimeout(timer);
      if (attempt >= retries) return null;
      await new Promise(r => setTimeout(r, Math.min(8000, 800 * Math.pow(2, attempt))));
    }
  }
  return null;
}

// ── ESPN: today's FBS slate (the game-day gate + records) ──
// groups=80 = FBS; without it ESPN returns only Top-25 games and most of the slate is invisible.
async function fetchESPNSlate(dateISO) {
  try {
    const resp = await fetch(`https://site.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard?dates=${dateISO.replace(/-/g, "")}&groups=80&limit=300`);
    if (!resp.ok) return { games: [], seasonPhase: "regular" };
    const data = await resp.json();
    const games = (data.events || []).map(ev => {
      const comp = ev.competitions?.[0];
      if (!comp) return null;
      const home = comp.competitors?.find(c => c.homeAway === "home");
      const away = comp.competitors?.find(c => c.homeAway === "away");
      if (!home || !away) return null;
      return {
        espnId: ev.id,
        date: ev.date,
        seasonType: ev.season?.type || 2, // CFB has no preseason
        weekLabel: ev.season?.slug || "",
        homeTeam: home.team?.displayName || "",
        awayTeam: away.team?.displayName || "",
        homeRecord: home.records?.[0]?.summary || "",
        awayRecord: away.records?.[0]?.summary || "",
        venue: comp.venue?.fullName || "",
        indoor: !!(comp.venue?.indoor) || INDOOR_VENUES.test(comp.venue?.fullName || ""),
        homeId: home.team?.id, awayId: away.team?.id,
        state: comp.status?.type?.state || "pre",
        statusName: comp.status?.type?.name || "",
        statusDetail: comp.status?.type?.detail || comp.status?.type?.description || "",
        espnCommence: ev.date || "",
      };
    }).filter(Boolean);
    const preCount = games.filter(g => g.state === "pre").length;
    console.log(`[cfb] ESPN slate: ${games.length} games (${preCount} pre; delayed/in/post kept for hard skip)`);
    return { games, seasonPhase: "regular" };
  } catch (e) {
    console.log(`[cfb] ESPN slate fetch error: ${e.message}`);
    return { games: [], seasonPhase: "regular" };
  }
}

// Live rating overlay from ESPN CFB standings: per-game point differential (margin signal)
// and per-game combined scoring rate (totals signal). Early season this is empty — the
// projection then stays fully market-anchored, which is the intended behavior.
async function fetchLiveRatingOverlay() {
  const out = {}; // displayName → { margin: pd/gp, totalRate: (PF+PA)/gp }
  try {
    const resp = await fetch("https://site.api.espn.com/apis/v2/sports/football/college-football/standings");
    if (!resp.ok) return out;
    const data = await resp.json();
    const walk = (node) => {
      if (!node) return;
      const entries = node.standings?.entries || [];
      for (const e of entries) {
        const name = e.team?.displayName || "";
        if (!name) continue;
        const stats = {};
        for (const s of (e.stats || [])) if (s.name) stats[s.name] = s.value;
        // ESPN's CFB standings expose `wins` but NO `losses`/`gamesPlayed` stat — games
        // played must come from the `overall` record string ("5-2"), else pd/gp would
        // divide by wins alone and overstate every team.
        const overall = (e.stats || []).find(s => s.name === "overall");
        const recStr = (overall && (overall.displayValue || overall.summary)) || "";
        const recM = recStr.match(/^(\d+)-(\d+)/);
        const wins = Number(stats.wins || 0), losses = Number(stats.losses || 0);
        const gp = Number(stats.gamesPlayed || 0)
          || (recM ? Number(recM[1]) + Number(recM[2]) : 0)
          || (wins + losses);
        if (gp <= 0) continue; // no games yet → no signal, stay market-anchored
        const pd = Number(stats.pointDifferential ?? stats.differential ?? 0);
        const pf = Number(stats.pointsFor ?? NaN);
        const pa = Number(stats.pointsAgainst ?? NaN);
        out[name] = {
          margin: pd / gp,
          totalRate: (Number.isFinite(pf) && Number.isFinite(pa)) ? (pf + pa) / gp : null,
        };
      }
      for (const child of (node.children || [])) walk(child);
    };
    walk(data);
    if (Array.isArray(data.children)) for (const c of data.children) walk(c);
    console.log(`[cfb] Live standings overlay for ${Object.keys(out).length} teams`);
  } catch (e) {
    console.log(`[cfb] standings overlay skipped: ${e.message}`);
  }
  return out;
}

function overlayFor(name, overlay) {
  if (!overlay) return null;
  if (overlay[name]) return overlay[name];
  for (const [k, v] of Object.entries(overlay)) {
    if (cfbTeamsMatch(k, name)) return v;
  }
  return null;
}

// QB-out adjustment (points of margin). ESPN's CFB injury feed is spotty — treat it as a
// best-effort overlay, never a required input.
async function fetchQbAdjustments() {
  const adj = {}; // team displayName → margin points (negative if THEIR qb is out)
  try {
    const resp = await fetch("https://site.api.espn.com/apis/site/v2/sports/football/college-football/injuries");
    if (!resp.ok) return adj;
    const data = await resp.json();
    for (const team of (data.injuries || data.teams || [])) {
      const teamName = team.displayName || team.team?.displayName || "";
      const athletes = team.injuries || team.athletes || [];
      for (const inj of athletes) {
        const pos = (inj.athlete?.position?.abbreviation || inj.position || "").toUpperCase();
        const status = (inj.status || inj.type || "").toLowerCase();
        if (pos !== "QB") continue;
        if (/out|injured reserve|ir|doubtful/.test(status)) {
          const mag = /doubtful/.test(status) ? -2.5 : -4.0;
          adj[teamName] = Math.min(adj[teamName] || 0, mag);
        }
      }
    }
    if (!Object.keys(adj).length && Array.isArray(data.items)) {
      for (const item of data.items) {
        const teamName = item.team?.displayName || "";
        const pos = (item.athlete?.position?.abbreviation || "").toUpperCase();
        const status = (item.status || "").toLowerCase();
        if (pos === "QB" && /out|ir|doubtful/.test(status)) {
          adj[teamName] = /doubtful/.test(status) ? -2.5 : -4.0;
        }
      }
    }
    if (Object.keys(adj).length) console.log(`[cfb] QB adjustments: ${JSON.stringify(adj)}`);
  } catch (e) {
    console.log(`[cfb] QB injury fetch skipped: ${e.message}`);
  }
  return adj;
}

function qbMarginAdj(home, away, qbAdj) {
  if (!qbAdj) return 0;
  const find = (name) => {
    if (qbAdj[name] != null) return qbAdj[name];
    for (const [k, v] of Object.entries(qbAdj)) {
      if (cfbTeamsMatch(k, name)) return v;
    }
    return 0;
  };
  return (find(home) || 0) - (find(away) || 0);
}

// ── The Odds API: today's CFB games (ET-date filtered) ──
async function fetchCFBOdds(dateISO) {
  const apiKey = process.env.ODDS_API_KEY;
  if (!apiKey) { console.log("[cfb] No ODDS_API_KEY — cannot fetch odds"); return []; }
  const seen = new Set();
  const games = [];
  for (const sport of CFB_ODDS_SPORTS) {
    try {
      const url = `https://api.the-odds-api.com/v4/sports/${sport}/odds?regions=us,us2,eu&markets=h2h,spreads,totals&oddsFormat=american&apiKey=${apiKey}`;
      const resp = await fetch(url);
      if (!resp.ok) { console.log(`[cfb] Odds fetch ${sport}: HTTP ${resp.status}`); continue; }
      const data = await resp.json();
      const nowMs = Date.now();
      for (const g of data) {
        if (seen.has(g.id)) continue;
        if (easternDateOf(g.commence_time) !== dateISO) continue;
        const kick = Date.parse(g.commence_time);
        // Skip games that have already kicked off (or are kicking off now)
        if (Number.isFinite(kick) && kick <= nowMs) {
          console.log(`[cfb] Odds skip already started: ${g.away_team} @ ${g.home_team} (${g.commence_time})`);
          continue;
        }
        seen.add(g.id);
        games.push(g);
      }
    } catch (e) {
      console.log(`[cfb] Odds fetch error for ${sport}: ${e.message}`);
    }
  }
  console.log(`[cfb] Odds API: ${games.length} CFB game(s) for ${dateISO}`);
  return games;
}

// ── Consensus per game: weighted-median points, two-sided no-vig probs, sharp anchor ──
function buildGameConsensus(game) {
  const home = game.home_team, away = game.away_team;
  const spreadPts = [], totalPts = [];
  const spreadNoVig = [], totalNoVig = [], mlNoVig = [];
  const offers = { spreadHome: [], spreadAway: [], over: [], under: [], mlHome: [], mlAway: [] };
  let majorSpread = 0, majorTotal = 0, majorML = 0;
  let sharp = { pri: 99, book: null, homeML: null, awayML: null, over: null, under: null, homeSpread: null, awaySpread: null };

  for (const bk of (game.bookmakers || [])) {
    const key = (bk.key || "").toLowerCase();
    const w = bookWeight(key);
    const retail = RETAIL_US_BOOKS.has(key);
    const pri = sharpPri(key);
    if (pri < sharp.pri) {
      sharp = { pri, book: key, homeML: null, awayML: null, over: null, under: null, homeSpread: null, awaySpread: null };
    }
    for (const mkt of (bk.markets || [])) {
      if (mkt.key === "spreads") {
        const h = mkt.outcomes?.find(o => o.name === home);
        const a = mkt.outcomes?.find(o => o.name === away);
        if (h?.point == null || a?.point == null) continue;
        if (isMajor(key)) majorSpread++;
        if (pri === sharp.pri) { sharp.homeSpread = h.price; sharp.awaySpread = a.price; }
        spreadPts.push({ v: h.point, w });
        const nv = noVigProb(h.price, a.price);
        if (nv != null) spreadNoVig.push({ point: h.point, prob: nv, w, key });
        if (retail) {
          offers.spreadHome.push({ book: key, point: h.point, price: h.price, major: isMajor(key) });
          offers.spreadAway.push({ book: key, point: a.point, price: a.price, major: isMajor(key) });
        }
      } else if (mkt.key === "totals") {
        const ov = mkt.outcomes?.find(o => o.name === "Over");
        const un = mkt.outcomes?.find(o => o.name === "Under");
        if (ov?.point == null || un?.point == null) continue;
        if (isMajor(key)) majorTotal++;
        if (pri === sharp.pri) { sharp.over = ov.price; sharp.under = un.price; }
        totalPts.push({ v: ov.point, w });
        const nv = noVigProb(ov.price, un.price);
        if (nv != null) totalNoVig.push({ point: ov.point, prob: nv, w, key });
        if (retail) {
          offers.over.push({ book: key, point: ov.point, price: ov.price, major: isMajor(key) });
          offers.under.push({ book: key, point: un.point, price: un.price, major: isMajor(key) });
        }
      } else if (mkt.key === "h2h") {
        const h = mkt.outcomes?.find(o => o.name === home);
        const a = mkt.outcomes?.find(o => o.name === away);
        if (!h || !a) continue;
        if (isMajor(key)) majorML++;
        if (pri === sharp.pri) { sharp.homeML = h.price; sharp.awayML = a.price; }
        const nv = noVigProb(h.price, a.price);
        if (nv != null) mlNoVig.push({ prob: nv, w, key });
        if (retail) {
          offers.mlHome.push({ book: key, price: h.price, major: isMajor(key) });
          offers.mlAway.push({ book: key, price: a.price, major: isMajor(key) });
        }
      }
    }
  }

  // No-vig prior at (or nearest to) the consensus number. Pinnacle-first via weights.
  const consensusSpread = weightedMedian(spreadPts); // home-team point
  const consensusTotal = weightedMedian(totalPts);
  const wavg = (arr, sel) => {
    const tw = arr.reduce((s, x) => s + x.w, 0);
    return tw > 0 ? arr.reduce((s, x) => s + sel(x) * x.w, 0) / tw : null;
  };
  const atNum = (arr, num) => {
    if (num == null) return arr;
    const exact = arr.filter(x => Math.abs(x.point - num) < 0.01);
    return exact.length ? exact : arr;
  };
  const spreadHomeNoVig = spreadNoVig.length ? wavg(atNum(spreadNoVig, consensusSpread), x => x.prob) : null;
  const totalOverNoVig = totalNoVig.length ? wavg(atNum(totalNoVig, consensusTotal), x => x.prob) : null;
  const mlHomeNoVig = mlNoVig.length ? wavg(mlNoVig, x => x.prob) : null;

  return {
    home, away, commenceTime: game.commence_time,
    consensusSpread, consensusTotal,
    spreadHomeNoVig, totalOverNoVig, mlHomeNoVig,
    offers, bookCount: (game.bookmakers || []).length,
    majorSpread, majorTotal, majorML, sharp,
  };
}

// ── Candidate generation: for each game, evaluate every retail offer on every market and
// keep the best-EV offer per side. Line shopping IS a real, honest edge — the CFB model's
// own directional signal is deliberately tiny until the overlay has real games behind it. ──
function attachPredCLV(cand, sharpOurs, sharpOpp, betOpp) {
  const sharpNV = noVigProb(sharpOurs, sharpOpp);
  if (sharpNV == null || cand.odds == null) return;
  const betNV = noVigProb(cand.odds, betOpp) ?? impliedProb(cand.odds);
  cand.sharpNoVig = +sharpNV.toFixed(4);
  cand.predCLV = +(sharpNV - betNV).toFixed(4);
  cand.sharpBook = "pinnacle";
}

function computeCandidates(consensus, espnGame, cfg, ratingOverlay, qbAdj) {
  const c = consensus;
  if (c.consensusSpread == null && c.mlHomeNoVig == null) return [];
  const cands = [];

  const ovHome = overlayFor(c.home, ratingOverlay);
  const ovAway = overlayFor(c.away, ratingOverlay);
  const qbAdjPts = qbMarginAdj(c.home, c.away, qbAdj);
  const marketMargin = c.consensusSpread != null ? -c.consensusSpread : 0;
  // No static seed exists for 130+ FBS teams: with a live overlay for BOTH teams the rating
  // margin is point-diff-based; without it the market number IS the prior (rating = market).
  const haveMarginOverlay = !!(ovHome && ovAway);
  const ratingMargin = haveMarginOverlay
    ? (ovHome.margin - ovAway.margin) + cfg.hfa
    : marketMargin;
  let modelMargin = cfg.marketWeight * marketMargin + (1 - cfg.marketWeight) * ratingMargin + qbAdjPts;
  // Hard clamp: the model may never drift more than marginClamp pts off the market number.
  modelMargin = Math.max(marketMargin - cfg.marginClamp, Math.min(marketMargin + cfg.marginClamp, modelMargin));

  const indoor = !!(espnGame && espnGame.indoor);
  const haveTotalOverlay = !!(ovHome && ovAway && ovHome.totalRate != null && ovAway.totalRate != null);
  let modelTotal = c.consensusTotal;
  if (c.consensusTotal != null) {
    if (haveTotalOverlay) {
      const ratingTotal = (ovHome.totalRate + ovAway.totalRate) / 2 + (indoor ? 0.8 : 0);
      modelTotal = 0.5 * ratingTotal + 0.5 * c.consensusTotal;
      modelTotal = Math.max(c.consensusTotal - cfg.totalClamp, Math.min(c.consensusTotal + cfg.totalClamp, modelTotal));
    } else {
      modelTotal = c.consensusTotal + (indoor ? 0.4 : 0);
    }
  }

  const shrink = (raw, market, prior) => {
    const cap = COVER_PROB_CAPS[`CFB_${market}`] || 0.60;
    const mkt = (typeof prior === "number" && prior > 0.01 && prior < 0.99) ? prior : null;
    if (mkt == null) return Math.min(raw, cap);
    const K = (SHRINK_K[market] ?? 0.35) * cfg.shrinkMult;
    return Math.min(mkt + K * (raw - mkt), cap);
  };

  const pushCand = (market, side, offer, rawProb, prior, modelProjection, consensusLine, edgePts) => {
    if (!offer || offer.price == null || offer.price < -300 || offer.price > 300) return null;
    const coverProb = shrink(rawProb, market, prior);
    const dec = americanToDecimal(offer.price);
    const ev = coverProb * dec - 1;
    if (ev <= 0) return null;
    let kellyUnits = ((ev / (dec - 1)) * 0.25) * 50; // quarter-Kelly ×50, alpha scale
    kellyUnits = Math.round(kellyUnits * 2) / 2;
    const capU = market === "Moneyline" ? cfg.mlMaxUnits : cfg.maxUnits;
    kellyUnits = Math.max(0.5, Math.min(capU, kellyUnits));
    const sigma = market === "Total" ? cfg.sigmaTotal : cfg.sigmaMargin;
    const mktProb = (typeof prior === "number" && prior > 0.01 && prior < 0.99) ? prior : impliedProb(offer.price);
    const probEdge = coverProb - mktProb;
    const cand = {
      sport: "NCAAF", market, side,
      homeTeam: c.home, awayTeam: c.away, commenceTime: c.commenceTime,
      odds: offer.price, book: offer.book,
      rawProb, coverProb, ev, kellyUnits, probEdge,
      zScore: edgePts != null ? +(edgePts / sigma).toFixed(2) : null,
      modelProjection, consensusLine, edge: edgePts != null ? +edgePts.toFixed(1) : null,
      noVigPrior: prior,
      consensusSpread: c.consensusSpread,
      consensusSpreadAbs: c.consensusSpread != null ? Math.abs(c.consensusSpread) : null,
      homeRecord: espnGame?.homeRecord || "", awayRecord: espnGame?.awayRecord || "",
      venue: espnGame?.venue || "",
      kellyCalcStr: `p=${coverProb.toFixed(3)}, dec=${dec.toFixed(2)}, EV=${(ev * 100).toFixed(1)}%, probEdge=${(probEdge * 100).toFixed(1)}pp, quarter-Kelly → ${kellyUnits}u (best line ${fmtOdds(offer.price)} @ ${offer.book})`,
    };
    cands.push(cand);
    return cand;
  };

  const bestOffer = (list, probFn) => {
    let best = null, bestEv = -Infinity, bestHr = null, bestHrEv = -Infinity;
    const majors = (list || []).filter(o => o.major);
    const pool = majors.length >= 2 ? list.filter(o => o.major) : [];
    if (!pool.length) return null;
    for (const o of pool) {
      const p = probFn(o);
      if (p == null) continue;
      const ev = p.cover * americanToDecimal(o.price) - 1;
      if (ev > bestEv) { bestEv = ev; best = { offer: o, ...p }; }
      if (isHardRock(o.book) && ev > bestHrEv) { bestHrEv = ev; bestHr = { offer: o, ...p }; }
    }
    // Prefer Hard Rock when within 0.5pp EV of the shopped best (product is HR-betable).
    if (bestHr && best && bestHrEv >= bestEv - 0.005) return bestHr;
    return best;
  };

  // SPREADS — key-number cover at the SHOPPED point (the number we actually bet).
  if (c.consensusSpread != null && c.spreadHomeNoVig != null && (c.majorSpread || 0) >= 2) {
    const homeBest = bestOffer(c.offers.spreadHome, (o) => {
      const raw = cfbSpreadCoverProb(modelMargin, o.point, cfg.sigmaMargin);
      const prior = Math.min(0.95, Math.max(0.05, c.spreadHomeNoVig + (o.point - c.consensusSpread) * 0.038));
      return { raw, cover: shrink(raw, "Spread", prior), prior };
    });
    if (homeBest) {
      const added = pushCand("Spread", `${c.home} ${fmtSigned(homeBest.offer.point)}`, homeBest.offer, homeBest.raw, homeBest.prior,
        `${c.home} ${fmtSigned(-modelMargin)}`, `${c.home} ${fmtSigned(homeBest.offer.point)} @ ${fmtOdds(homeBest.offer.price)}`,
        modelMargin - (-homeBest.offer.point));
      if (added) attachPredCLV(added, c.sharp?.homeSpread, c.sharp?.awaySpread, c.offers.spreadAway.find(x => x.book === homeBest.offer.book)?.price);
    }
    const awayBest = bestOffer(c.offers.spreadAway, (o) => {
      const raw = cfbSpreadCoverProb(-modelMargin, o.point, cfg.sigmaMargin);
      const prior = Math.min(0.95, Math.max(0.05, (1 - c.spreadHomeNoVig) + (o.point - (-c.consensusSpread)) * 0.038));
      return { raw, cover: shrink(raw, "Spread", prior), prior };
    });
    if (awayBest) {
      const added = pushCand("Spread", `${c.away} ${fmtSigned(awayBest.offer.point)}`, awayBest.offer, awayBest.raw, awayBest.prior,
        `${c.away} ${fmtSigned(modelMargin)}`, `${c.away} ${fmtSigned(awayBest.offer.point)} @ ${fmtOdds(awayBest.offer.price)}`,
        (-modelMargin) - (-awayBest.offer.point));
      if (added) attachPredCLV(added, c.sharp?.awaySpread, c.sharp?.homeSpread, c.offers.spreadHome.find(x => x.book === awayBest.offer.book)?.price);
    }
  }

  // TOTALS — overlay-blended (or pure-consensus) total, then shop the number.
  if (c.consensusTotal != null && c.totalOverNoVig != null && modelTotal != null && (c.majorTotal || 0) >= 2) {
    const overBest = bestOffer(c.offers.over, (o) => {
      const raw = cfbTotalCoverProb(modelTotal, o.point, true, cfg.sigmaTotal);
      const prior = Math.min(0.95, Math.max(0.05, c.totalOverNoVig + (c.consensusTotal - o.point) * 0.035));
      return { raw, cover: shrink(raw, "Total", prior), prior };
    });
    if (overBest) {
      const added = pushCand("Total", `Over ${overBest.offer.point}`, overBest.offer, overBest.raw, overBest.prior,
        `${modelTotal.toFixed(1)} total`, `Over ${overBest.offer.point} @ ${fmtOdds(overBest.offer.price)}`, overBest.offer.point ? modelTotal - overBest.offer.point : 0);
      if (added) attachPredCLV(added, c.sharp?.over, c.sharp?.under, c.offers.under.find(x => x.book === overBest.offer.book)?.price);
    }
    const underBest = bestOffer(c.offers.under, (o) => {
      const raw = cfbTotalCoverProb(modelTotal, o.point, false, cfg.sigmaTotal);
      const prior = Math.min(0.95, Math.max(0.05, (1 - c.totalOverNoVig) + (o.point - c.consensusTotal) * 0.035));
      return { raw, cover: shrink(raw, "Total", prior), prior };
    });
    if (underBest) {
      const added = pushCand("Total", `Under ${underBest.offer.point}`, underBest.offer, underBest.raw, underBest.prior,
        `${modelTotal.toFixed(1)} total`, `Under ${underBest.offer.point} @ ${fmtOdds(underBest.offer.price)}`, underBest.offer.point - modelTotal);
      if (added) attachPredCLV(added, c.sharp?.under, c.sharp?.over, c.offers.over.find(x => x.book === underBest.offer.book)?.price);
    }
  }

  // MONEYLINES — win prob from model margin via the ML-fitted σ (see sigmaML note above);
  // heavy prior anchor.
  if (c.mlHomeNoVig != null && (c.majorML || 0) >= 2) {
    const rawHomeWin = normalCDF(modelMargin / (cfg.sigmaML || cfg.sigmaMargin));
    const homeBest = bestOffer(c.offers.mlHome, (o) => ({ raw: rawHomeWin, cover: shrink(rawHomeWin, "Moneyline", c.mlHomeNoVig), prior: c.mlHomeNoVig }));
    if (homeBest) {
      const added = pushCand("Moneyline", `${c.home} ML`, homeBest.offer, rawHomeWin, c.mlHomeNoVig,
        `${(shrink(rawHomeWin, "Moneyline", c.mlHomeNoVig) * 100).toFixed(1)}% win`, `${fmtOdds(homeBest.offer.price)}`, null);
      if (added) attachPredCLV(added, c.sharp?.homeML, c.sharp?.awayML, c.offers.mlAway.find(x => x.book === homeBest.offer.book)?.price);
    }
    const rawAwayWin = 1 - rawHomeWin;
    const awayBest = bestOffer(c.offers.mlAway, (o) => ({ raw: rawAwayWin, cover: shrink(rawAwayWin, "Moneyline", 1 - c.mlHomeNoVig), prior: 1 - c.mlHomeNoVig }));
    if (awayBest) {
      const added = pushCand("Moneyline", `${c.away} ML`, awayBest.offer, rawAwayWin, 1 - c.mlHomeNoVig,
        `${(shrink(rawAwayWin, "Moneyline", 1 - c.mlHomeNoVig) * 100).toFixed(1)}% win`, `${fmtOdds(awayBest.offer.price)}`, null);
      if (added) attachPredCLV(added, c.sharp?.awayML, c.sharp?.homeML, c.offers.mlHome.find(x => x.book === awayBest.offer.book)?.price);
    }
  }

  return cands.filter(x => typeof x.predCLV !== "number" || x.predCLV >= -0.02);
}

// ── Match an odds-API game to the ESPN slate (records/venue context) — school-keyed ──
function findESPNGame(espnGames, home, away) {
  return espnGames.find(g =>
    cfbTeamsMatch(g.homeTeam, home) && cfbTeamsMatch(g.awayTeam, away)
  ) || null;
}

// ── Selection: rank by probEdge (not raw EV%), dual floor, dog-ML gate, max 1 ML ──
// CFB blowout filter (parity with Omega MAIN): |spread|≥17.5 needs EV≥6%.
function cfbSpreadAbsLine(cand) {
  if (!cand || cand.market !== "Spread") return null;
  const m = String(cand.side || "").match(/([+-]?\d+(?:\.\d+)?)\s*$/);
  return m ? Math.abs(parseFloat(m[1])) : null;
}
function gameKey(c) {
  if (!c) return "";
  if (c.awayTeam && c.homeTeam) return `${c.awayTeam}@${c.homeTeam}`;
  return String(c.matchup || "").toLowerCase().trim();
}
function isMoneyline(c) {
  return (c.market || c.betType) === "Moneyline";
}
function marketImpliedProb(c) {
  if (typeof c.noVigPrior === "number" && c.noVigPrior > 0.01 && c.noVigPrior < 0.99) return c.noVigPrior;
  const odds = parseAmericanOdds(c.odds);
  return Number.isFinite(odds) ? impliedProb(odds) : NaN;
}
function candProbEdge(c) {
  if (!c) return NaN;
  if (typeof c.probEdge === "number" && Number.isFinite(c.probEdge)) return c.probEdge;
  const cp = typeof c.coverProb === "number" ? c.coverProb : parseCoverProb(c.coverProb);
  const mkt = marketImpliedProb(c);
  if (!Number.isFinite(cp) || !Number.isFinite(mkt)) return NaN;
  return cp - mkt;
}
function consensusSpreadAbs(c) {
  if (typeof c.consensusSpreadAbs === "number" && Number.isFinite(c.consensusSpreadAbs)) return c.consensusSpreadAbs;
  if (typeof c.consensusSpread === "number" && Number.isFinite(c.consensusSpread)) return Math.abs(c.consensusSpread);
  return null;
}
function isUnderdogML(c) {
  if (!isMoneyline(c)) return false;
  const odds = parseAmericanOdds(c.odds);
  return Number.isFinite(odds) && odds > 0;
}
function isHomeDogML(c) {
  if (!isUnderdogML(c)) return false;
  const home = String(c.homeTeam || "").toLowerCase().trim();
  if (!home) return false;
  return String(c.side || c.pick || "").toLowerCase().startsWith(home);
}
function dogMlRejectReason(c) {
  if (!isUnderdogML(c)) return null;
  const odds = parseAmericanOdds(c.odds);
  const abs = consensusSpreadAbs(c);
  const cp = typeof c.coverProb === "number" ? c.coverProb : parseCoverProb(c.coverProb);
  if (Number.isFinite(odds) && odds > DOG_ML_HARD_PRICE) {
    return `dog ML hard-never: price ${fmtOdds(odds)} > +${DOG_ML_HARD_PRICE}`;
  }
  if (abs != null && abs >= DOG_ML_HARD_SPREAD) {
    return `dog ML hard-never: |spread| ${abs} >= ${DOG_ML_HARD_SPREAD}`;
  }
  if (abs == null) {
    return "dog ML skipped: consensus |spread| unknown";
  }
  if (abs > DOG_ML_MAX_SPREAD) {
    return `dog ML: consensus |spread| ${abs} > ${DOG_ML_MAX_SPREAD}`;
  }
  if (!(cp >= DOG_ML_MIN_COVER)) {
    return `dog ML: coverProb ${Number.isFinite(cp) ? (cp * 100).toFixed(1) : "?"}% < ${DOG_ML_MIN_COVER * 100}%`;
  }
  if (Number.isFinite(odds) && odds > DOG_ML_MAX_PRICE) {
    return `dog ML: price ${fmtOdds(odds)} > +${DOG_ML_MAX_PRICE}`;
  }
  return null;
}
function passesCfbBlowout(c) {
  const abs = cfbSpreadAbsLine(c);
  if (abs != null && abs >= 17.5 && !(c.ev >= 0.06)) return false;
  return true;
}
function rankScore(c) {
  let s = candProbEdge(c);
  if (!Number.isFinite(s)) s = -Infinity;
  if (isHomeDogML(c)) s -= HOME_DOG_ML_RANK_PENALTY;
  return s;
}
function marketPrefNonML(c) {
  const m = String(c.market || c.betType || "").toLowerCase();
  if (m === "spread" || m === "total") return 2;
  if (m === "moneyline") return 0;
  return 1;
}
function betterSameGame(a, b) {
  const pref = marketPrefNonML(a) - marketPrefNonML(b);
  if (pref) return pref;
  return rankScore(a) - rankScore(b);
}
function pickBestPerGame(pool) {
  const byGame = new Map();
  for (const cand of pool || []) {
    const key = gameKey(cand);
    if (!key) continue;
    const cur = byGame.get(key);
    if (!cur || betterSameGame(cand, cur) > 0) byGame.set(key, cand);
  }
  return [...byGame.values()].sort((a, b) => rankScore(b) - rankScore(a));
}
function takeUniqueGamesMaxOneML(pool, maxTake, mlAlready = 0) {
  const ranked = pickBestPerGame(pool);
  const out = [];
  let mlCount = mlAlready;
  const used = new Set();
  for (const c of ranked) {
    if (out.length >= maxTake) break;
    const g = gameKey(c);
    if (!g || used.has(g)) continue;
    if (isMoneyline(c) && mlCount >= MAX_ML_ON_CARD) continue;
    if (isMoneyline(c)) mlCount++;
    out.push(c);
    used.add(g);
  }
  return out;
}
function rejectionReason(cand, cfg) {
  const dog = dogMlRejectReason(cand);
  if (dog) return dog;
  if (!passesCfbBlowout(cand)) {
    const abs = cfbSpreadAbsLine(cand);
    return `Blowout spread |line|=${abs} needs EV>=6% (EV ${(cand.ev * 100).toFixed(1)}%).`;
  }
  const pe = candProbEdge(cand);
  const evFloor = cfg.evFloor;
  const peFloor = cfg.probEdgeFloor ?? CONV_PROB_EDGE_FLOOR;
  if (!(cand.ev >= evFloor) || !(pe >= peFloor)) {
    return `Best market (${cand.side} ${fmtOdds(cand.odds)}) EV ${(cand.ev * 100).toFixed(1)}% / probEdge ${(pe * 100).toFixed(1)}pp — below conviction floor (EV>=${(evFloor * 100).toFixed(0)}% AND probEdge>=${(peFloor * 100).toFixed(0)}pp).`;
  }
  if (isMoneyline(cand)) {
    return "Moneyline held off the card (max 1 ML; Spread/Total preferred).";
  }
  return "Edged out by higher-probEdge picks on today's card.";
}
function selectPicks(allCands, cfg) {
  const evFloor = cfg.evFloor;
  const peFloor = cfg.probEdgeFloor ?? CONV_PROB_EDGE_FLOOR;
  const leanEv = cfg.leanEvFloor ?? LEAN_EV_FLOOR;
  const leanPe = cfg.leanProbEdgeFloor ?? LEAN_PROB_EDGE_FLOOR;

  const eligible = [];
  for (const c of allCands || []) {
    if (!c || typeof c.ev !== "number") continue;
    if (!passesCfbBlowout(c)) {
      const abs = cfbSpreadAbsLine(c);
      console.log(`[cfb-blowout] Reject ${c.side} |line|=${abs} EV=${(c.ev * 100).toFixed(1)}% < 6%`);
      continue;
    }
    const dog = dogMlRejectReason(c);
    if (dog) {
      console.log(`[cfb-dog-ml] Reject ${c.side} ${fmtOdds(c.odds)} — ${dog}`);
      continue;
    }
    eligible.push(c);
  }

  const conviction = eligible.filter(c => c.ev >= evFloor && candProbEdge(c) >= peFloor);
  const yes = takeUniqueGamesMaxOneML(conviction, 3);
  const selected = yes.map(c => ({ ...c, isLean: false }));

  if (selected.length < 3) {
    const used = new Set(selected.map(gameKey));
    const leanPool = eligible.filter(c => {
      if (used.has(gameKey(c))) return false;
      return c.ev >= leanEv && candProbEdge(c) >= leanPe;
    });
    const fills = takeUniqueGamesMaxOneML(leanPool, 3 - selected.length, selected.filter(isMoneyline).length);
    for (const c of fills) selected.push({ ...c, isLean: true });
    if (fills.length) {
      console.log(`[cfb-lean-topup] Adding ${fills.length} lean pick(s) — card had ${yes.length} conviction YES`);
    }
  }

  return { picks: selected, lean: selected.length > 0 && selected.every(c => c.isLean) };
}

function unitsToRating(u) {
  if (u >= 2.5) return "A+";
  if (u >= 1.5) return "A";
  if (u >= 1.0) return "A-";
  if (u >= 0.5) return "B+";
  return "B";
}
const RATING_TO_CONFIDENCE = { "A+": "aplus", "A": "a", "A-": "aminus", "B+": "bplus", "B": "b", "Lean": "lean" };

// ── Assemble final pick objects (exact alpha card shape — the /cfb page is an alpha clone) ──
function buildFinalPicks(selected, isLean, seasonPhase) {
  return selected.map(c => {
    const leanPick = !!c.isLean || !!isLean;
    const units = leanPick ? LEAN_UNITS : c.kellyUnits;
    const rating = leanPick ? "Lean" : unitsToRating(units);
    const isML = c.market === "Moneyline";
    const pe = candProbEdge(c);
    const mkt = marketImpliedProb(c);
    const edgePctVal = Number.isFinite(pe) ? (pe * 100).toFixed(1) : ((c.coverProb - impliedProb(c.odds)) * 100).toFixed(1);
    const implPct = Number.isFinite(mkt) ? (mkt * 100).toFixed(1) : (impliedProb(c.odds) * 100).toFixed(1);
    const modelEdgeStr = isML
      ? `Model Win Prob: ${(c.coverProb * 100).toFixed(1)}%, Implied: ${implPct}%, Edge: ${edgePctVal}%`
      : `Bet ${c.side} ${fmtOdds(c.odds)} @ ${c.book || "retail"}. ${c.modelProjection}. Calibrated edge ${edgePctVal}%.`;
    return {
      sport: "NCAAF",
      matchup: `${c.awayTeam} vs. ${c.homeTeam}`,
      pick: c.side,
      betType: c.market,
      odds: fmtOdds(c.odds),
      rating,
      confidence: RATING_TO_CONFIDENCE[rating] || "b",
      units: `${units}u`,
      ev: `${(c.ev * 100).toFixed(1)}%`,
      evRaw: c.ev,
      edgePct: `${edgePctVal}%`,
      edgePoints: c.edge,
      coverProb: `${(c.coverProb * 100).toFixed(0)}%`,
      zScore: c.zScore,
      kellyCalc: c.kellyCalcStr,
      winProbability: `${(c.coverProb * 100).toFixed(0)}%`,
      coreReasoning: "",
      whatLoses: "",
      clvExpectation: "",
      modelEdge: modelEdgeStr,
      commenceTime: c.commenceTime || "",
      bestBook: c.book || "",
      predCLV: typeof c.predCLV === "number" ? c.predCLV : null,
      sharpBook: c.sharpBook || null,
      homeTeam: c.homeTeam,
      awayTeam: c.awayTeam,
      consensusSpread: c.consensusSpread,
      consensusSpreadAbs: c.consensusSpreadAbs,
      noVigPrior: c.noVigPrior,
      seasonPhase,
      thinSlate: leanPick,
      source: "cfb",
      result: "pending",
    };
  });
}

function calcParlayAmerican(oddsArr) {
  let dec = 1;
  for (const o of oddsArr) {
    const n = typeof o === "number" ? o : parseInt(String(o).replace(/[^0-9+-]/g, ""), 10);
    if (!Number.isFinite(n)) { dec *= 1.909; continue; }
    dec *= n > 0 ? 1 + n / 100 : 1 + 100 / Math.abs(n);
  }
  const am = dec >= 2 ? Math.round((dec - 1) * 100) : Math.round(-100 / (dec - 1));
  return am > 0 ? `+${am}` : `${am}`;
}

function parlayUnitsFor(picks) {
  const hasLean = (picks || []).some(p => p.thinSlate || p.isLean || (p.rating || "").toLowerCase() === "lean");
  return hasLean ? 0.25 : 0.5;
}
function legDirection(side) {
  const s = (side || "").toLowerCase();
  return s.includes("over") ? "over" : s.includes("under") ? "under" : "other";
}
function parlayComboStats(cands) {
  let combinedDecimal = 1.0, combinedProb = 1.0;
  for (const c of cands || []) {
    const odds = c.oddsNum;
    if (!Number.isFinite(odds) || !Number.isFinite(c.coverProbNum)) continue;
    combinedDecimal *= odds > 0 ? 1 + odds / 100 : 1 + 100 / Math.abs(odds);
    combinedProb *= c.coverProbNum;
  }
  const ev = combinedProb * combinedDecimal - 1;
  const uniqueSports = new Set((cands || []).map(c => c.sport).filter(Boolean)).size;
  const dirs = (cands || []).map(c => legDirection(c.side));
  const allSameTotalsDir = dirs.length >= 3 && (dirs.every(d => d === "over") || dirs.every(d => d === "under"));
  const adjustedEV = ev + Math.max(0, uniqueSports - 1) * 0.02 - (allSameTotalsDir ? 0.08 : 0);
  return { combinedDecimal, combinedProb, ev, adjustedEV };
}
function chooseParlay2or3(legs2, legs3) {
  const two = (legs2 && legs2.length >= 2) ? legs2 : null;
  const three = (legs3 && legs3.length >= 3) ? legs3 : null;
  if (three && !two) return three;
  if (two && !three) return two;
  if (!two && !three) return [];
  const s2 = parlayComboStats(two);
  const s3 = parlayComboStats(three);
  if (s2.ev > s3.ev) return two;
  if ((s3.ev - s2.ev) <= PARLAY_EV_TIE_BAND && s2.combinedProb >= s3.combinedProb + PARLAY_HIT_RATE_EDGE) {
    return two;
  }
  return three;
}
function parlayCombinations(arr, k) {
  const out = [];
  const rec = (start, acc) => {
    if (acc.length === k) { out.push(acc.slice()); return; }
    for (let i = start; i <= arr.length - (k - acc.length); i++) {
      acc.push(arr[i]);
      rec(i + 1, acc);
      acc.pop();
    }
  };
  rec(0, []);
  return out;
}
function isParlayDogML(c) {
  const m = String(c.market || c.betType || "").toLowerCase();
  if (m !== "moneyline") return false;
  return Number.isFinite(c.oddsNum) && c.oddsNum > 0;
}
function comboDogMlCount(combo) {
  return (combo || []).filter(isParlayDogML).length;
}
function bestParlayComboOfSize(pool, k) {
  if (!pool || pool.length < k) return null;
  let best = null;
  let bestEv = -Infinity;
  for (const combo of parlayCombinations(pool, k)) {
    const games = new Set(combo.map(c => (c.matchup || "").toLowerCase().trim()));
    if (games.size < k) continue;
    if (comboDogMlCount(combo) > 1) continue;
    const s = parlayComboStats(combo);
    if (s.ev > bestEv) {
      bestEv = s.ev;
      best = combo;
    }
  }
  return best;
}
function toParlayCand(c) {
  if (!c) return null;
  const oddsNum = parseAmericanOdds(c.oddsNum != null ? c.oddsNum : c.odds);
  const coverProbNum = Number.isFinite(c.coverProbNum)
    ? c.coverProbNum
    : (typeof c.coverProb === "number" ? c.coverProb : parseCoverProb(c.coverProb));
  const evNum = typeof c.evNum === "number" ? c.evNum
    : typeof c.ev === "number" ? c.ev
    : (typeof c.evRaw === "number" ? c.evRaw : parseFloat(c.ev) / 100);
  const side = c.side || c.pick;
  const market = c.market || c.betType;
  const matchup = c.matchup || (c.awayTeam && c.homeTeam ? `${c.awayTeam} vs. ${c.homeTeam}` : "");
  return {
    side, market, oddsNum, coverProbNum, evNum, matchup,
    commenceTime: c.commenceTime || "",
    sport: c.sport || "NCAAF",
    homeTeam: c.homeTeam, awayTeam: c.awayTeam,
    consensusSpread: c.consensusSpread, consensusSpreadAbs: c.consensusSpreadAbs,
    noVigPrior: c.noVigPrior, odds: oddsNum, coverProb: coverProbNum, pick: side, betType: market,
  };
}
function passesParlayLeg(c) {
  if (!c || !Number.isFinite(c.oddsNum) || !Number.isFinite(c.coverProbNum)) return false;
  if (c.oddsNum >= PARLAY_MAX_PLUS_ODDS) return false;
  if (c.oddsNum < -300) return false;
  if (c.coverProbNum < PARLAY_MIN_COVER) return false;
  if (dogMlRejectReason(c)) return false;
  return true;
}
function parlayMarketPref(c) {
  const m = String(c.market || "").toLowerCase();
  if (m === "total") return 3;
  if (m === "spread") return 2;
  return 1;
}
function assembleCfbParlay(cands, stake, isIndependent) {
  const legs = cands.map(c => ({
    pick: c.side,
    matchup: c.matchup,
    odds: fmtOdds(c.oddsNum),
    betType: c.market,
    sport: "NCAAF",
    commenceTime: c.commenceTime || "",
    coverProb: `${(c.coverProbNum * 100).toFixed(0)}%`,
    ev: typeof c.evNum === "number" && Number.isFinite(c.evNum) ? `${(c.evNum * 100).toFixed(1)}%` : undefined,
  }));
  const s = parlayComboStats(cands);
  const combinedOdds = s.combinedDecimal >= 2
    ? `+${Math.round((s.combinedDecimal - 1) * 100)}`
    : `${Math.round(-100 / (s.combinedDecimal - 1))}`;
  return {
    type: `${legs.length}-leg-parlay-optimized`,
    legs,
    combinedOdds,
    combinedDecimal: +s.combinedDecimal.toFixed(2),
    combinedProb: `${(s.combinedProb * 100).toFixed(1)}%`,
    ev: `${(s.ev * 100).toFixed(1)}%`,
    units: `${stake}u`,
    stake,
    source: isIndependent ? "independent-2v3" : "published-card",
    independent: !!isIndependent,
    uniqueGames: new Set(cands.map(c => (c.matchup || "").toLowerCase().trim())).size,
    _parlayEV: s.ev,
  };
}

// Omega v11.7-style 2-vs-3 optimizer: compare best 2-leg vs best 3-leg by true parlay EV.
// One leg per game. CFB constraints: no +200 legs, coverProb >= 40%, max 1 dog ML.
function buildPublishedParlay(picks, allCands) {
  const stake = parlayUnitsFor(picks);
  const fromCands = (allCands || []).map(toParlayCand).filter(c => c && passesParlayLeg(c));
  const fromPicks = (picks || []).map(toParlayCand).filter(c => c && passesParlayLeg(c));
  const poolSrc = fromCands.length >= 2 ? fromCands : fromPicks;
  const byGame = new Map();
  for (const c of poolSrc) {
    const g = (c.matchup || "").toLowerCase().trim();
    if (!g) continue;
    const prev = byGame.get(g);
    if (!prev) { byGame.set(g, c); continue; }
    const pref = parlayMarketPref(c) - parlayMarketPref(prev);
    const cover = c.coverProbNum - (prev.coverProbNum || 0);
    if (pref > 0 || (pref === 0 && cover > 0)) byGame.set(g, c);
  }
  const scan = [...byGame.values()].sort((a, b) =>
    (parlayMarketPref(b) - parlayMarketPref(a)) || (b.coverProbNum - a.coverProbNum)
  ).slice(0, 12);
  const best2 = bestParlayComboOfSize(scan, 2);
  const best3 = bestParlayComboOfSize(scan, 3);
  const chosen = chooseParlay2or3(best2, best3);
  if (chosen && chosen.length >= 2) {
    const straightSides = new Set((picks || []).map(p => p.pick));
    const isIndependent = !chosen.every(l => straightSides.has(l.side));
    const p = assembleCfbParlay(chosen, stake, isIndependent);
    if (p._parlayEV > 0) {
      console.log(`[cfb-parlay] ${p.type}: ${chosen.map(l => l.side).join(" + ")} | EV ${p.ev}`);
      delete p._parlayEV;
      return [p];
    }
  }
  if (fromPicks.length >= 2) {
    const fallbackScan = [];
    const seen = new Set();
    for (const c of fromPicks) {
      const g = (c.matchup || "").toLowerCase().trim();
      if (!g || seen.has(g)) continue;
      seen.add(g);
      fallbackScan.push(c);
    }
    const fb2 = bestParlayComboOfSize(fallbackScan, 2);
    const fb3 = bestParlayComboOfSize(fallbackScan, 3);
    const fb = chooseParlay2or3(fb2, fb3);
    if (fb && fb.length >= 2) {
      const p = assembleCfbParlay(fb, stake, false);
      if (p._parlayEV > 0) {
        delete p._parlayEV;
        return [p];
      }
    }
  }
  return [];
}

function emptyCard(dateISO, dateFormatted, seasonPhase, noPlays, extras = {}) {
  const noGames = Object.prototype.hasOwnProperty.call(extras, "noGames")
    ? !!extras.noGames
    : /No College Football Games Scheduled/i.test(noPlays || "");
  const card = {
    date: dateISO,
    dateFormatted,
    generatedAt: new Date().toISOString(),
    model: MODEL_VERSION,
    seasonPhase,
    noPlays,
    noGames,
    picks: [],
    rejections: extras.rejections || [],
    parlayLegs: [],
    summary: {
      totalPicks: 0,
      totalUnits: "0u",
      aplusLocks: 0,
      sportsCovered: extras.sportsCovered || [],
    },
  };
  // "No Qualifying Plays Today" headline + short reason (lib/no-plays). Only completed runs call this.
  const reason = extras.reason || sportReason("cfb", { noGames, gamesPriced: extras.gamesPriced || 0 });
  Object.assign(card, noPlaysFields(reason, { noGames }));
  card.edgeSummary = reason;
  card.insights = "";
  return card;
}

// ── Claude narration (narrator ONLY — the model already selected and sized; grounding is
// strictly the provided table, no invented specifics) ──
const CFB_NARRATOR_SYSTEM = `You are THE LOCK — WeBetAI's college football analyst. The statistical model has ALREADY selected and sized these picks. Your only job is to write honest, compelling narratives.

RULES:
- Say "WeBetAI" — never "the model" or "our model".
- Use the EXACT pick string, odds, and calibrated Edge % from the table. Never invent a different line.
- Use ONLY facts in the data (teams, the number we are betting, prices, best-book, records, venue, edge math). No invented player/coach/news.
- coreReasoning: 3-4 sentences arguing FOR the pick side. Start with a concrete supporting fact from the data. End with why the price offers value.
- whatLoses: 1 sentence — the specific scenario that beats the pick.
- clvExpectation: 1 short sentence on expected line movement.
- edgeSummary: 1-2 editorial sentences for the whole card, plain English, no jargon.
- insights: 2-3 sentences explaining today's card construction (markets scanned, why this market won, stake discipline).

Return ONLY valid JSON:
{"narratives":[{"pick":"<exact pick string>","coreReasoning":"...","whatLoses":"...","clvExpectation":"..."}],"edgeSummary":"...","insights":"..."}`;

async function narratePicks(picks, seasonPhase, dateFormatted) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  const fallback = () => {
    for (const p of picks) {
      p.coreReasoning = p.coreReasoning ||
        `WeBetAI scanned every spread, total, and moneyline on the college football slate and ${p.pick} at ${p.odds}${p.bestBook ? ` (${p.bestBook})` : ""} is the best value on this game. Calibrated cover ${p.coverProb} vs break-even at this price, ${p.ev} expected value. Stake is quarter-Kelly sized to the calibrated edge.`;
      p.whatLoses = p.whatLoses || "A game script that runs against the number — a late score or a stalled drive at a key number (3 or 7).";
      p.clvExpectation = p.clvExpectation || (typeof p.predCLV === "number"
        ? `Pick-time Pinnacle predCLV ${(p.predCLV * 100).toFixed(1)}¢ — hold if the close stays near this number.`
        : "Line expected to stay near the consensus number into kickoff.");
    }
    return {
      edgeSummary: `WeBetAI's college football model evaluated every market on today's slate and found its best value on ${picks.map(p => `${p.pick} (${p.odds})`).join(", ")}.`,
      insights: `${picks.length} college football pick${picks.length > 1 ? "s" : ""} today, ${picks.reduce((s, p) => s + parseFloat(p.units), 0)}u total exposure. Discipline: dual floor EV>=3% AND probEdge>=4pp, dog-ML gate, max 1 ML, key-number cover, 2+ major books, Hard Rock preferred, quarter-Kelly, market-anchored projections.`,
    };
  };
  if (!apiKey || !picks.length) return fallback();

  try {
    const table = picks.map(p => ({
      pick: p.pick, matchup: p.matchup, market: p.betType, odds: p.odds, bestBook: p.bestBook,
      units: p.units, rating: p.rating, coverProb: p.coverProb, ev: p.ev, modelEdge: p.modelEdge,
      seasonPhase: p.seasonPhase,
    }));
    const resp = await anthropicFetch({
      model: "claude-sonnet-4-6",
      max_tokens: 2000,
      temperature: 0.3,
      system: CFB_NARRATOR_SYSTEM,
      messages: [{ role: "user", content: `Date: ${dateFormatted}. Season phase: ${seasonPhase}.\nPicks table:\n${JSON.stringify(table, null, 2)}` }],
    });
    if (!resp || !resp.ok) { console.log(`[cfb] Narrator unavailable (${resp ? resp.status : "timeout"}) — using fallback`); return fallback(); }
    const data = await resp.json();
    const text = (data.content || []).map(b => b.text || "").join("");
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return fallback();
    const parsed = JSON.parse(jsonMatch[0]);
    for (const p of picks) {
      const n = (parsed.narratives || []).find(x => x.pick === p.pick) || (parsed.narratives || [])[0];
      if (n) {
        p.coreReasoning = n.coreReasoning || "";
        p.whatLoses = n.whatLoses || "";
        p.clvExpectation = n.clvExpectation || "";
      }
    }
    const fb = fallback(); // fills any narrative Claude left empty + default summaries
    return { edgeSummary: parsed.edgeSummary || fb.edgeSummary, insights: parsed.insights || fb.insights };
  } catch (e) {
    console.log(`[cfb] Narration error: ${e.message} — using fallback`);
    return fallback();
  }
}

// ── Storage (REST blob API, mirrors alpha/NFL incl. the v10.4 overwrite guard) ──
async function storePicks(dateISO, picksData, force, opts = {}) {
  const token = process.env.NETLIFY_AUTH_TOKEN;
  if (!token) { console.error("[cfb] NETLIFY_AUTH_TOKEN not set, cannot store picks"); return false; }
  const storeUrl = `https://api.netlify.com/api/v1/blobs/${SITE_ID}/${STORE_NAME}`;
  const auth = { "Authorization": `Bearer ${token}` };

  // Overwrite guard: a scheduled card is protected; force:true carries settled results forward.
  try {
    const existResp = await fetch(`${storeUrl}/picks-${dateISO}`, { headers: auth });
    if (existResp.ok) {
      const existing = await existResp.json();
      const existingPicks = Array.isArray(existing?.picks) ? existing.picks : [];
      if (existingPicks.length > 0 && !force) {
        console.error(`[cfb-guard] REFUSING overwrite: picks-${dateISO} already holds ${existingPicks.length} pick(s). POST with {"force":true} to override.`);
        return false;
      }
      if (existingPicks.length > 0) {
        const resMap = new Map(existingPicks.filter(p => p.result && p.result !== "pending").map(p => [`${p.pick}||${p.matchup}`, p]));
        for (const p of (picksData.picks || [])) {
          const prev = resMap.get(`${p.pick}||${p.matchup}`);
          if (prev && (!p.result || p.result === "pending")) {
            p.result = prev.result; p.profit = prev.profit;
            p.finalScore = prev.finalScore || null; p.settledAt = prev.settledAt || null;
          }
        }
      }
    }
  } catch (e) {
    console.log(`[cfb-guard] Existence check failed (${e.message}) — proceeding`);
  }

  try {
    const put = await fetch(`${storeUrl}/picks-${dateISO}`, {
      method: "PUT",
      headers: { ...auth, "Content-Type": "application/json" },
      body: JSON.stringify(picksData),
    });
    if (!put.ok) { console.error(`[cfb] Blob PUT failed ${put.status}: ${(await put.text()).slice(0, 200)}`); return false; }

    await fetch(`${storeUrl}/latest-date`, {
      method: "PUT", headers: { ...auth, "Content-Type": "text/plain" }, body: dateISO,
    });

    let dates = [];
    try {
      const dResp = await fetch(`${storeUrl}/picks-dates`, { headers: auth });
      if (dResp.ok) dates = await dResp.json();
    } catch (e) {}
    if (!Array.isArray(dates)) dates = [];
    // Off-day "no games" blobs update latest-date (so /cfb is never stale) but stay off
    // picks-dates so the track record is not padded with every off day.
    if (opts.indexDates !== false && !dates.includes(dateISO)) {
      dates.push(dateISO); dates.sort();
      await fetch(`${storeUrl}/picks-dates`, {
        method: "PUT", headers: { ...auth, "Content-Type": "application/json" }, body: JSON.stringify(dates),
      });
    }
    console.log(`[cfb] Picks stored to ${STORE_NAME}/picks-${dateISO}`);
    return true;
  } catch (e) {
    console.error(`[cfb] Blob store error: ${e.message}`);
    return false;
  }
}

// ── Main ──
exports.handler = async (event) => {
  const started = Date.now();
  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch (e) {}
  const force = !!body.force;
  const dryRun = !!body.dryRun;
  const dateISO = (typeof body.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date)) ? body.date : getEasternDateToday();
  const dateFormatted = formatDateLong(dateISO);
  console.log(`[cfb] ${MODEL_VERSION} run for ${dateISO} (scheduled:${!!body.scheduled} force:${force} dryRun:${dryRun})`);

  const cfg = PHASE_CONFIG.regular;
  const { games: espnGames, seasonPhase } = await fetchESPNSlate(dateISO);
  const espnPreGames = espnGames.filter(g => g.state === "pre");
  if (!espnPreGames.length) {
    console.log(`[cfb] No CFB pre-game slate on ${dateISO} (ET) — writing no-games card.`);
    const noGames = emptyCard(dateISO, dateFormatted, seasonPhase, NO_GAMES_MSG);
    if (!dryRun) await storePicks(dateISO, noGames, force, { indexDates: false });
    return { statusCode: 200, body: JSON.stringify({ ok: true, skipped: "no CFB games today", stored: !dryRun }) };
  }
  console.log(`[cfb] ${espnPreGames.length} CFB pre-game(s) today (${espnGames.length} ESPN total) · phase=${seasonPhase}`);

  const [ratingOverlay, qbAdj] = await Promise.all([fetchLiveRatingOverlay(), fetchQbAdjustments()]);

  const oddsGames = await fetchCFBOdds(dateISO);
  if (!oddsGames.length) {
    // Feed failure, not a pass: write nothing so the previous card stays up until a run completes.
    console.log(`[cfb] ESPN shows games but no odds available — NOT storing (previous card stays up).`);
    return { statusCode: 503, body: JSON.stringify({ ok: false, picks: 0, stored: false, error: "no CFB odds available" }) };
  }

  // Consensus + candidates per game
  const allCands = [];
  const nowMs = Date.now();
  for (const g of oddsGames) {
    const consensus = buildGameConsensus(g);
    if (consensus.bookCount < 3) { console.log(`[cfb] ${g.away_team} @ ${g.home_team}: only ${consensus.bookCount} books — skipping`); continue; }
    // Match against FULL ESPN slate (incl. delayed/in/post) so we can hard-skip non-pre.
    const espnGame = findESPNGame(espnGames, consensus.home, consensus.away);
    if (!espnGame) {
      console.log(`[cfb] Skip (no ESPN match): ${g.away_team} @ ${g.home_team}`);
      continue;
    }
    const statusName = String(espnGame.statusName || "");
    const delayed = /DELAYED/i.test(statusName) || /delayed/i.test(String(espnGame.statusDetail || ""));
    if (espnGame.state !== "pre" || delayed) {
      console.log(`[cfb] Skip (ESPN ${espnGame.state}${delayed ? "/delayed" : ""}): ${g.away_team} @ ${g.home_team} — Odds commence ${g.commence_time}, ESPN ${espnGame.espnCommence || espnGame.date}`);
      continue;
    }
    // Prefer earlier of Odds commence vs ESPN date — Odds often lags delayed kickoffs.
    const oddsKick = Date.parse(g.commence_time);
    const espnKick = Date.parse(espnGame.espnCommence || espnGame.date || "");
    const kick = [oddsKick, espnKick].filter(Number.isFinite);
    const earliest = kick.length ? Math.min(...kick) : NaN;
    if (Number.isFinite(earliest) && earliest <= nowMs) {
      console.log(`[cfb] Candidate skip already started: ${g.away_team} @ ${g.home_team} (earliest kick ${new Date(earliest).toISOString()})`);
      continue;
    }
    const cands = computeCandidates(consensus, espnGame, cfg, ratingOverlay, qbAdj);
    if (cands.length) {
      console.log(`[cfb] ${g.away_team} @ ${g.home_team}: consensus ${consensus.home} ${fmtSigned(consensus.consensusSpread ?? 0)} / total ${consensus.consensusTotal} · ${cands.length} candidate(s)`);
      for (const cand of cands) console.log(`[cfb]   ${cand.market}: ${cand.side} ${fmtOdds(cand.odds)} @ ${cand.book} — cover ${(cand.coverProb * 100).toFixed(1)}%, EV ${(cand.ev * 100).toFixed(1)}%, probEdge ${(candProbEdge(cand) * 100).toFixed(1)}pp`);
    }
    allCands.push(...cands);
  }

  if (!allCands.length) {
    console.log("[cfb] No positive-EV candidates on the slate — writing no-plays card.");
    const noPlaysData = emptyCard(dateISO, dateFormatted, seasonPhase, NO_EDGE_MSG, {
      noGames: false,
      gamesPriced: espnPreGames.length,
      sportsCovered: ["NCAAF"],
    });
    if (!dryRun) await storePicks(dateISO, noPlaysData, force);
    return { statusCode: 200, body: JSON.stringify({ ok: true, picks: 0 }) };
  }

  // Selection + floors
  const { picks: selected, lean } = selectPicks(allCands, cfg);
  const picks = buildFinalPicks(selected, lean, seasonPhase);

  // Rejections: everything considered but not shipped (transparency, mirrors alpha card)
  const pickSides = new Set(picks.map(p => p.pick));
  const rejections = [];
  const byGameBest = new Map();
  for (const cand of allCands) {
    const key = `${cand.awayTeam} vs. ${cand.homeTeam}`;
    if (!byGameBest.has(key) || cand.ev > byGameBest.get(key).ev) byGameBest.set(key, cand);
  }
  for (const [matchup, cand] of byGameBest) {
    if (pickSides.has(cand.side)) continue;
    rejections.push({
      matchup,
      side: cand.side,
      reason: rejectionReason(cand, cfg),
    });
  }

  // Candidates existed (ESPN slate was non-empty) but selection/floors yielded nothing.
  // Must store a no-plays card — a normal empty-picks blob has no noPlays and /cfb
  // falls back to the false "no games scheduled" empty state.
  if (!picks.length) {
    console.log("[cfb] Candidates existed but none cleared selection floors — writing no-plays card.");
    const noEdge = emptyCard(dateISO, dateFormatted, seasonPhase, NO_EDGE_MSG, {
      noGames: false,
      gamesPriced: espnPreGames.length,
      sportsCovered: ["NCAAF"],
      rejections: rejections.slice(0, 12),
      insights: "WeBetAI scanned today's college football slate. Games are scheduled, but none cleared the edge filters. Passed rather than force a lean.",
      edgeSummary: NO_EDGE_MSG,
    });
    if (dryRun) {
      console.log("[cfb] DRY RUN — nothing stored.");
      return { statusCode: 200, body: JSON.stringify({ ok: true, dryRun: true, picks: 0, picksData: noEdge }) };
    }
    const stored = await storePicks(dateISO, noEdge, force);
    console.log(`[cfb] Done in ${((Date.now() - started) / 1000).toFixed(1)}s (stored: ${stored}, no qualifying plays)`);
    return { statusCode: 200, body: JSON.stringify({ ok: true, picks: 0, stored }) };
  }

  // Narration (Claude narrator ONLY — JS already selected/sized; deterministic fallback)
  const { edgeSummary, insights } = await narratePicks(picks, seasonPhase, dateFormatted);

  const totalUnits = picks.reduce((s, p) => s + parseFloat(p.units), 0);
  const picksData = {
    date: dateISO,
    dateFormatted,
    generatedAt: new Date().toISOString(),
    model: MODEL_VERSION,
    seasonPhase,
    picks,
    rejections: rejections.slice(0, 12),
    parlayLegs: buildPublishedParlay(picks, allCands),
    summary: {
      totalPicks: picks.length,
      totalUnits: `${parseFloat(totalUnits.toFixed(2))}u`,
      aplusLocks: picks.filter(p => p.rating === "A+").length,
      sportsCovered: ["NCAAF"],
    },
    edgeSummary,
    insights,
  };

  console.log(`[cfb] Card: ${picks.map(p => `${p.pick} ${p.odds} (${p.units}, ${p.rating})`).join(" | ")}`);
  if (dryRun) {
    console.log("[cfb] DRY RUN — nothing stored.");
    return { statusCode: 200, body: JSON.stringify({ ok: true, dryRun: true, picksData }) };
  }

  const stored = await storePicks(dateISO, picksData, force);
  console.log(`[cfb] Done in ${((Date.now() - started) / 1000).toFixed(1)}s (stored: ${stored})`);
  return { statusCode: 200, body: JSON.stringify({ ok: true, picks: picks.length, stored }) };
};

// ── Offline-test hooks (Netlify only invokes exports.handler; these let a local harness
// exercise the math with no network) ──
module.exports.MODEL_VERSION = MODEL_VERSION;
module.exports.buildGameConsensus = buildGameConsensus;
module.exports.computeCandidates = computeCandidates;
module.exports.selectPicks = selectPicks;
module.exports.buildFinalPicks = buildFinalPicks;
module.exports.buildPublishedParlay = buildPublishedParlay;
module.exports.emptyCard = emptyCard;
module.exports.NO_GAMES_MSG = NO_GAMES_MSG;
module.exports.NO_EDGE_MSG = NO_EDGE_MSG;
module.exports.noVigProb = noVigProb;
module.exports.weightedMedian = weightedMedian;
module.exports.cfbTeamsMatch = cfbTeamsMatch;
module.exports.schoolKey = schoolKey;
module.exports.PHASE_CONFIG = PHASE_CONFIG;
module.exports.impliedProb = impliedProb;
module.exports.dogMlRejectReason = dogMlRejectReason;
module.exports.candProbEdge = candProbEdge;
module.exports.rankScore = rankScore;
module.exports.chooseParlay2or3 = chooseParlay2or3;
module.exports.parlayComboStats = parlayComboStats;
module.exports.HOME_DOG_ML_RANK_PENALTY = HOME_DOG_ML_RANK_PENALTY;
module.exports.CONV_PROB_EDGE_FLOOR = CONV_PROB_EDGE_FLOOR;
module.exports.LEAN_PROB_EDGE_FLOOR = LEAN_PROB_EDGE_FLOOR;
module.exports.LEAN_UNITS = LEAN_UNITS;
