// get-results-omega.js
// Returns combined pick history for /alpha track record:
//   - Alpha picks for dates in edge-picks-omega store
//   - Beta picks for dates before alpha started (pre-alpha history)
//   - 0-0 placeholder rows for dates with no picks in either pipeline

const { fetchESPNScores } = require('./lib/espn-scoreboard');
const { cacheIsFresh, cacheControlFor } = require('./lib/kpi-cache');
const { resolveDoubleheader, inheritCommenceTime } = require('../../js/live-score');

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json',
};

const RESULTS_CACHE_KEY = 'results-omega-cache-v8-allver';

function getEasternDateToday() {
  const et = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const y = et.getFullYear();
  const m = String(et.getMonth() + 1).padStart(2, '0');
  const d = String(et.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getAllDatesInRange(startDate, endDate) {
  const dates = [];
  const current = new Date(startDate + 'T12:00:00Z');
  const end = new Date(endDate + 'T12:00:00Z');
  while (current <= end) {
    dates.push(current.toISOString().slice(0, 10));
    current.setUTCDate(current.getUTCDate() + 1);
  }
  return dates;
}

function normalizeTeam(name) {
  return (name || '').toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
}

function schoolKey(name) {
  const parts = normalizeTeam(name).split(' ');
  return parts.length > 1 ? parts.slice(0, -1).join(' ') : (parts[0] || '');
}

function teamsMatch(pickTeam, espnTeam, espnAbbr, sport) {
  const p = normalizeTeam(pickTeam);
  const e = normalizeTeam(espnTeam);
  if (!p || !e) return false;
  if (p === e) return true;
  if (p.includes(e) || e.includes(p)) return true;
  if (espnAbbr && espnAbbr.length >= 2) {
    const a = espnAbbr.toLowerCase();
    const pWords = p.split(' ');
    if (pWords.includes(a)) return true;
  }
  if (sport === 'NCAAF') {
    const pS = schoolKey(pickTeam), eS = schoolKey(espnTeam);
    if (pS.length > 2 && pS === eS) return true;
    return false;
  }
  const pLast = p.split(' ').pop();
  const eLast = e.split(' ').pop();
  if (pLast.length > 2 && pLast === eLast) return true;
  return false;
}

// Shared DH rule: js/live-score.js (clear commenceTime, else in/post over a skewed pre).
function disambiguateDoubleheader(matches, pick) {
  return resolveDoubleheader(matches, pick);
}

function findGame(pick, games) {
  const sport = pick.sport || '';
  const ncaaf = sport === 'NCAAF';
  const matchup = (pick.matchup || '').toLowerCase();
  const matchupParts = matchup.split(/\s+(?:@|vs\.?|at|v)\s+/i).map(s => s.trim()).filter(Boolean);
  const primary = [];
  for (const g of games) {
    const awayKey = ncaaf ? schoolKey(g.awayTeam) : normalizeTeam(g.awayTeam).split(' ').pop();
    const homeKey = ncaaf ? schoolKey(g.homeTeam) : normalizeTeam(g.homeTeam).split(' ').pop();
    const awayMatch = matchupParts.some(part => teamsMatch(part, g.awayTeam, g.awayAbbr, sport)) ||
                       (awayKey.length > (ncaaf ? 2 : 3) && matchup.includes(awayKey));
    const homeMatch = matchupParts.some(part => teamsMatch(part, g.homeTeam, g.homeAbbr, sport)) ||
                       (homeKey.length > (ncaaf ? 2 : 3) && matchup.includes(homeKey));
    if (awayMatch && homeMatch) primary.push(g);
  }
  if (primary.length) return disambiguateDoubleheader(primary, pick);
  const pickTeam = (pick.pick || '').replace(/[+-]\d.*$/, '').replace(/ML$/i, '').replace(/\b(Over|Under)\b/gi, '').trim();
  if (pickTeam) {
    const secondary = [];
    for (const g of games) {
      const awayHit = teamsMatch(pickTeam, g.awayTeam, g.awayAbbr, sport);
      const homeHit = teamsMatch(pickTeam, g.homeTeam, g.homeAbbr, sport);
      if (awayHit || homeHit) {
        const otherKey = ncaaf
          ? schoolKey(awayHit ? g.homeTeam : g.awayTeam)
          : normalizeTeam(awayHit ? g.homeTeam : g.awayTeam).split(' ').pop();
        if (otherKey.length > (ncaaf ? 2 : 3) && matchup.includes(otherKey)) secondary.push(g);
      }
    }
    if (secondary.length) return disambiguateDoubleheader(secondary, pick);
  }
  if (matchupParts.length >= 2) {
    const tertiary = [];
    for (const g of games) {
      const awayKey = ncaaf ? schoolKey(g.awayTeam) : normalizeTeam(g.awayTeam).split(' ').pop();
      const homeKey = ncaaf ? schoolKey(g.homeTeam) : normalizeTeam(g.homeTeam).split(' ').pop();
      const part0 = ncaaf ? schoolKey(matchupParts[0]) : normalizeTeam(matchupParts[0]);
      const part1 = ncaaf ? schoolKey(matchupParts[1]) : normalizeTeam(matchupParts[1]);
      if ((part0.includes(awayKey) || awayKey.includes(part0)) &&
          (part1.includes(homeKey) || homeKey.includes(part1))) tertiary.push(g);
      else if ((part0.includes(homeKey) || homeKey.includes(part0)) &&
          (part1.includes(awayKey) || awayKey.includes(part1))) tertiary.push(g);
    }
    if (tertiary.length) return disambiguateDoubleheader(tertiary, pick);
  }
  return null;
}

// Parlay legs are stored WITHOUT commenceTime, so on a doubleheader date findGame falls back to the
// opener and settles the leg against the wrong final — the straight bet (which HAS commenceTime)
// grades correctly while the identical parlay leg does not. Inherit the start time from the straight
// pick naming the same matchup + selection so both sides resolve to the same game.
function withLegCommenceTime(leg, picks) {
  return inheritCommenceTime(leg, picks);
}

function gradePick(pick, game) {
  if (!game || game.state !== 'post') return 'pending';
  // Postponed / canceled games are voided by every major US book (no action) — the stake is
  // returned, so we grade them as a push. A push leg is dropped from a parlay and the ticket
  // reprices on the surviving legs (see gradeParlay). ESPN marks these state:'post' with
  // completed:false, so they must be caught BEFORE any score-based grading (0-0 → false "under").
  if (/POSTPONED|CANCELL?ED/i.test(game.statusName) || (game.state === 'post' && !game.completed)) return 'push';
  const pickStr = (pick.pick || '').trim();
  const betType = (pick.betType || '').toLowerCase();
  // First-Five-Innings picks settle on the first-5 score, NOT the full game.
  const isF5 = /\bf5\b|first 5|1st 5|first-5/i.test(pickStr) || betType.includes('f5') || /^f5\b/i.test(pickStr);
  let awayScore = game.awayScore;
  let homeScore = game.homeScore;
  if (isF5) {
    const aL = game.awayLine || [], hL = game.homeLine || [];
    if (aL.length < 5 || hL.length < 5) return 'pending'; // not enough innings to settle F5
    awayScore = aL.slice(0, 5).reduce((a, b) => a + b, 0);
    homeScore = hL.slice(0, 5).reduce((a, b) => a + b, 0);
  }
  const pickTeamRaw = pickStr.replace(/[+-]\d+(\.\d+)?/g, '').replace(/ML$/i, '').replace(/\b(Over|Under)\b/gi, '').trim();
  const pickedAway = teamsMatch(pickTeamRaw, game.awayTeam, game.awayAbbr, pick.sport);
  const pickedHome = teamsMatch(pickTeamRaw, game.homeTeam, game.homeAbbr, pick.sport);

  if (betType === 'total' || /over|under/i.test(pickStr)) {
    const totalPoints = awayScore + homeScore;
    const lineMatch = pickStr.match(/(over|under)\s*([\d.]+)/i);
    if (lineMatch) {
      const ou = lineMatch[1].toLowerCase();
      const line = parseFloat(lineMatch[2]);
      if (totalPoints === line) return 'push';
      const over = totalPoints > line;
      return (ou === 'over' && over) || (ou === 'under' && !over) ? 'win' : 'loss';
    }
  }
  if (betType === 'spread' || betType === 'puck line' || /[+-]\d+(\.\d+)?/.test(pickStr)) {
    const spreadMatch = pickStr.match(/([+-]\d+(\.\d+)?)/);
    if (spreadMatch && (pickedAway || pickedHome)) {
      const spread = parseFloat(spreadMatch[1]);
      const pickedScore = pickedAway ? awayScore : homeScore;
      const oppScore = pickedAway ? homeScore : awayScore;
      const adjusted = pickedScore + spread;
      if (adjusted === oppScore) return 'push';
      return adjusted > oppScore ? 'win' : 'loss';
    }
  }
  if (pickedAway || pickedHome) {
    const pickedScore = pickedAway ? awayScore : homeScore;
    const oppScore = pickedAway ? homeScore : awayScore;
    if (pickedScore === oppScore) return 'push';
    return pickedScore > oppScore ? 'win' : 'loss';
  }
  if (/draw/i.test(pickStr)) return awayScore === homeScore ? 'win' : 'loss';
  return 'pending';
}

function calcWinnings(atRisk, oddsStr) {
  const odds = parseInt((oddsStr || '').replace(/[^0-9+-]/g, ''));
  if (isNaN(odds) || !atRisk) return 0;
  if (odds > 0) return atRisk * (odds / 100);
  return atRisk * (100 / Math.abs(odds));
}

function calcParlayWinnings(risk, legsOdds) {
  let decimalProduct = 1;
  for (const oddsStr of legsOdds) {
    const odds = parseInt((oddsStr || '-110').replace(/[^0-9+-]/g, ''));
    if (isNaN(odds)) { decimalProduct *= 1.909; continue; }
    decimalProduct *= odds > 0 ? (odds / 100) + 1 : (100 / Math.abs(odds)) + 1;
  }
  return risk * (decimalProduct - 1);
}

// Whole-dollar display: round UP to the next dollar so no cents show (37.5 -> 38). The -1e-9
// keeps an already-whole amount whole (avoids 75 -> 76 on float dust).
function wholeUp(n) { return Math.ceil((n || 0) - 1e-9); }

function gradeParlay(pickResults, parlayRisk) {
  // v10.4.3: parlays can now be 2-leg (totals-first construction drops -CLV ML legs), so grade
  // any ticket with >=2 legs. Historical 3-leg tickets are unaffected.
  if (pickResults.length < 2) return { result: 'skip', profit: 0 };
  const results = pickResults.map(p => p.result);
  const anyLoss = results.includes('loss');
  const anyPending = results.includes('pending');
  const allWin = results.every(r => r === 'win');
  if (anyLoss) return { result: 'loss', profit: -parlayRisk };
  if (anyPending) return { result: 'pending', profit: 0 };
  if (allWin) return { result: 'win', profit: wholeUp(calcParlayWinnings(parlayRisk, pickResults.map(p => p.odds))) };
  const nonPushLegs = pickResults.filter(p => p.result !== 'push');
  if (nonPushLegs.length === 0) return { result: 'push', profit: 0 };
  const allNonPushWin = nonPushLegs.every(p => p.result === 'win');
  if (allNonPushWin) return { result: 'win', profit: wholeUp(calcParlayWinnings(parlayRisk, nonPushLegs.map(p => p.odds))) };
  return { result: 'pending', profit: 0 };
}

async function getDatesFromStore(storeUrl, authHeaders) {
  let dates = [];
  try {
    const datesResp = await fetch(`${storeUrl}/picks-dates`, { headers: authHeaders });
    if (datesResp.ok) dates = await datesResp.json();
  } catch (e) {}
  if (!Array.isArray(dates) || dates.length === 0) {
    try {
      const latestResp = await fetch(`${storeUrl}/latest-date`, { headers: authHeaders });
      if (latestResp.ok) {
        const latest = (await latestResp.text()).trim();
        if (latest) dates = [latest];
      }
    } catch (e) {}
  }
  return Array.isArray(dates) ? dates : [];
}

async function gradeDay(dateISO, picksData) {
  const picks = (picksData.picks || []).slice(0, 3);
  if (picks.length === 0) return null;

  const apiParlay = (picksData.parlayLegs && picksData.parlayLegs.length > 0) ? picksData.parlayLegs[0] : null;
  const optimizedLegs = (apiParlay && apiParlay.legs) ? apiParlay.legs : null;

  const sports = [...new Set([
    ...picks.map(p => p.sport),
    ...(optimizedLegs ? optimizedLegs.map(l => l.sport) : []),
  ].filter(Boolean))];

  const sportResults = await Promise.all(sports.map(async sport => {
    const games = await fetchESPNScores(dateISO, sport);
    games.forEach(g => { g._sport = sport; });
    return games;
  }));
  const scoresByGames = sportResults.flat();

  const dollarPerUnit = 150;
  let dayWins = 0, dayLosses = 0, dayPushes = 0, dayPending = 0;
  let dayWagered = 0, dayProfit = 0;
  const gradedPicks = [];

  for (const pick of picks) {
    const sportGames = scoresByGames.filter(g => g._sport === pick.sport);
    const game = findGame(pick, sportGames);
    const result = gradePick(pick, game);
    const units = parseFloat(pick.units) || 1;
    const risk = wholeUp(units * dollarPerUnit);
    const winAmount = wholeUp(calcWinnings(risk, pick.odds || '-110'));
    let profit = 0;
    if (result === 'win') { dayWins++; profit = winAmount; }
    else if (result === 'loss') { dayLosses++; profit = -risk; }
    else if (result === 'push') { dayPushes++; profit = 0; }
    else { dayPending++; }
    // Pushes return the stake (no action) — exclude from wagered so ROI isn't diluted.
    // (profit is already 0 for push/pending, so dayProfit is unaffected either way.)
    if (result === 'win' || result === 'loss') { dayWagered += risk; dayProfit += profit; }
    const isF5Pick = /\bf5\b|first 5|1st 5|first-5/i.test(pick.pick || '') || (pick.betType || '').toLowerCase().includes('f5');
    let scoreStr = null;
    if (game && game.state === 'post' && result === 'push' && (/POSTPONED|CANCELL?ED/i.test(game.statusName) || !game.completed)) {
      scoreStr = 'PPD';
    } else if (game && game.state === 'post') {
      if (isF5Pick && (game.awayLine || []).length >= 5 && (game.homeLine || []).length >= 5) {
        scoreStr = `${game.awayLine.slice(0, 5).reduce((a, b) => a + b, 0)}-${game.homeLine.slice(0, 5).reduce((a, b) => a + b, 0)} (F5)`;
      } else {
        scoreStr = `${game.awayScore}-${game.homeScore}`;
      }
    }
    gradedPicks.push({ sport: pick.sport, matchup: pick.matchup, pick: pick.pick, odds: pick.odds, units: pick.units, rating: pick.rating, result, profit: Math.round(profit), score: scoreStr });
  }

  let parlayInput;
  if (optimizedLegs) {
    parlayInput = optimizedLegs.map(leg => {
      const eleg = withLegCommenceTime(leg, picks);
      const sportGames = scoresByGames.filter(g => g._sport === eleg.sport);
      const game = findGame(eleg, sportGames);
      return { result: gradePick(eleg, game), odds: eleg.odds || '-110' };
    });
  } else {
    parlayInput = gradedPicks.map(gp => ({ result: gp.result, odds: gp.odds || '-110' }));
  }
  // Parlay stake drops to 0.25u whenever a lean pick is on the card, else 0.5u.
  const anyLean = picks.some(p => p.thinSlate);
  const parlayUnits = anyLean ? 0.25 : 0.5;
  const parlayRisk = wholeUp(parlayUnits * dollarPerUnit);
  const parlayResult = gradeParlay(parlayInput, parlayRisk);
  if (parlayResult.result !== 'pending' && parlayResult.result !== 'skip') {
    dayWagered += parlayRisk;
    dayProfit += parlayResult.profit;
  }
  if (parlayResult.result !== 'skip') {
    const parlayLegsSource = optimizedLegs || picks;
    gradedPicks.push({ sport: 'PARLAY', matchup: parlayLegsSource.map(p => (p.pick || '').split(/\s/)[0]).join(' / '), pick: `${parlayInput.length}-Team Parlay${optimizedLegs ? ' (Optimized)' : ''}`, odds: '', units: `${parlayUnits}u`, rating: 'P', result: parlayResult.result, profit: parlayResult.profit, score: null });
  }

  const decided = dayWins + dayLosses;
  return {
    date: dateISO,
    dateFormatted: picksData.dateFormatted || dateISO,
    source: picksData._source || 'omega',
    noPlays: false,
    picks: gradedPicks,
    wins: dayWins, losses: dayLosses, pushes: dayPushes, pending: dayPending,
    accuracy: decided > 0 ? ((dayWins / decided) * 100).toFixed(0) : '0',
    wagered: Math.round(dayWagered), profit: Math.round(dayProfit),
    roi: dayWagered > 0 ? ((dayProfit / dayWagered) * 100).toFixed(1) : '--',
    parlayResult: parlayResult.result, parlayProfit: parlayResult.profit, parlayRisk,
  };
}

// ── All-versions KPI helpers (2026-09-26) ──
const OMEGA_KPI_START = "2026-09-22";
let LEGACY = { days: [] };
try { LEGACY = require('./lib/kpi-legacy-alpha.json'); } catch (e) { console.error('[get-results-omega] legacy KPI file missing'); }

function legacyDaysBefore(floor) {
  return (LEGACY.days || []).filter(d => d.date < floor).slice().sort((a, b) => (a.date < b.date ? -1 : 1));
}

function pct(n, d) { return d > 0 ? ((n / d) * 100).toFixed(1) + '%' : '0%'; }

// Same rules the Omega page has always used: Record/Accuracy = straight picks (pushes excluded);
// P/L + ROI = all bets (straights + parlay).
function aggregateDays(list) {
  let cw = 0, cl = 0, cp = 0, cpe = 0, cwag = 0, cpr = 0;
  let sw = 0, sl = 0, swag = 0, spr = 0;
  let pw = 0, pl = 0, pwag = 0, ppr = 0;
  for (const day of list) {
    cw += day.wins || 0; cl += day.losses || 0; cp += day.pushes || 0; cpe += day.pending || 0;
    cwag += day.wagered || 0; cpr += day.profit || 0;
    for (const p of (day.picks || [])) {
      if (p.sport === 'PARLAY' || p.result === 'pending' || p.result === 'push') continue;
      swag += wholeUp((parseFloat(p.units) || 1) * 150);
      spr += p.profit || 0;
      if (p.result === 'win') sw++; else if (p.result === 'loss') sl++;
    }
    if (day.parlayResult && day.parlayResult !== 'skip' && day.parlayResult !== 'pending') {
      pwag += (day.parlayRisk || 75); ppr += day.parlayProfit || 0;
      if (day.parlayResult === 'win') pw++; else if (day.parlayResult === 'loss') pl++;
    }
  }
  return {
    cumulative: {
      wins: cw, losses: cl, pushes: cp, pending: cpe,
      accuracy: pct(cw, cw + cl),
      roi: cwag > 0 ? ((cpr / cwag) * 100).toFixed(1) + '%' : '0%',
      totalWagered: Math.round(cwag), totalProfit: Math.round(cpr),
    },
    straight: { wins: sw, losses: sl, accuracy: pct(sw, sw + sl), totalWagered: Math.round(swag), totalProfit: Math.round(spr) },
    parlay: { wins: pw, losses: pl, accuracy: pct(pw, pw + pl), totalWagered: Math.round(pwag), totalProfit: Math.round(ppr) },
  };
}

function flatSummary(list) {
  const a = aggregateDays(list);
  return {
    days: list.length,
    wins: a.straight.wins, losses: a.straight.losses, pushes: a.cumulative.pushes, pending: a.cumulative.pending,
    accuracy: a.straight.accuracy, profit: a.cumulative.totalProfit, wagered: a.cumulative.totalWagered, roi: a.cumulative.roi,
    parlayWins: a.parlay.wins, parlayLosses: a.parlay.losses,
  };
}

function shiftDate(iso, deltaDays) {
  const d = new Date(iso + 'T12:00:00Z');
  d.setUTCDate(d.getUTCDate() + deltaDays);
  return d.toISOString().slice(0, 10);
}

// Last N ET calendar days including today.
function aggregateWindow(list, n) {
  const today = getEasternDateToday();
  const from = shiftDate(today, -(n - 1));
  return { from, through: today, ...flatSummary(list.filter(d => d.date >= from && d.date <= today)) };
}

// Newest month first, current month included (it can overlap the 30-day window).
function monthlyTotals(list) {
  const byMonth = new Map();
  for (const d of list) {
    const m = d.date.slice(0, 7);
    if (!byMonth.has(m)) byMonth.set(m, []);
    byMonth.get(m).push(d);
  }
  return [...byMonth.keys()].sort().reverse().map(m => {
    const label = new Date(m + '-15T12:00:00Z').toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' });
    return { month: m, label, ...flatSummary(byMonth.get(m)) };
  });
}

// ?range=7 (default, page load) | 30 (dropdown) | all. Totals/months are always included and tiny;
// only the per-day pick rows are trimmed, which is what keeps the first paint light.
function respond(full, event) {
  const params = (event && event.queryStringParameters) || {};
  const range = params.range === 'all' ? 'all' : (params.range === '30' ? 30 : 7);
  let days = full.days || [];
  if (range !== 'all') {
    const from = shiftDate(getEasternDateToday(), -(range - 1));
    days = days.filter(d => d.date >= from);
  }
  const body = { ...full, days, range: String(range), totalDays: (full.days || []).length };
  return { statusCode: 200, headers: { ...CORS, 'Cache-Control': cacheControlFor(full) }, body: JSON.stringify(body) };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS, body: '' };
  }

  try {
    const SITE_ID = process.env.SITE_ID || '87d7bcd9-e95a-479c-bc44-6432a2ffc606';
    const token = process.env.NETLIFY_AUTH_TOKEN;
    if (!token) {
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ error: true, message: 'Not configured' }) };
    }

    const authHeaders = { 'Authorization': `Bearer ${token}` };
    const alphaStoreUrl = `https://api.netlify.com/api/v1/blobs/${SITE_ID}/edge-picks-omega`;

    // Adaptive cache: 30s while any pick is pending (settle promptly after final),
    // 5 min once the ET day is fully decided. v3 busts the pre-NFL/NCAAF endpoint cache.
    try {
      const cacheResp = await fetch(`${alphaStoreUrl}/${RESULTS_CACHE_KEY}`, { headers: authHeaders });
      if (cacheResp.ok) {
        const cached = await cacheResp.json();
        if (cacheIsFresh(cached, event)) {
          return respond(cached, event);
        }
      }
    } catch (e) {}

    // OMEGA: KPIs reset to start 2026-09-22 for v12.0.0-omega-vnext-clv cutover.
    // Omega store ONLY — no alpha/beta back-merge. Daily + cumulative ignore any pre-floor blob dates.
    // Optional ?from=YYYY-MM-DD can raise the floor further; default stays 2026-09-22 (v12 MAIN reset).
    const params = event.queryStringParameters || {};
    const KPI_START = OMEGA_KPI_START; // "2026-09-22" — Omega store floor; earlier dates come from the frozen legacy file
    const alphaDatesRaw = await getDatesFromStore(alphaStoreUrl, authHeaders);
    const alphaDates = alphaDatesRaw.filter(d => d >= KPI_START);

    const alphaDateSet = new Set(alphaDates);
    const betaDateSet = new Set();

    // Build lookup: date → {store, url}
    const picksLookup = new Map(
      alphaDates.map(d => [d, { store: 'omega', url: alphaStoreUrl }])
    );

    // Enumerate every calendar date from the Omega epoch to today (ET)
    const earliestDate = OMEGA_KPI_START;
    const todayET = getEasternDateToday();
    const fullDateRange = getAllDatesInRange(earliestDate, todayET);


    // PERF (2026-06-18): grade all dates in PARALLEL — was sequential await per date (~15s cold for
    // ~19 days). ESPN score fetches now overlap; cumulative stats are accumulated AFTER, in date order
    // (identical result). Cold load ~15s -> ~1-2s. Placeholder/no-play rows carry zero stats so they
    // accumulate harmlessly.
    const gradedByDate = await Promise.all(fullDateRange.map(async (dateISO) => {
      const entry = picksLookup.get(dateISO);
      if (!entry) {
        return { date: dateISO, dateFormatted: dateISO, source: 'no-picks', noPlays: true, picks: [], wins: 0, losses: 0, pushes: 0, pending: 0, accuracy: '0', wagered: 0, profit: 0, roi: '--', parlayResult: 'skip', parlayProfit: 0 };
      }
      let picksData;
      try {
        const picksResp = await fetch(`${entry.url}/picks-${dateISO}`, { headers: authHeaders });
        if (!picksResp.ok) return null;
        picksData = await picksResp.json();
        picksData._source = entry.store;
      } catch (e) { return null; }
      const day = await gradeDay(dateISO, picksData);
      if (!day) {
        return { date: dateISO, dateFormatted: picksData.dateFormatted || dateISO, source: entry.store, noPlays: true, picks: [], wins: 0, losses: 0, pushes: 0, pending: 0, accuracy: '0', wagered: 0, profit: 0, roi: '--', parlayResult: 'skip', parlayProfit: 0 };
      }
      return day;
    }));

    const omegaDays = gradedByDate.filter(Boolean); // oldest first

    // ALL VERSIONS (founder, 2026-09-26): the public track record is one cumulative line for the
    // algo — Beta + Alpha history frozen through the day before the Omega KPI epoch, then Omega.
    // Legacy rows come from lib/kpi-legacy-alpha.json (scripts/build-kpi-legacy.js), never regraded.
    const legacyDays = legacyDaysBefore(OMEGA_KPI_START); // oldest first
    const allDays = legacyDays.concat(omegaDays);
    const all = aggregateDays(allDays);
    const omegaOnly = aggregateDays(omegaDays);
    const legacy = aggregateDays(legacyDays);

    const result = {
      days: allDays.slice().reverse(), // newest first; respond() trims to ?range (7 default)
      cumulative: all.cumulative,
      straight: all.straight,
      parlay: all.parlay,
      scope: {
        label: 'All model versions',
        from: allDays.length ? allDays[0].date : null,
        omegaStart: OMEGA_KPI_START,
        legacyThrough: LEGACY.through || null,
      },
      omegaOnly,
      legacy,
      months: monthlyTotals(allDays),
      windows: {
        last7: aggregateWindow(allDays, 7),
        last30: aggregateWindow(allDays, 30),
      },
      cachedAt: Date.now(),
    };

    try {
      const { summarizeClvFromStore } = require('./lib/clv-summary');
      result.clv = await summarizeClvFromStore({
        storeUrl: alphaStoreUrl,
        authHeaders,
        dates: alphaDates,
      });
    } catch (e) {
      result.clv = { available: false, n: 0, meanCents: null, beatClosePct: null, byFamily: {}, note: 'clv summary unavailable' };
    }

    try {
      await fetch(`${alphaStoreUrl}/${RESULTS_CACHE_KEY}`, {
        method: 'PUT',
        headers: { ...authHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify(result),
      });
    } catch (e) {}

    return respond(result, event);

  } catch (err) {
    console.error('[get-results-omega] Error:', err.message);
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: true, message: 'Failed to compute results' }) };
  }
};
