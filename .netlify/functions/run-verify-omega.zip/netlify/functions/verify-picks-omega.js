// verify-picks.js
// v2: Post-pick verification + auto-fix + sharp handicapper review + Discord alerts
//
// Runs at 10:30am ET daily. For each pick on today's beta card:
// 1. MATH CHECKS: Recompute EV, Kelly, grade. Flag mismatches.
// 2. NARRATIVE CHECKS: Verify reasoning mentions correct team, correct length, whatLoses present.
// 3. SHARP REVIEW: Call Grok as an elite Vegas handicapper to review the full card.
// 4. AUTO-FIX: If a pick fails critical checks (negative EV, math broken), drop it.
//    Auto-fix does not invent a side. A later reserve top-up can refill to 3.
// 5. DISCORD ALERT: Post errors/warnings to #picks-model-optimization.
//
// Verify may drop, flag, or resize inside the existing unit cap.
// A short card refills only from the private reserve, only up to 3,
// and never with a blocked side. Steam does not refill. No odds pull.
// A material Hard Rock line or price is the exception: that pick is
// repriced at Hard Rock, or replaced by the next Hard Rock candidate,
// and the parlay is rebuilt from the corrected card. Every change is logged.
// Late-news (MLB starter, NHL goalie, NFL/NCAAF QB) uses the same rule:
// drop or flag a published pick, never add or swap one.

const SITE_ID = process.env.SITE_ID || "87d7bcd9-e95a-479c-bc44-6432a2ffc606";
const DISCORD_CHANNEL = "1482660132222537808";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json",
};

// ── Helpers ──
function americanToDecimal(odds) { return odds > 0 ? 1 + odds / 100 : 1 + 100 / Math.abs(odds); }
function impliedProb(odds) { return odds < 0 ? Math.abs(odds) / (Math.abs(odds) + 100) : 100 / (odds + 100); }
function parseOdds(s) { return parseInt(String(s).replace(/[^0-9\-+]/g, ""), 10); }
function parseUnits(s) { return parseFloat(String(s).replace(/[^0-9.]/g, "")); }
function parseProbability(s) { const n = parseFloat(String(s).replace(/[^0-9.]/g, "")); return n > 1 ? n / 100 : n; }

// Omega v12.0.9: straights ≤3.5u + fixed 0.5u parlay ≤ 4.0u MAX (not a fill target).
// Trim order matches generate (quality, then units). Grades are not rewritten.
function enforceOmegaDailyUnitCap(picksData) {
  if (!picksData || !Array.isArray(picksData.picks)) return;
  // Same quality-then-units trim as generate. Grades are not rewritten from stake.
  const capped = applyDailyUnitCap(picksData.picks, picksData.parlayLegs);
  picksData.picks = capped.picks;
  if (Array.isArray(picksData.parlayLegs)) picksData.parlayLegs = capped.parlayLegs;
  if (picksData.summary) {
    picksData.summary.totalPicks = picksData.picks.length;
    picksData.summary.totalStraightBets = picksData.picks.length;
    writeSummaryStakeDisplay(picksData.summary, picksData.picks, picksData.parlayLegs);
  }
}


const { toPickObject, applyDailyUnitCap } = require('./lib/omega-vnext/select');
const { passesSheetMinimums } = require('./lib/omega-vnext/bet_check_gate');
const { finishShortCard, sideBlocked } = require('./lib/omega-vnext/card_topup');
const { buildShortfall } = require('./lib/omega-vnext/shortfall');
const { MAX_STRAIGHTS } = require('./lib/omega-vnext/config');
const { reviewHardRock, verifySchedule, applySilentSortCheck } = require('./lib/omega-vnext/selection_pass');
const { parlayFromStraights, parlayEvLabel, parlayIndependent } = require('./lib/omega-vnext/parlay');
const lateNews = require('./lib/omega-vnext/late_news');
const { storeLateNewsOps } = require('./lib/omega-vnext/store');
const { decimalToAmerican, formatAmerican, writeSummaryStakeDisplay } = require('./lib/omega-vnext/odds_math');
const { xaiChat, resolveXaiKey } = require('./lib/xai-chat');
const {
  createAuditLog, runWithAudit, persistAuditLog, attachAuditSummary, resolveFetch, makeRunId, currentAudit,
} = require('./lib/omega-vnext/audit_log');
const { replayNoWrite } = require('./lib/omega-vnext/no_write');

function auditFetch(url, init) {
  return resolveFetch(fetch)(url, init);
}

/** Favorite (decimal < 2) stays a minus price. Plus only when decimal >= 2. */
function formatCombinedAmerican(combinedDecimal) {
  const am = decimalToAmerican(combinedDecimal);
  if (am == null) return '';
  return formatAmerican(am);
}

/** Cover probability as a 0–1 fraction. Accepts 0.55 or "55%". */
function coverProbFraction(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return v > 1 ? v / 100 : v;
  if (v == null || v === '') return null;
  const n = parseFloat(String(v).replace(/[^0-9.]/g, ''));
  if (!Number.isFinite(n)) return null;
  return n > 1 ? n / 100 : n;
}

/**
 * Edge fraction for a verify candidate.
 * omega-vnext candidateTable stores generator edgePct on `edge` (not edgePct).
 * Fallback is coverProb − book implied when neither field is present.
 */
function edgeFractionForCandidate(c) {
  if (!c) return null;
  if (c.edgePct != null && c.edgePct !== '') return c.edgePct;
  if (typeof c.edge === 'number' && Number.isFinite(c.edge)) return c.edge;
  const cp = typeof c.coverProb === 'number' ? c.coverProb : parseFloat(c.coverProb);
  const odds = typeof c.odds === 'number' ? c.odds : parseOdds(c.odds);
  if (Number.isFinite(cp) && cp > 0 && cp <= 1 && Number.isFinite(odds) && odds !== 0) {
    return cp - impliedProb(odds);
  }
  return null;
}

function cardModelVersion(picksData) {
  if (!picksData) return undefined;
  return picksData.model || (picksData.summary && picksData.summary.modelVersion) || undefined;
}

/**
 * Replacement / backfill pick. Rating, qualityGrade, confidence, and units
 * come from toPickObject: quarter-Kelly ×50 in 0.5u steps, MAX_STRAIGHT_UNITS_PER_PICK,
 * then B_GRADE_UNIT_CAP when the quality grade is B.
 * The card-level 3.5u / 0.5u / 4.0u cap is enforceOmegaDailyUnitCap on write.
 * kellyUnits on the candidate is ignored (that field was the Alpha ladder).
 */
function buildQualityReplacement(c, opts = {}) {
  const edgePct = edgeFractionForCandidate(c);
  const oddsNum = typeof c.odds === 'number' ? c.odds : parseOdds(c.odds);
  const coverProb = coverProbFraction(c.coverProb != null ? c.coverProb : c.winProbability);
  const normalized = {
    ...c,
    side: c.side || c.pick,
    market: c.market || c.betType,
    odds: Number.isFinite(oddsNum) ? oddsNum : c.odds,
    coverProb: coverProb != null ? coverProb : c.coverProb,
    edgePct,
  };
  return toPickObject(normalized, { modelVersion: opts.modelVersion });
}

/** Drop pass blocks any straight refill. Earlier steam hard-fails count too. */
function steamDropBlocksStraightRefill(droppedSteam, steamHardFails) {
  return Number(droppedSteam) > 0 || Number(steamHardFails) > 0;
}

/**
 * Refill only to reach 3, only from the private reserve, never for a
 * blocked side. Steam still refuses. Placeability and late-news set
 * blockStraightRefill for the audit trail; that flag does not veto a
 * reserve row that is not itself blocked.
 */
function straightRefillAllowed(ctx = {}) {
  if (steamDropBlocksStraightRefill(ctx.droppedSteam, ctx.steamHardFails)) return false;
  const count = ctx.straightCount != null
    ? Number(ctx.straightCount)
    : (Array.isArray(ctx.picks) ? ctx.picks.length : NaN);
  if (!Number.isFinite(count) || !(count < MAX_STRAIGHTS)) return false;
  const reserve = Array.isArray(ctx.reserve) ? ctx.reserve : [];
  if (!reserve.length) return false;
  return true;
}

/**
 * After placeability, late-news, and auto-fix drops. Tops up from
 * card.reserve, checks placeability on the new rows only, rebuilds the
 * parlay, and re-applies the unit cap. Does not call the Odds API.
 * A failure here leaves the card as it was.
 */
function applyVerifyReserveTopUp(picksData, ctx = {}) {
  const empty = { topped: false, topUps: [], exhausted: false };
  try {
    if (!picksData || !Array.isArray(picksData.picks)) return empty;
    const allowed = straightRefillAllowed({
      droppedSteam: ctx.droppedSteam,
      steamHardFails: ctx.steamHardFails,
      straightCount: picksData.picks.length,
      reserve: picksData.reserve,
      picks: picksData.picks,
    });
    if (!allowed) {
      if (picksData.picks.length < MAX_STRAIGHTS) {
        picksData.shortfall = buildShortfall({
          picks: picksData.picks,
          parlayLegs: picksData.parlayLegs,
          yesPool: picksData.reserve || [],
          rejected: ctx.blocked || [],
        });
      }
      return empty;
    }
    const finished = finishShortCard({
      picks: picksData.picks,
      reserve: picksData.reserve,
      blocked: require('./lib/omega-vnext/card_integrity').blockedRowsFor(picksData, ctx.blocked || []),
      parlayPool: (picksData.picks || []).concat(picksData.reserve || []),
      decide: ctx.decide,
      checkPlaceability: true,
      maxRounds: 3,
      allowSameGame: ctx.allowSameGame,
    });
    if (!finished.added.length) {
      picksData.shortfall = buildShortfall({
        picks: picksData.picks,
        parlayLegs: picksData.parlayLegs,
        yesPool: finished.reserve || picksData.reserve || [],
        rejected: ctx.blocked || [],
      });
      return { topped: false, topUps: [], exhausted: !!finished.exhausted };
    }
    picksData.picks = finished.picks;
    picksData.parlayLegs = finished.parlayLegs;
    picksData.reserve = finished.reserve;
    if (!picksData.summary || typeof picksData.summary !== 'object') picksData.summary = {};
    picksData.summary.topUps = finished.topUps;
    picksData.summary.totalPicks = finished.picks.length;
    picksData.summary.totalStraightBets = finished.picks.length;
    writeSummaryStakeDisplay(picksData.summary, finished.picks, finished.parlayLegs);
    const integrity = require('./lib/omega-vnext/card_integrity').applyCardIntegrity(picksData);
    Object.assign(picksData, integrity.card);
    picksData.shortfall = buildShortfall({
      picks: finished.picks,
      parlayLegs: finished.parlayLegs,
      yesPool: finished.reserve || [],
      rejected: ctx.blocked || [],
    });
    return { topped: true, topUps: finished.topUps, exhausted: !!finished.exhausted };
  } catch (err) {
    console.log(`[verify-final] reserve top-up soft-fail: ${err && err.message}`);
    return empty;
  }
}

function sameTicketName(a, b) {
  const norm = (s) => String(s || '').trim().toLowerCase().replace(/\s+ml$/, '').trim();
  const na = norm(a);
  const nb = norm(b);
  return na !== '' && na === nb;
}

function repriceLockedParlay(root, legs) {
  let combinedDecimal = 1;
  let combinedProb = 1;
  let priced = true;
  for (const leg of legs) {
    const odds = parseOdds(leg.odds);
    const p = parseProbability(leg.coverProb);
    if (!Number.isFinite(odds) || odds === 0 || !Number.isFinite(p)) { priced = false; break; }
    combinedDecimal *= americanToDecimal(odds);
    combinedProb *= p;
  }
  const type = String(root.type || '').replace(/^\d+(?=-leg-parlay-)/, String(legs.length));
  const next = { ...root, legs, type: type || root.type };
  if (priced) {
    const parlayEV = (combinedProb * combinedDecimal) - 1;
    next.combinedOdds = formatCombinedAmerican(combinedDecimal);
    next.combinedDecimal = +combinedDecimal.toFixed(2);
    next.combinedProb = `${(combinedProb * 100).toFixed(1)}%`;
    next.ev = `${(parlayEV * 100).toFixed(1)}%`;
  }
  // Numbers stay a plain product. The label says so when comboStats would
  // have applied a haircut or a correlation term.
  const view = { ...next, legs, plainProduct: priced === true };
  const label = parlayEvLabel(view);
  if (label) {
    next.evLabel = label;
    next.correlationNote = label;
  }
  next.independent = parlayIndependent({ ...next, legs });
  if (Object.prototype.hasOwnProperty.call(root, 'mirrorsCard')) {
    const origLen = Array.isArray(root.legs) ? root.legs.length : legs.length;
    next.mirrorsCard = root.mirrorsCard === true && origLen === legs.length;
  }
  return next;
}

/**
 * Drop or resize a generate-locked parlay. Never compose a new one from the
 * straight card. `straightCard` is accepted and ignored so a caller cannot
 * quietly refill by passing the remaining straights.
 */
function resolveLockedParlay(parlayLegs, opts = {}) {
  // Remaining straights are not a parts bin. A caller that passes them cannot refill.
  void opts.straightCard;
  const removed = []
    .concat(opts.removedPicks || [])
    .filter(Boolean);
  const existing = Array.isArray(parlayLegs) ? parlayLegs : [];
  const root = existing[0] || null;
  const legs = root && Array.isArray(root.legs) ? root.legs : [];
  if (!root || legs.length < 2) {
    return { parlayLegs: [], action: legs.length ? 'cleared' : 'none', rebuilt: false };
  }
  const kept = legs.filter(leg => !removed.some(name => sameTicketName(name, leg.pick) || sameTicketName(name, leg.side)));
  if (kept.length === legs.length) {
    return { parlayLegs: existing, action: 'preserved', rebuilt: false };
  }
  if (kept.length < 2) {
    return { parlayLegs: [], action: 'cleared', rebuilt: false };
  }
  return {
    parlayLegs: [repriceLockedParlay(root, kept)],
    action: 'resized',
    rebuilt: false,
  };
}

// ── Math Checks ──
function runMathChecks(pick) {
  const warnings = [], errors = [];
  const checks = { evMatch: true, kellyMatch: true, gradeMatch: true, edgePositive: true };
  const odds = parseOdds(pick.odds);
  const units = parseUnits(pick.units);
  const coverProb = parseProbability(pick.winProbability || pick.coverProb);
  const decPayout = americanToDecimal(odds);
  const breakeven = impliedProb(odds);

  if (isNaN(odds) || isNaN(units) || isNaN(coverProb)) {
    errors.push("CRITICAL: Cannot parse odds, units, or probability");
    return { checks, warnings, errors, severity: "critical" };
  }

  // EV check
  const computedEV = coverProb * decPayout - 1;
  if (computedEV <= 0) {
    checks.edgePositive = false;
    errors.push(`CRITICAL: Negative EV (${(computedEV * 100).toFixed(1)}%) — coverProb ${(coverProb * 100).toFixed(0)}% <= breakeven ${(breakeven * 100).toFixed(0)}%`);
  }

  // EV display match
  if (pick.kellyCalc) {
    const evMatch = pick.kellyCalc.match(/edge=([\d.-]+)/);
    if (evMatch && Math.abs(computedEV - parseFloat(evMatch[1])) > 0.03) {
      checks.evMatch = false;
      warnings.push(`EV mismatch: computed ${(computedEV * 100).toFixed(1)}% vs displayed ${(parseFloat(evMatch[1]) * 100).toFixed(1)}%`);
    }
  }

  // Grade check — quality/edge bands (v12.1+), NOT units
  // A+ ≥5.0%, A ≥3.5%, A- ≥2.0%, else B. Exact band edges use higher grade.
  const edgeFrac = (() => {
    const raw = pick.edgePct != null ? pick.edgePct : pick.ev;
    if (raw == null) return null;
    if (typeof raw === 'number') return raw > 1 ? raw / 100 : raw;
    const n = parseFloat(String(raw).replace(/[^0-9.+-]/g, ''));
    if (!Number.isFinite(n)) return null;
    return Math.abs(n) > 1 ? n / 100 : n;
  })();
  if (edgeFrac != null) {
    let expectedGrade = 'b';
    if (edgeFrac >= 0.050) expectedGrade = 'aplus';
    else if (edgeFrac >= 0.035) expectedGrade = 'a';
    else if (edgeFrac >= 0.020) expectedGrade = 'aminus';
    const norm = String(pick.rating || '').toLowerCase().replace(/\+/g, 'plus').replace(/-/g, 'minus');
    const normMap = { 'a+': 'aplus', aplus: 'aplus', a: 'a', 'a-': 'aminus', aminus: 'aminus', b: 'b', 'b+': 'bplus', bplus: 'bplus' };
    const have = normMap[norm] || norm;
    if (pick.rating && have !== expectedGrade) {
      checks.gradeMatch = false;
      warnings.push(`Grade mismatch: "${pick.rating}" but edge ${(edgeFrac * 100).toFixed(1)}% should be "${expectedGrade}"`);
    }
  }

  const hasCritical = errors.some(e => e.startsWith("CRITICAL"));
  return { checks, warnings, errors, severity: hasCritical ? "critical" : warnings.length > 0 ? "warning" : "clean" };
}

// ── Narrative Checks ──
function runNarrativeChecks(pick) {
  const warnings = [], errors = [];
  const checks = { mentionsPickedTeam: true, reasonableLength: true, whatLosesPresent: true, narrativeDirection: true };
  const reasoning = pick.coreReasoning || "";
  const pickName = pick.pick || "";

  // Extract team name from pick
  const teamToken = pickName.split(/\s+(ML|[-+]?\d)/)[0].trim();
  const isTotal = /over|under/i.test(pickName);

  if (!isTotal && teamToken && reasoning.length > 0) {
    const lastWord = teamToken.split(/\s+/).pop().toLowerCase();
    if (lastWord.length > 3 && !reasoning.toLowerCase().includes(lastWord)) {
      checks.mentionsPickedTeam = false;
      warnings.push(`Narrative doesn't mention picked team "${teamToken}"`);
    }
  }

  // Length check
  const sentences = reasoning.split(/[.!?]+/).filter(s => s.trim().length > 10);
  if (sentences.length < 2) {
    checks.reasonableLength = false;
    errors.push("CRITICAL: Narrative too short — fewer than 2 sentences");
  } else if (sentences.length > 7) {
    checks.reasonableLength = false;
    warnings.push(`Narrative too long: ${sentences.length} sentences`);
  }

  // Empty narrative
  if (reasoning.trim().length < 20) {
    errors.push("CRITICAL: Narrative is empty or nearly empty");
  }

  // whatLoses
  if (!pick.whatLoses || pick.whatLoses.trim().length < 10) {
    checks.whatLosesPresent = false;
    warnings.push("whatLoses field is empty or too short");
  }

  const hasCritical = errors.some(e => e.startsWith("CRITICAL"));
  return { checks, warnings, errors, severity: hasCritical ? "critical" : warnings.length > 0 ? "warning" : "clean" };
}

// ── Hard Rock + US-major placeability (soft-veto) ──
// Confirm every published bet is shoppable. Hard Rock is the preferred book (market exists,
// totals/spreads point within 0.5, price within ~3–6 implied points). When Hard Rock misses,
// majors coverage can still save the pick: pick.placeableBooks / bestPlaceable from generate
// when present, otherwise a live US_BOOK_PRIORITY scan. Drop the pick only when Hard Rock
// AND majors both fail. Odds API down or a game missing from the feed → warn only, do not
// clear the card. Empty card OK. Never lean-refill a dropped side. Severity stays off
// "critical" so auto-fix does not invent a replacement; the soft-veto drop is separate.
const {
  US_BOOK_PRIORITY,
  PLACEABILITY,
  GATES,
} = require('./lib/omega-vnext/config');
const {
  assessPlaceability,
  verifyPlaceabilityDecision,
  applyPlaceabilityDrops,
} = require('./lib/omega-vnext/edge');
const HR_BOOK_KEYS = new Set(["hardrockbet", "hardrockbet_oh", "hardrock"]);
const HR_SPORT_KEYS = { MLB: "baseball_mlb", NBA: "basketball_nba", NHL: "icehockey_nhl", NFL: "americanfootball_nfl", NCAAF: "americanfootball_ncaaf" };
function sportEvFloor(sport, defaultFloor = 0) {
  const map = (GATES && GATES.minEV) || {};
  if (sport && map[sport] != null) return map[sport];
  if (map.default != null) return map.default;
  return defaultFloor;
}
function sportCoverFloor(sport) {
  const map = (GATES && GATES.minCoverProb) || {};
  if (sport && map[sport] != null) return map[sport];
  if (map.default != null) return map.default;
  return 0;
}
function candidateClearsSportGates(c) {
  // Sheet floors are the only admission rule post-generate (2026-10-18):
  // no sub-sheet replacement/backfill pick can be added after generate.
  if (!passesSheetMinimums(c)) return false;
  if (!c || !(c.ev > 0) || !(c.ev + 1e-12 >= sportEvFloor(c.sport))) return false;
  const cp = typeof c.coverProb === "number" ? c.coverProb : parseFloat(c.coverProb) || 0;
  if (cp < sportCoverFloor(c.sport)) return false;
  return true;
}
const HR_F5_MARKETS = { "F5 Moneyline": "h2h_1st_5_innings", "F5 Run Line": "spreads_1st_5_innings", "F5 Total": "totals_1st_5_innings" };
const HR_ODDS_WORSE_PP = 3.0; // warning: Hard Rock implied prob >3pp worse than published
const HR_ODDS_ERROR_PP = 6.0; // error: >6pp worse — materially off the expressed price

function hrLastWord(name) { return String(name || "").trim().split(/\s+/).pop().toLowerCase(); }
function hrImpliedPct(american) { return impliedProb(american) * 100; }
function hrMatchGame(games, matchup) {
  const m = String(matchup || "").toLowerCase();
  return (games || []).find(g => {
    const h = String(g.home_team || "").toLowerCase();
    const a = String(g.away_team || "").toLowerCase();
    if (m.includes(hrLastWord(g.home_team)) && m.includes(hrLastWord(g.away_team))) return true;
    // CFB: nicknames collide (Tigers/Bulldogs) — also match on school/first tokens.
    const hSchool = h.replace(/\s+\S+$/, "");
    const aSchool = a.replace(/\s+\S+$/, "");
    return hSchool.length > 3 && aSchool.length > 3 && m.includes(hSchool) && m.includes(aSchool);
  }) || null;
}
function hrBookFrom(game) {
  return ((game && game.bookmakers) || []).find(b => HR_BOOK_KEYS.has((b.key || "").toLowerCase())) || null;
}
function hrMarketFrom(book, marketKey) {
  return ((book && book.markets) || []).find(mk => mk.key === marketKey) || null;
}

// Find the published pick's side inside one book's market, plus the published point.
function hrFindOutcome(market, pick, marketKey) {
  let outcome = null, pubPoint = null;
  if (marketKey === "h2h" || marketKey === "h2h_1st_5_innings") {
    const team = String(pick.pick || "").replace(/\s*(F5\s*)?ML\s*$/i, "").trim();
    outcome = (market.outcomes || []).find(o => hrLastWord(o.name) === hrLastWord(team) || String(o.name).toLowerCase().includes(hrLastWord(team)));
  } else if (marketKey === "totals" || marketKey === "totals_1st_5_innings") {
    const side = /under/i.test(pick.pick) ? "Under" : "Over";
    pubPoint = parseFloat(String(pick.pick).replace(/[^0-9.]/g, ""));
    outcome = (market.outcomes || []).find(o => o.name === side);
  } else {
    const team = String(pick.pick || "").replace(/[-+]?\d+(\.\d+)?\s*$/, "").trim();
    const ptMatch = String(pick.pick || "").match(/([-+]?\d+(\.\d+)?)\s*$/);
    pubPoint = ptMatch ? parseFloat(ptMatch[1]) : null;
    outcome = (market.outcomes || []).find(o => hrLastWord(o.name) === hrLastWord(team) || String(o.name).toLowerCase().includes(hrLastWord(team)));
  }
  return { outcome, pubPoint };
}

// Deprecated F5 majors fallback. The 10:30 check uses the saved 10:00 quotes
// and does not call this helper. Backup books are Pinnacle, Hard Rock, and
// DraftKings. FanDuel, BetMGM, Caesars, and the rest are off this list.
const HR_MAJOR_BOOKS = new Set([
  "pinnacle", "hardrockbet", "hardrock", "draftkings",
]);
function hrMajorsFallback(pick, game) {
  const out = { available: false, hrOdds: null, hrPoint: null, warnings: [], errors: [], notes: [] };
  const marketKey = HR_F5_MARKETS[pick.betType || ""];
  const pubOdds = parseOdds(pick.odds);
  const prices = [];
  for (const b of (game.bookmakers || [])) {
    if (!HR_MAJOR_BOOKS.has((b.key || "").toLowerCase())) continue;
    const market = hrMarketFrom(b, marketKey);
    if (!market) continue;
    const { outcome, pubPoint } = hrFindOutcome(market, pick, marketKey);
    if (!outcome || !Number.isFinite(outcome.price)) continue;
    if (pubPoint !== null && Number.isFinite(outcome.point) && Math.abs(outcome.point - pubPoint) > 0.5) continue;
    prices.push(outcome.price);
  }
  if (prices.length < 3) {
    out.errors.push(`HardRock: Hard Rock's First 5 Innings prices aren't in the odds feed and only ${prices.length} other major book(s) quote this bet — not confirmed placeable`);
    return out;
  }
  const sorted = prices.slice().sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  const medianStr = median > 0 ? `+${median}` : `${median}`;
  out.available = true;
  const worsePP = Number.isFinite(pubOdds) ? hrImpliedPct(median) - hrImpliedPct(pubOdds) : 0;
  if (worsePP > HR_ODDS_ERROR_PP) {
    out.available = false;
    out.errors.push(`HardRock: majors' median F5 price ${medianStr} vs published ${pick.odds} (+${worsePP.toFixed(1)}pp implied) — outside ballpark`);
  } else if (worsePP > HR_ODDS_WORSE_PP) {
    out.warnings.push(`HardRock: majors' median F5 price ${medianStr} vs published ${pick.odds} (+${worsePP.toFixed(1)}pp implied) — worse but in ballpark`);
  }
  if (out.available) {
    out.notes.push(`HardRock: HR lists this as "First 5 Innings" on-app but its F5 prices aren't in the odds feed — confirmed at ${prices.length} majors (median ${medianStr}); spot-check the HR app for HR's exact number`);
  }
  return out;
}

// Route one pick to the right confirmation path: HR-direct when the feed has Hard Rock's
// market, majors-fallback for F5 events where HR's prices aren't in the feed.
function hrCheckOne(pick, game) {
  const isF5 = (pick.betType || "").startsWith("F5");
  if (isF5 && game && !hrBookFrom(game)) return hrMajorsFallback(pick, game);
  return hrEvaluate(pick, game);
}

// Compare one published pick against Hard Rock's current offering for that market.
function hrEvaluate(pick, game) {
  const out = { available: false, hrOdds: null, hrPoint: null, warnings: [], errors: [], notes: [] };
  const pubOdds = parseOdds(pick.odds);
  const betType = pick.betType || "";
  const isF5 = betType.startsWith("F5");
  const marketKey = isF5 ? HR_F5_MARKETS[betType] : (betType === "Moneyline" ? "h2h" : betType === "Total" ? "totals" : "spreads");
  if (!marketKey) { out.warnings.push(`HardRock: unsupported bet type "${betType}" — not checked`); return out; }

  const book = hrBookFrom(game);
  if (!book) { out.errors.push(`HardRock: Hard Rock Bet has no lines for this game — bet not confirmed placeable`); return out; }
  const market = hrMarketFrom(book, marketKey);
  if (!market) { out.errors.push(`HardRock: ${betType} market not offered at Hard Rock Bet for this game`); return out; }

  const { outcome, pubPoint } = hrFindOutcome(market, pick, marketKey);
  if (!outcome || !Number.isFinite(outcome.price)) {
    out.errors.push(`HardRock: side "${pick.pick}" not found in Hard Rock's ${betType} market`);
    return out;
  }

  out.available = true;
  out.hrOdds = outcome.price > 0 ? `+${outcome.price}` : `${outcome.price}`;
  if (outcome.point !== undefined) out.hrPoint = outcome.point;

  // Point ballpark (totals/spreads): same bet within half a point, else it's a different bet.
  if (pubPoint !== null && Number.isFinite(outcome.point)) {
    const d = Math.abs(outcome.point - pubPoint);
    if (d > 0.5) {
      out.errors.push(`HardRock: line is ${outcome.point} vs published ${pubPoint} (Δ${d.toFixed(1)}) — materially different bet`);
      return out;
    }
    if (d > 0) out.warnings.push(`HardRock: line is ${outcome.point} vs published ${pubPoint} — half-point off`);
  }

  // Price ballpark: how much worse is Hard Rock's implied probability than the published price?
  if (Number.isFinite(pubOdds)) {
    const worsePP = hrImpliedPct(outcome.price) - hrImpliedPct(pubOdds);
    if (worsePP > HR_ODDS_ERROR_PP) {
      out.errors.push(`HardRock: price ${out.hrOdds} vs published ${pick.odds} (+${worsePP.toFixed(1)}pp implied) — outside ballpark`);
    } else if (worsePP > HR_ODDS_WORSE_PP) {
      out.warnings.push(`HardRock: price ${out.hrOdds} vs published ${pick.odds} (+${worsePP.toFixed(1)}pp implied) — worse but in ballpark`);
    }
  }
  return out;
}

function oddsBookmakerParam(picksData) {
  const rows = [...(picksData.picks || [])];
  for (const pl of picksData.parlayLegs || []) rows.push(...(pl.legs || []));
  const needsLiveMajors = rows.some(p => !Array.isArray(p.placeableBooks));
  if (!needsLiveMajors) return "hardrockbet,hardrockbet_oh";
  return [...new Set([...US_BOOK_PRIORITY, "hardrockbet_oh"])].join(",");
}

function liveMajorsFor(pick, game) {
  if (!game || !Array.isArray(game.bookmakers)) return [];
  const betType = pick.betType || pick.market || "";
  const isF5 = betType.startsWith("F5");
  const marketKey = isF5
    ? HR_F5_MARKETS[betType]
    : (betType === "Moneyline" ? "h2h" : betType === "Total" ? "totals" : (betType === "Spread" ? "spreads" : null));
  if (!marketKey) return [];
  const drift = PLACEABILITY.maxPointDrift != null ? PLACEABILITY.maxPointDrift : 0.5;
  const prices = [];
  for (const b of game.bookmakers) {
    const market = hrMarketFrom(b, marketKey);
    if (!market) continue;
    const { outcome, pubPoint } = hrFindOutcome(market, pick, marketKey);
    if (!outcome || !Number.isFinite(outcome.price)) continue;
    if (pubPoint !== null && Number.isFinite(outcome.point) && Math.abs(outcome.point - pubPoint) > drift) continue;
    prices.push({ book: b.key, american: Number(outcome.price) });
  }
  return assessPlaceability(prices, parseOdds(pick.odds)).placeableBooks;
}

function decisionForPick(pick, hr, { feedDown = false, gameMissing = false, livePlaceableBooks = null } = {}) {
  return verifyPlaceabilityDecision({
    pick,
    hr,
    apiDown: false,
    feedDown,
    gameMissing,
    livePlaceableBooks: Array.isArray(pick.placeableBooks) ? null : livePlaceableBooks,
  });
}

function snapshotAlreadyCoversQa(picksData) {
  const sel = picksData && picksData.selection;
  return !!(sel && sel.snapshotCoversHardRock === true && sel.snapshotCoversParlay === true);
}

async function runHardRockCheck(picksData) {
  // Saved 10:00 quotes only. No Odds API pull. Straights are flagged.
  // decision.drop stays false so a miss never removes a straight.
  const sportGames = {};
  const reviewed = reviewHardRock(picksData, sportGames);
  let drafted = { changed: false, card: picksData, verdict: reviewed.verdict, lines: reviewed.lines, corrections: [] };
  try {
    const timeline = require('./lib/omega-vnext/timeline');
    drafted = timeline.draftAndCheckHardRock(picksData, { sportGames });
    if (drafted && drafted.card) {
      picksData.picks = drafted.card.picks;
      picksData.parlayLegs = drafted.card.parlayLegs;
      picksData.hardRockCheck = drafted.card.hardRockCheck;
      picksData.timelineStep = drafted.card.timelineStep;
      picksData.cardStatus = drafted.card.cardStatus;
      picksData.finalized = false;
      picksData.selection = drafted.card.selection;
      picksData.bugLog = drafted.card.bugLog;
    }
  } catch (err) {
    console.log(`[verify-hardrock] draft check soft-fail: ${err && err.message}`);
  }
  const lines = (drafted && drafted.lines) || reviewed.lines || [];
  const summary = {
    book: "Hard Rock Bet",
    checked: (picksData.picks || []).length,
    available: lines.filter((row) => row && row.placeable && row.kind === "straight").length,
    warnings: lines.filter((row) => row && row.placeable === false).length,
    errors: 0,
    skipped: false,
    apiDown: false,
    verdict: (drafted && drafted.verdict) || reviewed.verdict || "FAIL",
    blocksPublish: false,
    reason: "saved 10:00 quotes",
  };
  const pickResults = (picksData.picks || []).map((pick, i) => {
    const line = lines.find((row) => row && row.kind === "straight" && row.index === i) || {};
    const placeable = !!line.placeable;
    return {
      available: placeable,
      hrOdds: line.hardRockAmerican != null ? line.hardRockAmerican : null,
      hrPoint: line.line != null ? line.line : null,
      warnings: placeable ? [] : ["Hard Rock does not post the displayed price"],
      errors: [],
      notes: [],
      decision: { drop: false },
    };
  });
  const parlayFindings = [];
  const legDecisions = lines.filter((row) => row && row.kind === "parlay").map((row) => {
    if (!row.placeable) {
      parlayFindings.push({ level: "warning", note: `Parlay leg "${row.pick}" is not at the displayed price on Hard Rock` });
    }
    return { drop: false, pick: row.pick, matchup: row.matchup, placeable: !!row.placeable };
  });
  return {
    summary,
    pickResults,
    parlayFindings,
    legDecisions,
    corrections: (drafted && drafted.corrections) || [],
    changed: !!(drafted && drafted.changed),
  };
}

async function runHardRockCheckLegacyFetch(picksData) {
  // Deprecated. Not called. The 10:30 path is runHardRockCheck and does not
  // pull odds. The old fetch body stays below so it is not deleted.
  void picksData;
  return {
    summary: { skipped: true, apiDown: false, reason: 'deprecated' },
    pickResults: [],
    parlayFindings: [],
    legDecisions: [],
    corrections: [],
    changed: false,
  };
  if (snapshotAlreadyCoversQa(picksData)) {
    const schedule = verifySchedule(picksData, Date.now());
    return {
      summary: {
        book: "Hard Rock Bet",
        checked: (picksData.picks || []).length,
        available: 0,
        warnings: 0,
        errors: 0,
        skipped: true,
        apiDown: false,
        reason: "10 AM snapshot covers Hard Rock and the parlay",
        scheduleDrops: schedule.dropped || [],
      },
      pickResults: (picksData.picks || []).map(() => ({
        available: false,
        hrOdds: null,
        hrPoint: null,
        warnings: [],
        errors: [],
        notes: [],
        decision: { drop: false },
      })),
      parlayFindings: [],
      legDecisions: [],
      corrections: [],
      changed: !!schedule.changed,
    };
  }
  const summary = { book: "Hard Rock Bet", checked: 0, available: 0, warnings: 0, errors: 0, skipped: false, apiDown: false };
  const pickResults = [];
  const parlayFindings = [];
  const legDecisions = [];
  const apiKey = process.env.ODDS_API_KEY;
  if (!apiKey) {
    summary.skipped = true;
    summary.apiDown = true;
    summary.reason = "No ODDS_API_KEY";
    const decision = verifyPlaceabilityDecision({ apiDown: true });
    for (const _p of (picksData.picks || [])) {
      pickResults.push({
        available: false, hrOdds: null, hrPoint: null,
        warnings: [decision.warning], errors: [], notes: [], decision,
      });
    }
    return { summary, pickResults, parlayFindings, legDecisions, corrections: [], changed: false };
  }

  // Main-lines fetch: Hard Rock only when every pick already carries placeableBooks.
  // Otherwise include US_BOOK_PRIORITY so majors coverage can be rechecked live.
  // Plus one per-event fetch per F5 game.
  const bySport = {};
  for (const p of (picksData.picks || [])) (bySport[p.sport] = bySport[p.sport] || []).push(p);
  for (const pl of (picksData.parlayLegs || [])) {
    for (const leg of (pl.legs || [])) (bySport[leg.sport] = bySport[leg.sport] || []).push(leg);
  }
  const bookmakers = oddsBookmakerParam(picksData);
  const sportGames = {};
  let anySportOk = false;
  let sportsAttempted = 0;
  for (const sport of Object.keys(bySport)) {
    const key = HR_SPORT_KEYS[sport];
    if (!key) continue;
    sportsAttempted++;
    try {
      const resp = await auditFetch(
        `https://api.the-odds-api.com/v4/sports/${key}/odds?markets=h2h,spreads,totals&oddsFormat=american&bookmakers=${bookmakers}&apiKey=${apiKey}`,
        { signal: AbortSignal.timeout(12000) }
      );
      sportGames[sport] = resp.ok ? await resp.json() : null;
      if (resp.ok) anySportOk = true;
    } catch (e) { sportGames[sport] = null; }
  }
  if (sportsAttempted > 0 && !anySportOk) summary.apiDown = true;

  // Hard Rock is a review-only verifier. A gap is flagged and the DraftKings
  // price is left alone. Start times are re-checked here; a live or
  // out-of-slate straight is dropped and the next DK candidate can fill.
  let corrections = [];
  let changed = false;
  if (!summary.apiDown) {
    const reviewed = reviewHardRock(picksData, sportGames);
    corrections = reviewed.flags || [];
    summary.hardRockFlags = corrections.length;
    if (summary.hardRockFlags) {
      console.log(`[verify-hardrock] review-only flags=${summary.hardRockFlags} (DK price unchanged)`);
    }
  }
  const schedule = verifySchedule(picksData, Date.now());
  if (schedule.changed) {
    changed = true;
    summary.scheduleDrops = schedule.dropped || [];
  }

  const f5Cache = {};
  async function gameForPick(pick) {
    const games = sportGames[pick.sport];
    if (!games) return { game: null, feedDown: true };
    const game = hrMatchGame(games, pick.matchup);
    if (!game) return { game: null, feedDown: false };
    if ((pick.betType || "").startsWith("F5")) {
      if (!(game.id in f5Cache)) {
        try {
          // All US books, not HR-scoped: HR's F5 prices aren't in the feed, so the
          // majors-fallback needs the full field to confirm placeability.
          const resp = await auditFetch(
            `https://api.the-odds-api.com/v4/sports/${HR_SPORT_KEYS[pick.sport]}/events/${game.id}/odds?regions=us,us2&markets=h2h_1st_5_innings,spreads_1st_5_innings,totals_1st_5_innings&oddsFormat=american&apiKey=${apiKey}`,
            { signal: AbortSignal.timeout(12000) }
          );
          f5Cache[game.id] = resp.ok ? await resp.json() : null;
        } catch (e) { f5Cache[game.id] = null; }
      }
      return { game: f5Cache[game.id], feedDown: f5Cache[game.id] === null };
    }
    return { game, feedDown: false };
  }

  for (const pick of (picksData.picks || [])) {
    summary.checked++;
    const { game, feedDown } = await gameForPick(pick);
    const down = feedDown || summary.apiDown;
    let r;
    if (!game) {
      r = { available: false, hrOdds: null, hrPoint: null, warnings: [], errors: [], notes: [] };
      // Feed down or game already started: unknowable, not unplaceable. Warn, do not drop.
      r.warnings.push(down
        ? `HardRock: odds feed unavailable — placeability not confirmed`
        : `HardRock: game not in the current odds feed (already started?) — placeability not confirmed`);
      r.decision = verifyPlaceabilityDecision({
        pick, apiDown: !!summary.apiDown, feedDown: down, gameMissing: !down, hr: { unknowable: true },
      });
    } else {
      r = hrCheckOne(pick, game);
      const liveBooks = Array.isArray(pick.placeableBooks) ? null : liveMajorsFor(pick, game);
      r.decision = decisionForPick(pick, r, { livePlaceableBooks: liveBooks });
      // Majors still cover: keep the pick. HR miss is a warning, not a drop signal.
      if (r.decision && !r.decision.drop && r.decision.warning && r.errors && r.errors.length) {
        r.warnings.push(r.decision.warning);
        r.warnings.push(...r.errors);
        r.errors = [];
      }
    }
    if (r.available) summary.available++;
    summary.warnings += r.warnings.length;
    summary.errors += r.errors.length;
    pickResults.push(r);
  }

  // Parlay legs: same per-leg confirmation + same-game structural check (a standard parlay
  // with two legs from one game is typically not buildable — books require an SGP instead).
  // A failing leg is recorded for the soft-veto. The parlay is cleared, not refilled.
  for (const pl of (picksData.parlayLegs || [])) {
    const legGames = [];
    for (const leg of (pl.legs || [])) {
      const idx = (picksData.picks || []).findIndex(p => p.pick === leg.pick && p.matchup === leg.matchup);
      let decision = null;
      if (idx >= 0 && pickResults[idx]) {
        const r = pickResults[idx];
        decision = r.decision || null;
        if (!r.available && r.errors.length) parlayFindings.push({ level: "error", note: `Parlay leg "${leg.pick}": ${r.errors[0]}` });
      } else {
        const { game, feedDown } = await gameForPick(leg);
        const down = feedDown || summary.apiDown;
        if (!game) {
          decision = verifyPlaceabilityDecision({
            pick: leg, apiDown: !!summary.apiDown, feedDown: down, gameMissing: !down, hr: { unknowable: true },
          });
          parlayFindings.push({ level: "warning", note: `Parlay leg "${leg.pick}" not reconfirmed — odds feed ${down ? "unavailable" : "missing this game"}` });
        } else {
          const r = hrCheckOne(leg, game);
          const liveBooks = Array.isArray(leg.placeableBooks) ? null : liveMajorsFor(leg, game);
          decision = decisionForPick(leg, r, { livePlaceableBooks: liveBooks });
          if (decision && decision.drop) {
            parlayFindings.push({ level: "error", note: `Parlay leg "${leg.pick}" failed placeability (Hard Rock + majors)` });
          } else if (!r.available && !(decision && decision.warning)) {
            parlayFindings.push({ level: "warning", note: `Parlay leg "${leg.pick}" not confirmed at Hard Rock Bet` });
          }
        }
      }
      if (decision && decision.drop && idx < 0) {
        legDecisions.push({
          drop: true, pick: leg.pick, matchup: leg.matchup, reason: decision.reason,
        });
      }
      legGames.push(hrLastWord((leg.matchup || "").replace(/\s*(vs\.?|@|at)\s*/gi, " ")));
    }
    const dupes = legGames.filter((g, i) => legGames.indexOf(g) !== i);
    if (dupes.length > 0) {
      parlayFindings.push({ level: "warning", note: `Parlay has two legs from the same game — a standard parlay likely won't build at Hard Rock Bet (needs SGP)` });
    }
  }
  summary.errors += parlayFindings.filter(f => f.level === "error").length;
  summary.warnings += parlayFindings.filter(f => f.level === "warning").length;
  return { summary, pickResults, parlayFindings, legDecisions, corrections, changed };
}

// ── Open→pick steam recheck (Omega v12.1 line-move) ──
// Load latest morning snap; hard-fail / flag critical on adverse steam past verify thresholds.
// Empty card OK — never lean force-fill. Placeability soft-veto is separate from steam:
// it drops a pick only when Hard Rock and US majors both fail. The later reserve
// top-up may replace that drop. This steam recheck does not refill.
async function runOmegaSteamRecheck(picksData, pickReports) {
  const out = { checked: 0, failed: 0, reasons: [] };
  try {
    const linePath = require('./lib/omega-vnext/line_path');
    const { LINE_MOVE } = require('./lib/omega-vnext/config');
    const dateISO = picksData.date;
    if (!dateISO || !Array.isArray(picksData.picks)) return out;
    const loaded = await linePath.loadLinePath(dateISO);
    const openSnap = loaded.earliest;
    const nowSnap = loaded.latest || loaded.earliest;
    if (!openSnap) {
      console.log('[verify-steam] no morning line snaps — skip steam recheck');
      return out;
    }
    for (let i = 0; i < picksData.picks.length; i++) {
      const pick = picksData.picks[i];
      const key = linePath.gameKey(pick.awayTeam, pick.homeTeam);
      const openG = (openSnap.games || {})[key];
      const nowG = ((nowSnap && nowSnap.games) || {})[key];
      if (!openG) continue;
      const openWithTs = { ...openG, capturedAt: openSnap.capturedAt || null };
      const cand = {
        market: pick.betType || pick.market,
        side: pick.pick || pick.side,
        homeTeam: pick.homeTeam,
        awayTeam: pick.awayTeam,
        odds: typeof pick.odds === 'number' ? pick.odds : parseInt(String(pick.odds).replace(/[^0-9\-+]/g, ''), 10),
        line: pick.line != null ? pick.line : null,
        predictedClv: pick.predictedClv,
      };
      const move = linePath.computeOpenToNowMove(cand, openWithTs, nowG || null);
      pick.lineMove = move;
      if (move.openPrint && !pick.openPrint) {
        pick.openPrint = move.openPrint;
        pick.lockSnapshot = pick.lockSnapshot || {};
        pick.lockSnapshot.openPrint = move.openPrint;
      }
      out.checked++;
      const reason = linePath.adverseSteamReason(move, { verify: true });
      if (reason) {
        out.failed++;
        out.reasons.push({ pick: pick.pick, reason });
        if (pickReports[i]) {
          pickReports[i].errors.push(`STEAM_HARDFAIL: ${reason}`);
          pickReports[i].severity = 'critical';
          pickReports[i].steamHardFail = reason;
        }
        console.log(`[verify-steam] HARDFAIL ${pick.pick}: ${reason}`);
      } else if (move.steamAgainst && pickReports[i]) {
        pickReports[i].warnings.push(`steam against (below verify threshold): towardScore=${move.towardScore}`);
      }
    }
    console.log(`[verify-steam] checked=${out.checked} failed=${out.failed} open=${openSnap.hhmm || openSnap.slot} latest=${(nowSnap && (nowSnap.hhmm || nowSnap.slot)) || 'n/a'} threshCents=${LINE_MOVE.verifyAdverseCents}`);
  } catch (e) {
    console.log(`[verify-steam] skipped: ${e.message}`);
  }
  return out;
}

// ── Sharp Handicapper Review (Grok) ──
const SHARP_REVIEW_SYSTEM = `You are an elite Las Vegas handicapper with 25 years of experience. You've worked for professional betting syndicates and have a lifetime ROI of +8% on over 50,000 bets. You review betting cards for red flags that pure math can't catch.

Your job: Review today's 3-pick card and flag anything that concerns you. Think about:
- Trap games (teams with nothing to play for, scheduling spots, look-ahead games)
- Narrative coherence (does the reasoning actually support the pick direction?)
- Line smell (does the line look right for this matchup, or is it a trap number?)
- Correlation risk (are multiple picks exposed to the same outcome?)
- Situational factors (travel, rest, motivation, playoffs context)
- NFL/NCAAF: QB status (out/doubtful), outdoor weather (wind/cold/precip vs indoor/dome), short-week rest (TNF). Never apply baseball starter/FIP logic to football.

Return ONLY valid JSON:
{
  "verdict": "clean" | "concerns" | "red_flag",
  "confidence": 1-100,
  "analysis": "1-3 sentences summarizing your review",
  "pickFlags": [
    { "pickIndex": 1, "flag": "concern" | "red_flag", "reason": "brief explanation" }
  ]
}

"clean" = card looks solid, no issues.
"concerns" = minor situational worries but still playable.
"red_flag" = at least one pick has a significant problem that math wouldn't catch.

Be honest and direct. Don't flag things just to flag them. Only raise genuine concerns.`;

function isXaiHttpError(err) {
  return /xAI HTTP \d+/.test(String((err && err.message) || ''));
}

async function sharpReview(picks, dateFormatted) {
  const xaiKey = resolveXaiKey();
  if (!xaiKey) return { verdict: "skip", analysis: "No API key for sharp review" };

  const cardSummary = picks.map((p, i) =>
    `${i + 1}. [${p.rating}] ${p.pick} ${p.odds} | ${p.units} | ${p.sport} | Cover: ${p.winProbability} | EV: ${p.ev}\n   Reasoning: ${(p.coreReasoning || '').slice(0, 200)}\n   What loses: ${p.whatLoses || 'N/A'}`
  ).join('\n\n');

  try {
    // never hang QA on a rate-limited call — try/catch → skip
    const text = await xaiChat({
      apiKey: xaiKey,
      system: SHARP_REVIEW_SYSTEM,
      user: `Today's card (${dateFormatted}):\n\n${cardSummary}`,
      maxTokens: 1500,
      timeoutMs: 25000,
    });
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
  } catch (e) {
    console.log(`[verify-sharp] Grok review failed: ${e.message}`);
  }
  return { verdict: "skip", analysis: "Sharp review unavailable" };
}

const STRAIGHT_NARRATIVE_SYSTEM = `You write concise sports betting pick narratives for WeBetAI. You have NO live data, so you must NOT invent specific facts (player names, stats, records, injuries, venues, weather). Each narrative should:
- Be 2-3 sentences max
- Explain in GENERAL terms why WeBetAI's model favors the side named in the pick (team / Over-Under / line)
- Frame the value as the model's projection diverging from this market price
- State NO specific player names, records, scores, venues, or injuries you were not explicitly given — if unsure, stay general
- Never use technical jargon (no ORtg, DRtg, DVOA, ATS); never restate projections, lines, or numbers (shown separately)
- Always say "WeBetAI" not "the model"

Also write:
- "whatLoses": one sentence describing the specific scenario that beats this pick
- "dataVerified": brief note that the edge is model-grounded (no invented injuries/stats)
- "clvExpectation": one sentence on expected closing-line movement

Return ONLY valid JSON array:
[{ "pickIndex": 1, "coreReasoning": "...", "whatLoses": "...", "dataVerified": "...", "clvExpectation": "..." }, ...]`;

const PARLAY_LEG_NARRATIVE_SYSTEM = `You write concise sports betting pick narratives for WeBetAI parlay legs. You have NO live data, so you must NOT invent specific facts (player names, stats, records, injuries, venues, weather). Each narrative should:
- Be 2-4 sentences
- Explain in GENERAL terms why WeBetAI favors the side named in the leg
- Frame the value as the model's projection diverging from this market price
- State NO specific player names, records, scores, venues, or injuries you were not explicitly given
- Never use technical jargon; never restate projections/lines/numbers (shown separately)
- Always say "WeBetAI" not "the model"

Also write whatLoses, dataVerified, and clvExpectation (one sentence each).

Return ONLY valid JSON array:
[{ "legIndex": 1, "coreReasoning": "...", "whatLoses": "...", "dataVerified": "...", "clvExpectation": "..." }, ...]`;

function applyNarrativeTemplate(rows, indices) {
  let finalFixCount = 0;
  for (const i of indices) {
    const p = rows[i];
    if (!p.coreReasoning || p.coreReasoning.length < 80 || p.coreReasoning.includes('replaces')) {
      const isTotal = /over|under/i.test(p.pick);
      const isML = /\bML\b/i.test(p.pick);
      p.coreReasoning = isTotal
        ? `WeBetAI projects ${p.modelEdge || 'a statistical edge'} on this total. Recent scoring trends and pace data support this direction, with the projection diverging from the consensus line.`
        : isML
        ? `WeBetAI gives this team a win probability above the market's implied odds at ${p.odds}. The Elo rating differential and recent form support value at these odds.`
        : `WeBetAI projects ${p.modelEdge || 'a spread edge'} on this matchup. Efficiency metrics and recent form diverge from the consensus line, creating positive expected value.`;
      finalFixCount++;
    }
    if (!p.whatLoses || p.whatLoses.length < 15) {
      p.whatLoses = "The opposite outcome materializes, or late line movement eliminates the edge.";
    }
  }
  return finalFixCount;
}

function applyParlayLegTemplate(legs, indices) {
  let finalFixCount = 0;
  for (const i of indices) {
    const leg = legs[i];
    if (!leg.coreReasoning || leg.coreReasoning.length < 80) {
      const isTotal = /over|under/i.test(leg.pick || '');
      leg.coreReasoning = isTotal
        ? `WeBetAI likes this total as a parlay leg — scoring trends and pace support the direction at the posted number.`
        : `WeBetAI likes this side as a parlay leg — form and matchup factors diverge from the market price enough to include it on the slip.`;
      finalFixCount++;
    }
    if (!leg.whatLoses || leg.whatLoses.length < 15) {
      leg.whatLoses = "The opposite outcome materializes, or late line movement eliminates the edge.";
    }
  }
  return finalFixCount;
}

/** HTTP failures log and leave the short copy. Network/parse failures use the template. Card still publishes. */
async function backfillStraightNarratives(picks, uniqueNeeds) {
  let finalFixCount = 0;
  if (!uniqueNeeds || uniqueNeeds.length === 0 || !resolveXaiKey()) return finalFixCount;
  console.log(`[verify-final] Writing narratives for ${uniqueNeeds.length} pick(s) via Grok`);
  const pickDescriptions = uniqueNeeds.map(i => {
    const p = picks[i];
    return `Pick ${i + 1}: ${p.pick} ${p.odds} | ${p.sport} ${p.betType || ''} | ${p.matchup} | Cover: ${p.winProbability} | EV: ${p.ev} | ${p.modelEdge || ''}`;
  }).join('\n');
  try {
    // never hang QA on a rate-limited call — try/catch → template
    const text = await xaiChat({
      apiKey: resolveXaiKey(),
      system: STRAIGHT_NARRATIVE_SYSTEM,
      user: `Write narratives for these picks:\n${pickDescriptions}`,
      maxTokens: 1500,
      timeoutMs: 25000,
    });
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      const narratives = JSON.parse(jsonMatch[0]);
      for (const n of narratives) {
        const idx = (n.pickIndex || 1) - 1;
        if (idx >= 0 && idx < picks.length) {
          if (n.coreReasoning && n.coreReasoning.length > 30) {
            picks[idx].coreReasoning = n.coreReasoning;
            finalFixCount++;
            console.log(`[verify-final] Wrote narrative for pick ${idx + 1}: "${picks[idx].pick}"`);
          }
          if (n.whatLoses && n.whatLoses.length > 10) {
            picks[idx].whatLoses = n.whatLoses;
          }
          if (n.dataVerified && n.dataVerified.length > 5) {
            picks[idx].dataVerified = n.dataVerified;
          }
          if (n.clvExpectation && n.clvExpectation.length > 5) {
            picks[idx].clvExpectation = n.clvExpectation;
          }
        }
      }
    }
  } catch (e) {
    if (isXaiHttpError(e) || /no text in xAI response/.test(e.message)) {
      console.log(`[verify-final] ${e.message}`);
    } else {
      console.log(`[verify-final] Grok narrative write failed: ${e.message}`);
      finalFixCount += applyNarrativeTemplate(picks, uniqueNeeds);
    }
  }
  return finalFixCount;
}

async function backfillParlayLegNarratives(legs, uniqueLegNeeds) {
  let finalFixCount = 0;
  if (!uniqueLegNeeds || uniqueLegNeeds.length === 0) return finalFixCount;
  if (!resolveXaiKey()) {
    console.log(`[verify-final] Skipping parlay-leg Grok write — no XAI_API_KEY`);
    return finalFixCount;
  }
  console.log(`[verify-final] Writing parlay-leg narratives for ${uniqueLegNeeds.length} leg(s) via Grok`);
  const legDescriptions = uniqueLegNeeds.map(i => {
    const leg = legs[i];
    return `Leg ${i + 1}: ${leg.pick} ${leg.odds || ''} | ${leg.sport || ''} ${leg.betType || ''} | ${leg.matchup || ''} | Cover: ${leg.coverProb || ''} | EV: ${leg.ev || ''}`;
  }).join('\n');
  try {
    const text = await xaiChat({
      apiKey: resolveXaiKey(),
      system: PARLAY_LEG_NARRATIVE_SYSTEM,
      user: `Write narratives for these parlay legs:\n${legDescriptions}`,
      maxTokens: 2000,
      timeoutMs: 25000,
    });
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      const narratives = JSON.parse(jsonMatch[0]);
      for (const n of narratives) {
        const idx = (n.legIndex || 1) - 1;
        if (idx >= 0 && idx < legs.length) {
          if (n.coreReasoning && n.coreReasoning.length > 30) {
            legs[idx].coreReasoning = n.coreReasoning;
            finalFixCount++;
            console.log(`[verify-final] Wrote parlay-leg narrative for leg ${idx + 1}: "${legs[idx].pick}"`);
          }
          if (n.whatLoses && n.whatLoses.length > 10) legs[idx].whatLoses = n.whatLoses;
          if (n.dataVerified && n.dataVerified.length > 5) legs[idx].dataVerified = n.dataVerified;
          if (n.clvExpectation && n.clvExpectation.length > 5) legs[idx].clvExpectation = n.clvExpectation;
        }
      }
    }
  } catch (e) {
    if (isXaiHttpError(e) || /no text in xAI response/.test(e.message)) {
      console.log(`[verify-final] parlay-leg ${e.message}`);
    } else {
      console.log(`[verify-final] Grok parlay-leg narrative write failed: ${e.message}`);
      finalFixCount += applyParlayLegTemplate(legs, uniqueLegNeeds);
    }
  }
  return finalFixCount;
}

// ── Auto-Fix: drop a critical pick. Do not invent a replacement straight. ──
async function autoFixPicks(picksData, pickReports) {
  const criticalIndices = [];
  for (let i = 0; i < pickReports.length; i++) {
    if (pickReports[i].mathSeverity === "critical") criticalIndices.push(i);
  }
  if (criticalIndices.length === 0) return { fixed: false, replacements: [] };

  const replacements = [];
  for (const idx of criticalIndices.slice().sort((a, b) => b - a)) {
    const badPick = picksData.picks[idx];
    if (!badPick) continue;
    replacements.push({
      index: idx,
      removed: badPick.pick,
      removedReason: (pickReports[idx].errors || []).join("; "),
      added: null,
    });
    picksData.picks.splice(idx, 1);
    console.log(`[verify-fix] REMOVED pick ${idx + 1}: "${badPick.pick}" (no replacement — verify does not invent straights)`);
  }

  // Fix narrative warnings (too short/empty) — add generic narrative if missing
  for (let i = 0; i < picksData.picks.length; i++) {
    const p = picksData.picks[i];
    if (!p.coreReasoning || p.coreReasoning.trim().length < 20) {
      p.coreReasoning = `WeBetAI's statistical model identifies edge value on this ${p.sport} ${p.betType || ''} play. The projection disagrees with the consensus line, creating a positive expected value opportunity.`;
      console.log(`[verify-fix] Added generic narrative for pick ${i + 1}: "${p.pick}"`);
    }
    if (!p.whatLoses || p.whatLoses.trim().length < 10) {
      p.whatLoses = "The opposite outcome materializes, or late line movement eliminates the edge.";
    }
  }

  // Grades are quality (edge/CLV) — do not force them back to unit-sized letters.
  // Keep existing rating/confidence from generator; only ensure confidence exists.
  for (const p of picksData.picks) {
    if (p.rating && (p.confidence == null || p.confidence === '')) {
      const map = { aplus: 90, a: 82, aminus: 75, bplus: 68, b: 60 };
      p.confidence = map[String(p.rating).toLowerCase()] || 60;
    }
  }

  // Recalculate summary + enforce 4.0u daily cap (straights ≤3.5u + parlay 0.5u)
  enforceOmegaDailyUnitCap(picksData);
  if (picksData.summary) {
    picksData.summary.totalPicks = picksData.picks.length;
    picksData.summary.totalStraightBets = picksData.picks.length;
    writeSummaryStakeDisplay(picksData.summary, picksData.picks, picksData.parlayLegs);
  }

  return { fixed: true, replacements };
}

// ── Write updated picks back to blob ──
async function updatePicksBlob(dateKey, picksData) {
  try { enforceOmegaDailyUnitCap(picksData); } catch (e) { console.error('[verify] unit cap', e.message); }
  try { attachAuditSummary(picksData, currentAudit()); }
  catch (e) { console.error(`[omega-audit] verify card summary soft-fail: ${e && e.message}`); }
  picksData.verifiedAt = new Date().toISOString();
  // verified is set by the caller (final pass) based on whether the FINAL card is genuinely clean.
  // Do NOT force true here — a red-flagged pick that couldn't be resolved must not be stamped "verified".
  if (typeof picksData.verified !== "boolean") picksData.verified = true;

  const token = process.env.NETLIFY_AUTH_TOKEN;
  if (!token) return false;

  try {
    const url = `https://api.netlify.com/api/v1/blobs/${SITE_ID}/edge-picks-omega/picks-${dateKey}`;
    const resp = await auditFetch(url, {
      method: "PUT",
      headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(picksData),
    });
    if (resp.ok) {
      console.log(`[verify] Updated picks blob for ${dateKey}`);
      return true;
    }
  } catch (e) {
    console.error(`[verify] Blob update failed: ${e.message}`);
  }
  return false;
}

// ── Discord Alert ──
async function postToDiscord(report, sharpResult) {
  // PAUSED 2026-10-15 (Ben): all Discord posts off. QA/report still run. Flip to false to re-enable.
  const DISCORD_POSTS_PAUSED = true;
  if (DISCORD_POSTS_PAUSED) { console.log("[verify] Discord posts paused, skipping"); return; }
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) { console.log("[verify] No DISCORD_BOT_TOKEN, skipping alert"); return; }

  const hasIssues = report.totalErrors > 0 || report.totalWarnings > 0;
  const hasSharpFlags = sharpResult?.verdict === "red_flag";
  const hasReplacements = report.replacements && report.replacements.length > 0;

  // Only post if there are issues or replacements
  if (!hasIssues && !hasSharpFlags && !hasReplacements) {
    console.log("[verify] All clean — no Discord alert needed");
    return;
  }

  let msg = `**🔍 OMEGA Pick Verification Report — ${report.date}**\n`;

  if (hasReplacements) {
    msg += `\n**⚠️ Auto-Fixed ${report.replacements.length} pick(s):**\n`;
    for (const r of report.replacements) {
      msg += `• Removed: \`${r.removed}\` — ${r.removedReason}\n`;
      msg += `  Replaced with: \`${r.added || 'REMOVED (no replacement)'}\`\n`;
    }
  }

  if (report.totalErrors > 0) {
    msg += `\n**❌ ${report.totalErrors} Error(s):**\n`;
    for (const pr of report.picks) {
      for (const e of pr.errors) msg += `• ${pr.pick}: ${e}\n`;
    }
  }

  if (report.totalWarnings > 0) {
    msg += `\n**⚠️ ${report.totalWarnings} Warning(s):**\n`;
    for (const pr of report.picks) {
      for (const w of pr.warnings) msg += `• ${pr.pick}: ${w}\n`;
    }
  }

  if (sharpResult && sharpResult.verdict !== "clean" && sharpResult.verdict !== "skip") {
    msg += `\n**🎰 Sharp Handicapper Review: ${sharpResult.verdict.toUpperCase()}**\n`;
    msg += `${sharpResult.analysis}\n`;
    if (sharpResult.pickFlags) {
      for (const f of sharpResult.pickFlags) {
        msg += `• Pick #${f.pickIndex}: [${f.flag}] ${f.reason}\n`;
      }
    }
  }

  msg += `\n${report.summary}\nhttps://webetsocial.com/omega`;

  // Truncate if too long for Discord (2000 char limit)
  if (msg.length > 1950) msg = msg.slice(0, 1950) + '...';

  try {
    const resp = await auditFetch(`https://discord.com/api/v10/channels/${DISCORD_CHANNEL}/messages`, {
      method: "POST",
      headers: { "Authorization": `Bot ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ content: msg }),
    });
    if (resp.ok) console.log("[verify] Discord alert posted");
    else console.log(`[verify] Discord post failed: ${resp.status}`);
  } catch (e) {
    console.log(`[verify] Discord error: ${e.message}`);
  }
}

// ── Fetch picks from blob store ──
async function fetchBetaPicks(dateKey) {
  const token = process.env.NETLIFY_AUTH_TOKEN;
  if (!token) return null;

  const baseUrl = `https://api.netlify.com/api/v1/blobs/${SITE_ID}/edge-picks-omega`;
  const headers = { Authorization: `Bearer ${token}` };

  if (!dateKey) {
    try {
      const resp = await auditFetch(`${baseUrl}/latest-date`, { headers });
      if (resp.ok) dateKey = (await resp.text()).trim().replace(/"/g, '');
    } catch (e) { console.error("[verify] latest-date fetch failed:", e.message); }
  }
  if (!dateKey) return null;

  try {
    const resp = await auditFetch(`${baseUrl}/picks-${dateKey}`, { headers });
    if (resp.ok) return { dateKey, data: await resp.json() };
  } catch (e) { console.error("[verify] picks fetch failed:", e.message); }
  return null;
}

// ── Store report ──
async function storeReport(dateKey, report) {
  const token = process.env.NETLIFY_AUTH_TOKEN;
  if (!token) return;
  try {
    await auditFetch(
      `https://api.netlify.com/api/v1/blobs/${SITE_ID}/edge-picks-omega/verification-${dateKey}`,
      { method: "PUT", headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify(report) }
    );
  } catch (e) { console.error("[verify] Store error:", e.message); }
}

exports.buildQualityReplacement = buildQualityReplacement;
exports.steamDropBlocksStraightRefill = steamDropBlocksStraightRefill;
exports.straightRefillAllowed = straightRefillAllowed;
exports.applyVerifyReserveTopUp = applyVerifyReserveTopUp;
exports.resolveLockedParlay = resolveLockedParlay;
exports.formatCombinedAmerican = formatCombinedAmerican;
exports.sportEvFloor = sportEvFloor;
exports.sportCoverFloor = sportCoverFloor;
exports.candidateClearsSportGates = candidateClearsSportGates;
exports.updatePicksBlob = updatePicksBlob;
exports.fetchBetaPicks = fetchBetaPicks;
exports.enforceOmegaDailyUnitCap = enforceOmegaDailyUnitCap;
exports.sharpReview = sharpReview;
exports.backfillStraightNarratives = backfillStraightNarratives;
exports.backfillParlayLegNarratives = backfillParlayLegNarratives;

// ── Handler ──
const { rejectUnlessEtSlot, etParts } = require("./lib/et-schedule");

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: CORS, body: "" };
  const etSkip = rejectUnlessEtSlot("verify-picks-omega", event);
  if (etSkip) return etSkip;

  if (!event._omegaAuditBound) {
    const params = event.queryStringParameters || {};
    let dateKey = params.date || null;
    if (!dateKey) {
      dateKey = new Date().toLocaleDateString("en-CA", { timeZone: "America/New_York" });
    }
    const auditLog = createAuditLog({
      runId: makeRunId(),
      date: dateKey,
      fn: 'verify-picks-omega',
    });
    const bound = Object.assign({}, event, {
      _omegaAuditBound: true,
      queryStringParameters: Object.assign({}, params, { date: dateKey }),
    });
    return runWithAudit(auditLog, async () => {
      try {
        return await exports.handler(bound);
      } finally {
        try {
          await persistAuditLog(auditLog, { dryRun: replayNoWrite() });
        } catch (err) {
          console.error(`[omega-audit] verify persist soft-fail: ${err && err.message}`);
        }
      }
    });
  }

  try {
    const params = event.queryStringParameters || {};
    let dateKey = params.date || null;

    if (!dateKey) {
      const now = new Date();
      dateKey = now.toLocaleDateString("en-CA", { timeZone: "America/New_York" });
    }

    console.log(`[verify] Starting verification for ${dateKey}`);

    const result = await fetchBetaPicks(dateKey);
    if (!result || !result.data || !result.data.picks || result.data.picks.length === 0) {
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ date: dateKey, verified: false, summary: "No picks found" }) };
    }

    const picksData = result.data;
    const dateFormatted = dateKey;
    const lockedStraightPicks = (picksData.picks || []).map(p => p.pick).filter(Boolean);

    // ── Step 1: Math + Narrative checks ──
    let totalWarnings = 0, totalErrors = 0;
    const pickReports = [];

    for (const pick of picksData.picks) {
      const math = runMathChecks(pick);
      const narrative = runNarrativeChecks(pick);
      const allWarnings = [...math.warnings, ...narrative.warnings];
      const allErrors = [...math.errors, ...narrative.errors];
      const severity = math.severity === "critical" || narrative.severity === "critical" ? "critical" : allWarnings.length > 0 ? "warning" : "clean";
      totalWarnings += allWarnings.length;
      totalErrors += allErrors.length;
      pickReports.push({ pick: `${pick.pick} ${pick.odds}`, sport: pick.sport, severity, mathSeverity: math.severity, mathChecks: math.checks, narrativeChecks: narrative.checks, warnings: allWarnings, errors: allErrors });
    }

    console.log(`[verify] Math/narrative: ${totalErrors} errors, ${totalWarnings} warnings`);

    // ── Step 1.5: Hard Rock + US-major placeability (soft-veto) ──
    // Drop a pick only when Hard Rock and majors coverage both fail. Odds API down
    // warns and leaves the card. Do not mark critical — auto-fix must not invent a
    // replacement side. Empty card OK.
    let hrCheck = { summary: { skipped: true }, pickResults: [], parlayFindings: [], legDecisions: [], corrections: [], changed: false };
    let blockStraightRefill = false;
    let blockParlayRefill = false;
    let placeabilityDropped = 0;
    let droppedSteam = 0;
    let lateNewsReport = null;
    const droppedThisRun = [];
    let verifyTopUps = [];
    try {
      hrCheck = await runHardRockCheck(picksData);
      if (hrCheck.changed) {
        // Reports were built on the pre-correct card. Rebuild them on the
        // Hard Rock numbers so a stale critical error cannot drop the new side.
        totalWarnings = 0;
        totalErrors = 0;
        pickReports.length = 0;
        for (const pick of picksData.picks) {
          const math = runMathChecks(pick);
          const narrative = runNarrativeChecks(pick);
          const allWarnings = [...math.warnings, ...narrative.warnings];
          const allErrors = [...math.errors, ...narrative.errors];
          const severity = math.severity === "critical" || narrative.severity === "critical" ? "critical" : allWarnings.length > 0 ? "warning" : "clean";
          totalWarnings += allWarnings.length;
          totalErrors += allErrors.length;
          pickReports.push({ pick: `${pick.pick} ${pick.odds}`, sport: pick.sport, severity, mathSeverity: math.severity, mathChecks: math.checks, narrativeChecks: narrative.checks, warnings: allWarnings, errors: allErrors });
        }
        for (const row of (hrCheck.corrections || [])) {
          console.log(`[verify-hardrock] card ${row.action}: ${row.from || ''} → ${row.to || 'dropped'} (${row.reason || ''})`);
          const idx = row.to ? picksData.picks.findIndex(p => p.pick === row.to) : -1;
          if (idx >= 0 && pickReports[idx]) {
            pickReports[idx].warnings.push(`Hard Rock auto-correct ${row.action}: ${row.from} → ${row.to} (${row.reason || ''})`);
            totalWarnings++;
            if (pickReports[idx].severity === "clean") pickReports[idx].severity = "warning";
          }
        }
        try {
          await updatePicksBlob(dateKey, picksData);
        } catch (e) {
          console.log(`[verify-hardrock] auto-correct blob write soft-fail: ${e.message}`);
        }
      }
      const decisions = (hrCheck.pickResults || []).map(r => (r && r.decision) || { drop: false });
      const legDecisions = hrCheck.legDecisions || [];
      for (let i = 0; i < pickReports.length; i++) {
        const r = hrCheck.pickResults[i];
        if (!r) continue;
        pickReports[i].hardRock = { available: r.available, hrOdds: r.hrOdds, hrPoint: r.hrPoint, notes: r.notes || [] };
        if (r.decision && r.decision.drop) {
          pickReports[i].placeabilityDrop = r.decision.reason;
          continue;
        }
        for (const w of r.warnings) { pickReports[i].warnings.push(w); totalWarnings++; }
        for (const e of r.errors) { pickReports[i].errors.push(e); totalErrors++; }
        if (pickReports[i].severity === "clean" && (r.warnings.length > 0 || r.errors.length > 0)) {
          pickReports[i].severity = "warning";
        }
      }
      totalErrors += hrCheck.parlayFindings.filter(f => f.level === "error").length;
      totalWarnings += hrCheck.parlayFindings.filter(f => f.level === "warning").length;
      const anyDrop = decisions.some(d => d.drop) || legDecisions.some(d => d.drop);
      if (anyDrop && !hrCheck.summary.apiDown && !hrCheck.summary.skipped) {
        const picksBeforePlace = (picksData.picks || []).slice();
        const applied = applyPlaceabilityDrops(picksData, decisions, legDecisions);
        for (const gone of picksBeforePlace) {
          if (!(picksData.picks || []).includes(gone)) droppedThisRun.push(gone);
        }
        for (let i = pickReports.length - 1; i >= 0; i--) {
          if (decisions[i] && decisions[i].drop) pickReports.splice(i, 1);
        }
        placeabilityDropped = applied.dropped;
        if (applied.dropped > 0) blockStraightRefill = true;
        if (applied.parlayCleared) blockParlayRefill = true;
        console.log(`[verify-placeability] soft-veto dropped ${applied.dropped} straight(s); parlayCleared=${applied.parlayCleared}; remaining=${picksData.picks.length}`);
        await updatePicksBlob(dateKey, picksData);
      } else if (hrCheck.summary.apiDown || hrCheck.summary.skipped) {
        console.log(`[verify-placeability] odds API unavailable — card left intact (${hrCheck.summary.reason || "feed down"})`);
      }
      console.log(`[verify-hardrock] ${hrCheck.summary.available}/${hrCheck.summary.checked} bets confirmed at Hard Rock Bet | ${hrCheck.summary.errors} error(s), ${hrCheck.summary.warnings} warning(s)`);
    } catch (e) {
      console.log(`[verify-hardrock] Check failed (non-fatal, card unchanged): ${e.message}`);
    }

    // ── Step 1.6: Steam is a pre-10:30 selection input only ──
    // sharpSteamSinceOpen records size and direction, and dkLagsSharp, on
    // the generate path. Verify does not recheck steam and does not drop
    // or reprice a pick for steam. Nothing on the card moves for steam
    // after the 10:30 lock. runOmegaSteamRecheck is not called.
    let steamCheck = { checked: 0, failed: 0, reasons: [] };
    if (steamDropBlocksStraightRefill(droppedSteam, steamCheck.failed)) {
      blockStraightRefill = true;
    }

    // ── Step 2: Auto-fix critical issues ──
    const fixResult = await autoFixPicks(picksData, pickReports);
    if (fixResult.fixed) {
      console.log(`[verify] Auto-fixed ${fixResult.replacements.length} pick(s)`);
      for (const row of fixResult.replacements || []) {
        if (row && row.removed) droppedThisRun.push({ pick: row.removed, side: row.removed });
      }
      // Write updated picks back to blob so the page shows clean data
      await updatePicksBlob(dateKey, picksData);
    }

    // Pre-publish news reprice. Same 90-minute window. A scratched starter,
    // a priced goalie change, or a newly out QB reprices at the posted
    // DraftKings number and stays when the new EV clears the floor. It
    // drops only on ev-floor. Postponed and suspended still void. This
    // verify slot is 10:30 ET, before the 11:00 publish. Never adds a side.
    try {
      const lateNow = new Date();
      const late = await lateNews.runLateNews({
        picksData,
        dateISO: dateKey,
        now: lateNow,
        withinMin: 90,
      });
      lateNewsReport = late;
      try {
        const plan = lateNews.commitLateNewsCard(picksData, late, {
          resolveLockedParlay,
          enforceCap: enforceOmegaDailyUnitCap,
        });
        if (plan.blockStraightRefill) blockStraightRefill = true;
        if (late && Array.isArray(late.removed)) {
          for (const name of late.removed) {
            if (name) droppedThisRun.push({ pick: name, side: name });
          }
        }
        for (const row of picksData.voidedPregame || []) {
          if (row) droppedThisRun.push({ ...row, void: true });
        }
        if (plan.write) await updatePicksBlob(dateKey, picksData);
      } catch (e) {
        console.log(`[verify-late-news] write soft-fail: ${e.message}`);
      }
      try {
        await storeLateNewsOps(dateKey, lateNews.opsFromRun(late, {
          date: dateKey,
          functionName: 'verify-picks-omega',
          et: etParts(lateNow).et,
        }));
      } catch (e) {
        console.error(`[verify-late-news] ops soft-fail: ${e.message}`);
      }
    } catch (e) {
      console.log(`[verify-late-news] soft-fail: ${e.message}`);
      lateNewsReport = { dropped: 0, flagged: 0, checked: 0, httpCalls: 0, softFail: true, error: e.message };
    }

    // ── Step 3: Sharp handicapper review ──
    const sharpResult = await sharpReview(picksData.picks, dateFormatted);
    console.log(`[verify] Sharp review: ${sharpResult.verdict} (${sharpResult.confidence || 0}% confidence)`);

    // ── Step 3b: Sharp handicapper review — INFORMATIONAL ONLY (2026-06-25) ──
    // The sharp review is a non-deterministic LLM working from STALE training knowledge (no live data).
    // It false-flagged a genuine +EV play (on narrative) AND a fine play (claimed "corrupted data" on a
    // correct A's road game). So it must NOT modify, resize, or annotate the user-facing card. Its verdict
    // is logged + posted to Discord for human monitoring only; real structural issues (same-game
    // correlation) are handled deterministically upstream (canonical-key de-correlation in the merge).
    let sharpReplacements = [];
    if (sharpResult.verdict === "red_flag") {
      console.log(`[verify-sharp] (informational, no card change) red_flag: ${sharpResult.analysis || ""}`);
    }

    // Merge all replacements
    const hrReplacements = (hrCheck.corrections || [])
      .filter(c => c && (c.action === 'repriced' || c.action === 'replaced' || c.action === 'dropped'))
      .map(c => ({
        removed: c.from && c.from !== c.to ? c.from : null,
        added: c.to || null,
        removedReason: `hardrock-autocorrect:${c.action}`,
      }));
    const allReplacements = [...(fixResult.replacements || []), ...sharpReplacements, ...hrReplacements];

    // ── Step 3c: FINAL PASS — re-verify the locked card. ──
    // After drops, refill from the private reserve up to 3. Steam does not
    // refill. A blocked side never returns. No odds pull. When the reserve
    // cannot fill the card, publish what remains.
    // 1. Every remaining pick has a real narrative (not generic)
    // 2. Grades stay quality/edge — never rewritten from units
    // 3. Math checks pass
    // 4. A top-up rebuilds the parlay from the final straights. Otherwise a
    //    locked parlay is preserved, or a dropped leg is removed.
    {
      console.log(`[verify-final] Running final verification pass on ${picksData.picks.length} picks`);
      let finalFixCount = 0;

      // Placeability, late-news, and auto-fix drops refill from the private reserve up to 3.
      // Steam does not refill. A blocked side never returns.
      const stillOnCard = new Set(picksData.picks.map(p => p.pick));
      const removedSinceLock = lockedStraightPicks.filter(p => !stillOnCard.has(p));
      for (const name of removedSinceLock) {
        if (name && !droppedThisRun.some((row) => (row.pick || row.side) === name)) {
          droppedThisRun.push({ pick: name, side: name });
        }
      }
      const topUpResult = applyVerifyReserveTopUp(picksData, {
        droppedSteam,
        steamHardFails: steamCheck.failed,
        blocked: require('./lib/omega-vnext/card_integrity').blockedRowsFor(picksData, droppedThisRun),
      });
      verifyTopUps = topUpResult.topUps || [];
      if (topUpResult.topped) {
        console.log(`[verify-final] reserve top-up ${verifyTopUps.length}: ${verifyTopUps.map((row) => `${row.pick} (${row.reason})`).join(', ')}`);
      } else if (removedSinceLock.length || picksData.picks.length < lockedStraightPicks.length) {
        console.log(`[verify-final] Straight refill blocked — publishing ${picksData.picks.length} pick(s) from the locked card`);
      }

      // Strip stale sharp-review annotations only.
      // Grades stay quality/edge from generator — NEVER rewrite from units (v12.1+).
      for (const p of picksData.picks) {
        delete p.sharpConcern; delete p._dropRedFlag;
      }

      // Identify picks needing real narratives (generic, too short, or contains "replaces")
      const needsNarrative = [];
      for (let i = 0; i < picksData.picks.length; i++) {
        const p = picksData.picks[i];
        const cr = p.coreReasoning || "";
        if (cr.length < 80 || cr.includes('replaces a') || cr.includes('replacing a') || cr.includes('statistical edge on this')) {
          needsNarrative.push(i);
        }
        if (!p.whatLoses || p.whatLoses.trim().length < 15) {
          needsNarrative.push(i); // will dedupe below
        }
      }
      const uniqueNeeds = [...new Set(needsNarrative)];

      // Grok writes narratives for picks that need them. Failure keeps the card.
      finalFixCount += await backfillStraightNarratives(picksData.picks, uniqueNeeds);

      // Ensure UI fields always present after narrative pass (Grok may omit optional keys)
      for (const p of picksData.picks) {
        if (!p.whatLoses || p.whatLoses.trim().length < 15) {
          p.whatLoses = "The opposite outcome materializes, or late line movement eliminates the edge.";
          finalFixCount++;
        }
        if (!p.dataVerified || p.dataVerified.trim().length < 5) {
          p.dataVerified = "Model-grounded edge; narrative verified in QA final pass.";
        }
        if (!p.clvExpectation || p.clvExpectation.trim().length < 5) {
          p.clvExpectation = "Expect modest movement toward the pick if sharp money arrives; monitor into close.";
        }
      }

      // Re-verify math on all picks
      for (let i = 0; i < picksData.picks.length; i++) {
        const finalMath = runMathChecks(picksData.picks[i]);
        if (finalMath.severity === "critical") {
          console.log(`[verify-final] CRITICAL: Pick ${i + 1} still fails math — flagging for Discord`);
          picksData.picks[i]._verifyFlag = "math-critical-after-fix";
        }
      }

      // ── Parlay: a reserve top-up already rebuilt from the final straights.
      // Otherwise preserve the generate-locked slip. Drop a leg steam or safety
      // already removed. Do not compose a new parlay from the straight card.
      const removedPicks = [
        ...removedSinceLock,
        ...allReplacements.map(r => r.removed).filter(Boolean),
      ];
      if (topUpResult.topped) {
        console.log(`[verify-final] Parlay rebuilt from ${picksData.picks.length} straights after reserve top-up`);
      } else {
        if (blockParlayRefill) {
          console.log(`[verify-final] Parlay not refilled after placeability soft-veto`);
        }
        const resolvedParlay = resolveLockedParlay(picksData.parlayLegs, {
          removedPicks,
          straightCard: picksData.picks,
        });
        if (resolvedParlay.rebuilt) {
          console.error('[verify] parlay rebuild requested — ignored; QA does not block publish');
        } else {
          picksData.parlayLegs = resolvedParlay.parlayLegs;
        }
        if (resolvedParlay.action === 'preserved') {
          const keptType = (picksData.parlayLegs[0] && picksData.parlayLegs[0].type) || 'none';
          console.log(`[verify-final] Parlay preserved — generator output intact (${keptType})`);
        } else if (resolvedParlay.action === 'resized') {
          finalFixCount++;
          console.log(`[verify-final] Parlay resized after a safety drop — legs kept: ${resolvedParlay.parlayLegs[0].legs.map(l => l.pick).join(' + ')}`);
        } else if (resolvedParlay.action === 'cleared') {
          console.log(`[verify-final] Parlay cleared — a safety drop left fewer than 2 locked legs`);
        }
        if ((picksData.picks || []).length < MAX_STRAIGHTS) {
          picksData.shortfall = buildShortfall({
            picks: picksData.picks,
            parlayLegs: picksData.parlayLegs,
            yesPool: picksData.reserve || [],
            rejected: droppedThisRun,
          });
        }
      }

      // ── Step 3c-parlay: write journalistic narratives for PARLAY LEGS (Optimized Parlay cards) ──
      // Straights get writeups above; parlay legs often differ from the straight card and were
      // previously left with empty/fallback blurbs. Mirror the straight Grok pass per-leg.
      {
        const plRoot = (Array.isArray(picksData.parlayLegs) && picksData.parlayLegs[0]) || null;
        const legs = (plRoot && Array.isArray(plRoot.legs)) ? plRoot.legs : [];
        const needsLeg = [];
        for (let i = 0; i < legs.length; i++) {
          const leg = legs[i];
          // Prefer matching straight narrative when same pick+matchup already has real prose
          const match = picksData.picks.find(p => p.pick === leg.pick && p.matchup === leg.matchup);
          if (match && match.coreReasoning && match.coreReasoning.length > 80 && !/replaces a|statistical edge on this/i.test(match.coreReasoning)) {
            leg.coreReasoning = match.coreReasoning;
            if (match.whatLoses) leg.whatLoses = match.whatLoses;
            if (match.dataVerified) leg.dataVerified = match.dataVerified;
            if (match.clvExpectation) leg.clvExpectation = match.clvExpectation;
          }
          const cr = leg.coreReasoning || "";
          if (cr.length < 80 || /replaces a|statistical edge on this|clears Omega vNext gates/i.test(cr)) {
            needsLeg.push(i);
          } else if (!leg.whatLoses || leg.whatLoses.trim().length < 15) {
            needsLeg.push(i);
          }
        }
        const uniqueLegNeeds = [...new Set(needsLeg)];
        finalFixCount += await backfillParlayLegNarratives(legs, uniqueLegNeeds);
      }

      // Ensure parlay legs carry whatLoses for Optimized Parlay cards
      {
        const plRoot = (Array.isArray(picksData.parlayLegs) && picksData.parlayLegs[0]) || null;
        for (const leg of ((plRoot && plRoot.legs) || [])) {
          if (!leg.whatLoses || String(leg.whatLoses).trim().length < 15) {
            leg.whatLoses = "The opposite outcome materializes, or late line movement eliminates the edge.";
            finalFixCount++;
          }
          if (!leg.dataVerified || String(leg.dataVerified).trim().length < 5) {
            leg.dataVerified = "Model-grounded parlay leg; narrative verified in QA final pass.";
          }
          if (!leg.clvExpectation || String(leg.clvExpectation).trim().length < 5) {
            leg.clvExpectation = "Expect modest movement toward the leg if sharp money arrives.";
          }
        }
      }

      // QA_HARDFAIL soft: generator already dropped SP/QB/stale; verify does not force-fill leans.
      // Grok remains narrator/verifier only — structural hard-fails live in omega-vnext/qa_hardfail.js.
      // verified ONLY if the final card is genuinely clean: at least 1 pick and none still failing math
      picksData.verified = picksData.picks.length > 0 && picksData.picks.every(p => !p._verifyFlag);

      // Sort check: card top 3 vs the re-ranked list. Silent on the page.
      // A mismatch rebuilds the top 3 and the parlay and writes bugLog only.
      {
        const sortCheck = applySilentSortCheck(picksData);
        if (sortCheck.entry) {
          if (!Array.isArray(picksData.bugLog)) picksData.bugLog = [];
          picksData.bugLog.push(sortCheck.entry);
        }
        if (sortCheck.changed) {
          const restoresBlocked = (sortCheck.picks || []).some((row) => sideBlocked(row, droppedThisRun));
          // The 10:00 rank list still names a side this run already dropped.
          // Putting it back would undo the reserve fill. Keep the topped-up card.
          if (topUpResult.topped || restoresBlocked) {
            console.log('[verify-final] sort-check rebuild skipped — blocked side or reserve top-up');
          } else {
            picksData.picks = sortCheck.picks;
            const prevTicket = (Array.isArray(picksData.parlayLegs) && picksData.parlayLegs[0]) || {};
            const rebuilt = parlayFromStraights(picksData.picks, {
              hrPlaceabilityNote: prevTicket.hrPlaceabilityNote,
              pool: picksData.candidateTable,
            });
            if (rebuilt.length) picksData.parlayLegs = rebuilt;
            enforceOmegaDailyUnitCap(picksData);
            console.log(`[verify-sort] silent auto-correct differed=${sortCheck.entry.differed.length}`);
          }
        }
      }

      // Write the final clean card
      await updatePicksBlob(dateKey, picksData);
      console.log(`[verify-final] Final pass complete: ${finalFixCount} fixes applied and saved`);
    }

    // ── Step 4: Build report ──
    const anyFixed = allReplacements.length > 0;
    const report = {
      date: dateKey,
      verified: picksData.verified === true,
      autoFixed: anyFixed,
      replacements: allReplacements,
      totalWarnings,
      totalErrors,
      sharpRedFlags: sharpReplacements.length,
      picks: pickReports,
      hardRock: { ...hrCheck.summary, parlay: hrCheck.parlayFindings, corrections: hrCheck.corrections || [] },
      placeability: { dropped: placeabilityDropped, parlayCleared: blockParlayRefill },
      topUps: verifyTopUps,
      steamRecheck: steamCheck,
      lateNews: lateNewsReport ? {
        checked: lateNewsReport.checked || 0,
        dropped: lateNewsReport.dropped || 0,
        flagged: lateNewsReport.flagged || 0,
        httpCalls: lateNewsReport.httpCalls || 0,
        softFail: !!lateNewsReport.softFail,
      } : { checked: 0, dropped: 0, flagged: 0, httpCalls: 0, softFail: false },
      sharpReview: sharpResult,
      summary: `${pickReports.length} picks checked | ${totalErrors} error(s) | ${totalWarnings} warning(s) | HardRock: ${hrCheck.summary.skipped ? "skipped" : `${hrCheck.summary.available}/${hrCheck.summary.checked} confirmed`} | Sharp: ${sharpResult.verdict}${sharpReplacements.length > 0 ? ` (${sharpReplacements.length} replaced)` : ''} | ${anyFixed ? `Auto-fixed ${allReplacements.length} pick(s)` : 'No fixes needed'}`,
      verifiedAt: new Date().toISOString(),
    };

    // ── Step 5: Store report + Discord alert ──
    await storeReport(dateKey, report);
    await postToDiscord(report, sharpResult);

    return { statusCode: 200, headers: CORS, body: JSON.stringify(report, null, 2) };
  } catch (err) {
    console.error("[verify] Error:", err.message);
    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({
        published: true,
        qaError: err.message,
        message: 'QA did not block publish. The stored card stays up.',
      }),
    };
  }
};
